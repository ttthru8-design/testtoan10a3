# HỆ THỐNG LUYỆN THI TRẮC NGHIỆM TOÁN 10 - PHIẾU TÔ OMR TRỰC TUYẾN

Hệ thống thi trắc nghiệm Toán 10 mô phỏng chân thực kỳ thi tốt nghiệp & kiểm tra tập trung theo chuẩn **Chương trình GDPT mới 2018** (Định dạng đề thi mới của Bộ Giáo dục & Đào tạo).

---

## 🌟 ĐẶC ĐIỂM NỔI BẬT

1. **Quy trình vào phòng thi như thi thật**:
   - **Trang chủ Cổng thi**: Thí sinh điền Họ tên và Lớp.
   - **Bốc mã đề ngẫu nhiên**: Khi ấn **"Vào thi & Bốc mã đề ngẫu nhiên"**, hệ thống phát ngẫu nhiên một mã đề từ ngân hàng đề thi kèm **Thẻ dự thi chính thức** (có Số Báo Danh và Mã Đề Thi được phát, ví dụ `1005`).
   - **Đề thi được niêm phong**: Khi bước vào phòng thi, đề thi ban đầu ở trạng thái khóa. Thí sinh phải tự tay dùng chuột **tô 4 chữ số của Mã đề thi** trên Phiếu trả lời trắc nghiệm OMR.
   - **Mở khóa đề thi tự động**: Khi học sinh tô đúng 4 cột mã đề thi khớp với mã đề được phát, đề thi mở niêm phong, phát âm thanh hiệu lệnh và đồng hồ đếm ngược 90 phút bắt đầu chạy!

2. **Phiếu trả lời trắc nghiệm chuẩn OMR (Bubble Sheet)**:
   - Khung thông tin thí sinh: Họ tên, Lớp.
   - Bảng tô Số Báo Danh (SBD) gồm 6 cột (0 - 9).
   - **Bảng tô Mã Đề Thi gồm 4 cột (0 - 9)**.
   - **Phần I**: 12 câu trắc nghiệm nhiều phương án lựa chọn, mỗi câu 4 bong bóng `(A) (B) (C) (D)`. Hiệu ứng tô chì 2B chân thực.
   - **Phần II**: 4 câu trắc nghiệm Đúng/Sai, mỗi câu 4 ý a, b, c, d với 2 bong bóng `(Đ) (S)`.
   - **Phần III**: 6 câu trắc nghiệm trả lời ngắn (điền đáp số số học/thập phân).

3. **Ngân hàng đề thi phong phú & Các câu hỏi vận dụng cao**:
   - Tích hợp toàn bộ 40 câu hỏi từ đề tài liệu **"BÀI TẬP TỐI TOÁN 10 - KTTT LẦN 3"** với đầy đủ các dạng toán khó phân hóa:
     + Tìm điểm cực trị hình học $MA + MB$ nhỏ nhất trên trục $Oy$ ($M(0; 19/5)$).
     + Điểm cực trị $MA^2 + MB^2 + 2MC^2$ nhỏ nhất (tâm tỉ cự $I(0; 0)$).
     + Điểm $M \in Oy$ sao cho $|\vec{MA} + \vec{MB} + \vec{MC} + \vec{MD}|$ nhỏ nhất ($M(0; 1)$).
     + Máy bay drone tiếp nhiên liệu trên đoạn $AB$ thỏa mãn $MA = 2MB$ ($M(3; -2)$).
     + Bài toán tối ưu điểm thưởng pha chế nước ngọt cuộc thi (640 điểm).
     + Bài toán vật lý: 3 lực tác dụng vào điểm $M$ cân bằng ($F_3 = 25\sqrt{3}\text{ N}$).
     + Phân tích vectơ trong hình bình hành, tam giác, tọa độ Oxy.
   - Tạo sẵn **12 mã đề hoàn chỉnh** (Mã `1001` đến `1012`), mỗi đề gồm đầy đủ 22 câu hỏi (3 phần).

4. **Chấm điểm tức thì theo quy chế Bộ GD&ĐT**:
   - **Phần I**: 12 câu x 0.25đ = Tối đa **3.0 điểm**.
   - **Phần II**: 4 câu Đúng/Sai. Quy tắc tính điểm chuẩn Bộ:
     + Đúng 1 ý: 0.10 điểm
     + Đúng 2 ý: 0.25 điểm
     + Đúng 3 ý: 0.50 điểm
     + Đúng 4 ý: 1.00 điểm
     (Tối đa 4 câu x 1.0đ = **4.0 điểm**).
   - **Phần III**: 6 câu trả lời ngắn x 0.5đ = Tối đa **3.0 điểm**.
   - **Tổng điểm tối đa: 10.0 điểm**.
   - Pháo hoa chúc mừng nếu đạt điểm cao, xếp loại (Xuất sắc, Giỏi, Khá, Trung bình...).
   - **Lời giải chi tiết từng bước** cho toàn bộ các câu hỏi.
   - Lưu trữ lịch sử bài thi trên trình duyệt (LocalStorage).

---

## 🚀 HƯỚNG DẪN SỬ DỤNG

1. **Cách 1**: Nhấp đúp vào file `chay_web.bat` để mở ngay trên trình duyệt Chrome/Edge/Cốc Cốc.
2. **Cách 2**: Nhấp đúp trực tiếp vào file [index.html](file:///c:/Users/asus/Downloads/luy%E1%BB%87n%20to%C3%A1n/index.html).
3. **Cách 3**: Khởi chạy server nội bộ bằng dòng lệnh:
   ```bash
   python -m http.server 8080
   ```
   sau đó mở trình duyệt truy cập: `http://localhost:8080/index.html`.
