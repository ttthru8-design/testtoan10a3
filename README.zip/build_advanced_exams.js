// Comprehensive Exam Data Generator with 40 advanced questions from "BÀI TẬP TỐI TOÁN 10 - KTTT LẦN 3"
// and 10+ randomized full exam packages matching the 2025 MoET format.

const fs = require('fs');
const path = require('path');

// 1. NGÂN HÀNG CÂU HỎI TRẮC NGHIỆM TỪ TÀI LIỆU VỪA CUNG CẤP (BÀI TẬP TỐI TOÁN 10 KTTT 3)
const bank40 = [
  {
    id: 1,
    question: "Bất phương trình nào sau đây là bất phương trình bậc nhất hai ẩn?",
    options: ["A. $3x - 2y \\le 5$", "B. $x^2 + y < 1$", "C. $xy \\ge 4$", "D. $x + y + z \\le 3$"],
    answer: "A",
    solution: "Bất phương trình bậc nhất hai ẩn có dạng $ax + by \\le c$ (với $a, b$ không đồng thời bằng 0). Do đó $3x - 2y \\le 5$ là bất phương trình bậc nhất hai ẩn."
  },
  {
    id: 2,
    question: "Trong các cặp số sau đây, cặp nào không là nghiệm của bất phương trình $2x + y < 1$?",
    options: ["A. $(-2; 1)$", "B. $(3; -7)$", "C. $(0; 1)$", "D. $(0; 0)$"],
    answer: "C",
    solution: "Thay $(0; 1)$ vào: $2(0) + 1 = 1 < 1$ là sai. Do đó $(0; 1)$ không là nghiệm."
  },
  {
    id: 3,
    question: "Trong các hệ bất phương trình sau, hệ nào không phải hệ bất phương trình bậc nhất hai ẩn?",
    options: [
      "A. $\\begin{cases} x + 2y > 0 \\\\ 2xy < 3 \\end{cases}$",
      "B. $\\begin{cases} 3x + y < 100 \\\\ x - 2y \\le 10 \\end{cases}$",
      "C. $\\begin{cases} x - 2y > 58 \\\\ 3y + x < 0 \\end{cases}$",
      "D. $\\begin{cases} 2x - y \\le 10 \\\\ x \\le 2 \\end{cases}$"
    ],
    answer: "A",
    solution: "Hệ ở đáp án A chứa số hạng $2xy$ (bậc hai đối với hai biến) nên không phải hệ bất phương trình bậc nhất hai ẩn."
  },
  {
    id: 4,
    question: "Trong các cặp số sau, cặp nào không là nghiệm của hệ bất phương trình $\\begin{cases} x + y - 2 \\le 0 \\\\ 2x - 3y + 2 > 0 \\end{cases}$?",
    options: ["A. $(0; 0)$", "B. $(1; 1)$", "C. $(-1; 1)$", "D. $(-1; -1)$"],
    answer: "C",
    solution: "Thay $(-1; 1)$: $2(-1) - 3(1) + 2 = -3 > 0$ là sai. Vậy $(-1; 1)$ không là nghiệm."
  },
  {
    id: 5,
    question: "Cho tứ giác $ABCD$. Có bao nhiêu vectơ khác vectơ-không có điểm đầu và cuối là các đỉnh của tứ giác?",
    options: ["A. 4", "B. 6", "C. 8", "D. 12"],
    answer: "D",
    solution: "Số vectơ khác vectơ-không có điểm đầu và điểm cuối từ 4 đỉnh phân biệt là $A_4^2 = 4 \\times 3 = 12$ vectơ."
  },
  {
    id: 6,
    question: "Khẳng định nào sau đây là sai?",
    options: [
      "A. $1\\cdot\\vec{a} = \\vec{a}$",
      "B. $k\\vec{a}$ và $\\vec{a}$ cùng hướng khi $k > 0$",
      "C. $k\\vec{a}$ và $\\vec{a}$ cùng hướng khi $k < 0$",
      "D. Hai vectơ $\\vec{a}$ và $\\vec{b} \\ne \\vec{0}$ cùng phương khi có một số $k$ để $\\vec{a} = k\\vec{b}$"
    ],
    answer: "C",
    solution: "Khi $k < 0$, vectơ $k\\vec{a}$ ngược hướng với $\\vec{a}$. Do đó khẳng định C là sai."
  },
  {
    id: 7,
    question: "Trên đường thẳng $MN$ lấy điểm $P$ sao cho $\\vec{MN} = -3\\vec{MP}$. Điểm $P$ được xác định đúng trong hình vẽ nào?",
    options: ["A. Hình 3 (M nằm giữa P và N, MN = 3MP)", "B. Hình 4", "C. Hình 1", "D. Hình 2"],
    answer: "A",
    solution: "Vì $\\vec{MN} = -3\\vec{MP}$ nên hai vectơ $\\vec{MN}$ và $\\vec{MP}$ ngược hướng, suy ra $M$ nằm giữa $P$ và $N$, và đoạn $MN = 3MP$. Điều này ứng với Hình 3."
  },
  {
    id: 8,
    question: "Cho tam giác $ABC$. Gọi $M$ và $N$ lần lượt là trung điểm của $AB$ và $AC$. Trong các mệnh đề sau, tìm mệnh đề sai?",
    options: [
      "A. $\\vec{AB} = 2\\vec{AM}$",
      "B. $\\vec{AC} = 2\\vec{CN}$",
      "C. $\\vec{BC} = -2\\vec{NM}$",
      "D. $\\vec{CN} = -\\frac{1}{2}\\vec{AC}$"
    ],
    answer: "B",
    solution: "Vì $N$ là trung điểm $AC$ nên $\\vec{AC}$ và $\\vec{CN}$ ngược hướng, do đó $\\vec{AC} = -2\\vec{CN}$. Mệnh đề B ghi $\\vec{AC} = 2\\vec{CN}$ là sai."
  },
  {
    id: 9,
    question: "Trong mặt phẳng tọa độ $Oxy$ cho hai điểm $A(1; 4)$ và $B(3; 5)$. Khi đó tọa độ vectơ $\\vec{AB}$ là:",
    options: ["A. $(-2; -1)$", "B. $(1; 2)$", "C. $(2; 1)$", "D. $(4; 9)$"],
    answer: "C",
    solution: "$\\vec{AB} = (3 - 1; 5 - 4) = (2; 1)$."
  },
  {
    id: 10,
    question: "Cho $\\vec{a} = (-1; 2), \\vec{b} = (5; -7)$. Tìm tọa độ của $\\vec{a} - \\vec{b}$.",
    options: ["A. $(6; -9)$", "B. $(4; -5)$", "C. $(-6; 9)$", "D. $(-5; -14)$"],
    answer: "C",
    solution: "$\\vec{a} - \\vec{b} = (-1 - 5; 2 - (-7)) = (-6; 9)$."
  },
  {
    id: 11,
    question: "Cho hình bình hành $ABCD$. Vectơ tổng $\\vec{CB} + \\vec{CD}$ bằng:",
    options: ["A. $\\vec{CA}$", "B. $\\vec{BD}$", "C. $\\vec{AC}$", "D. $\\vec{DB}$"],
    answer: "A",
    solution: "Theo quy tắc hình bình hành xuất phát từ đỉnh $C$: $\\vec{CB} + \\vec{CD} = \\vec{CA}$."
  },
  {
    id: 12,
    question: "Cho $A(4; 0), B(2; -3), C(9; 6)$. Tọa độ trọng tâm $G$ của tam giác $ABC$ là:",
    options: ["A. $(3; 5)$", "B. $(5; 1)$", "C. $(15; 9)$", "D. $(9; 15)$"],
    answer: "B",
    solution: "$x_G = \\frac{4 + 2 + 9}{3} = 5; y_G = \\frac{0 - 3 + 6}{3} = 1 \\implies G(5; 1)$."
  },
  {
    id: 13,
    question: "Trong hệ tọa độ $Oxy$, cho $A(2; -3), B(4; 7)$. Tìm tọa độ trung điểm $I$ của đoạn thẳng $AB$.",
    options: ["A. $(6; 4)$", "B. $(2; 10)$", "C. $(3; 2)$", "D. $(8; -21)$"],
    answer: "C",
    solution: "$I = (\\frac{2 + 4}{2}; \\frac{-3 + 7}{2}) = (3; 2)$."
  },
  {
    id: 14,
    question: "Trong hệ tọa độ $Oxy$, cho ba điểm $A(2; 1), B(0; -3), C(3; 1)$. Tìm tọa độ điểm $D$ để tứ giác $ABCD$ là hình bình hành.",
    options: ["A. $(5; 5)$", "B. $(5; -2)$", "C. $(5; -4)$", "D. $(-1; -4)$"],
    answer: "A",
    solution: "$ABCD$ là hình bình hành $\\iff \\vec{AB} = \\vec{DC} \\iff (-2; -4) = (3 - x_D; 1 - y_D) \\implies x_D = 5, y_D = 5$."
  },
  {
    id: 15,
    question: "Cho $\\vec{a} = 2\\vec{i} - 3\\vec{j}, \\vec{b} = m\\vec{j} + \\vec{i}$. Nếu $\\vec{a}, \\vec{b}$ cùng phương thì giá trị của $m$ là:",
    options: ["A. $m = -6$", "B. $m = 6$", "C. $m = -\\frac{2}{3}$", "D. $m = -\\frac{3}{2}$"],
    answer: "D",
    solution: "$\\vec{a} = (2; -3), \\vec{b} = (1; m)$. Cùng phương $\\iff \\frac{1}{2} = \\frac{m}{-3} \\implies m = -\\frac{3}{2}$."
  },
  {
    id: 16,
    question: "Cho ba điểm $A(2; -4), B(6; 0), C(m; 4)$. Định $m$ để ba điểm $A, B, C$ thẳng hàng?",
    options: ["A. $m = 10$", "B. $m = -6$", "C. $m = 2$", "D. $m = -10$"],
    answer: "A",
    solution: "$\\vec{AB} = (4; 4) = 4(1; 1)$. $\\vec{AC} = (m - 2; 8)$. Thẳng hàng khi $\\frac{m - 2}{4} = \\frac{8}{4} = 2 \\implies m - 2 = 8 \\implies m = 10$."
  },
  {
    id: 17,
    question: "Cho ba vectơ $\\vec{a} = (5; 3), \\vec{b} = (4; 2), \\vec{c} = (2; 0)$. Phân tích vectơ $\\vec{c}$ theo hai vectơ $\\vec{a}$ và $\\vec{b}$ ta được:",
    options: [
      "A. $\\vec{c} = 2\\vec{a} - 3\\vec{b}$",
      "B. $\\vec{c} = -2\\vec{a} + 3\\vec{b}$",
      "C. $\\vec{c} = \\vec{a} - \\vec{b}$",
      "D. $\\vec{c} = \\vec{a} - 2\\vec{b}$"
    ],
    answer: "B",
    solution: "Giải hệ: $5x + 4y = 2; 3x + 2y = 0 \\implies x = -2, y = 3 \\implies \\vec{c} = -2\\vec{a} + 3\\vec{b}$."
  },
  {
    id: 18,
    question: "Trong mặt phẳng tọa độ $Oxy$, biết $A(3; -2), B(10; 0)$. Độ dài của vectơ $\\vec{AB}$ là:",
    options: ["A. $\\sqrt{53}$", "B. $3\\sqrt{5}$", "C. $\\sqrt{5}$", "D. 3"],
    answer: "A",
    solution: "$AB = \\sqrt{(10 - 3)^2 + (0 - (-2))^2} = \\sqrt{7^2 + 2^2} = \\sqrt{53}$."
  },
  {
    id: 19,
    question: "Cho tam giác $ABC$ vuông cân tại $A$ có $AB = 1$. Tính bình phương độ dài $|\vec{AB} + \vec{AC}|$.",
    options: ["A. $\\sqrt{2}$", "B. $\\frac{\\sqrt{2}}{2}$", "C. 2", "D. 4"],
    answer: "C",
    solution: "Vì tam giác vuông cân tại $A$ nên $\\vec{AB}\\perp\\vec{AC} \\implies |\\vec{AB} + \\vec{AC}|^2 = AB^2 + AC^2 = 1^2 + 1^2 = 2$."
  },
  {
    id: 20,
    question: "Cho hình vuông $ABCD$ có cạnh bằng 3. Tính độ dài của vectơ $\\vec{AC} + \\vec{BD}$.",
    options: ["A. 6", "B. $6\\sqrt{2}$", "C. 12", "D. 0"],
    answer: "A",
    solution: "$\\vec{AC} + \\vec{BD} = (\\vec{AB} + \\vec{BC}) + (\\vec{BA} + \\vec{AD}) = \\vec{BC} + \\vec{AD} = 2\\vec{AD} \\implies$ độ dài bằng $2 \\times 3 = 6$."
  },
  {
    id: 21,
    question: "Cho hình chữ nhật $ABCD$ biết $AB = 4, AD = 3$. Gọi $O$ là giao điểm của hai đường chéo $AC$ và $BD$. Xét các mệnh đề sau: a) $\\vec{OB}$ không cùng phương với $\\vec{BD}$; b) $\\vec{OA} = -\\frac{1}{2}\\vec{AC}$; c) $\\vec{BA} + \\vec{BC} = \\vec{BO} + \\vec{OD}$; d) $|\\vec{BA} + \\vec{BC}| = 5$. Có bao nhiêu mệnh đề đúng?",
    options: ["A. 1", "B. 2", "C. 3", "D. 4"],
    answer: "C",
    solution: "Mệnh đề a sai (vì O thuộc BD nên cùng phương); Mệnh đề b đúng; Mệnh đề c đúng (vì cả hai đều bằng $\\vec{BD}$); Mệnh đề d đúng (bằng $BD = \\sqrt{4^2+3^2}=5$). Có 3 mệnh đề đúng."
  },
  {
    id: 22,
    question: "Xét bất phương trình $x + 2y \\le 6$. Xét các mệnh đề sau: a) Đường biên $x + 2y = 6$ được vẽ bằng nét liền; b) Gốc tọa độ thuộc miền nghiệm; c) Điểm $(6; 1)$ thuộc miền nghiệm; d) Miền nghiệm không chứa gốc tọa độ. Có bao nhiêu mệnh đề đúng?",
    options: ["A. 1", "B. 2", "C. 3", "D. 4"],
    answer: "B",
    solution: "Mệnh đề a đúng (có dấu $\\le$); b đúng ($0 \\le 6$); c sai ($6 + 2 = 8 > 6$); d sai. Vậy có 2 mệnh đề đúng."
  },
  {
    id: 23,
    question: "Một kho chứa hai loại kiện hàng, mỗi kiện loại A nặng 2 kg và mỗi kiện loại B nặng 5 kg. Nếu tổng khối lượng hàng phải nhỏ hơn 300 kg, với $x, y$ là số kiện tương ứng, điều kiện đúng là:",
    options: ["A. $2x + 5y < 300$", "B. $2x + 5y \\le 300$", "C. $5x + 2y < 300$", "D. $2x + 5y > 300$"],
    answer: "A",
    solution: "Vì đề bài ghi 'nhỏ hơn 300 kg' nên bất phương trình là $2x + 5y < 300$."
  },
  {
    id: 24,
    question: "Một chương trình bán vé người lớn giá 80 nghìn đồng/vé và vé học sinh giá 50 nghìn đồng/vé. Gọi $x, y$ lần lượt là số vé người lớn và vé học sinh. Để doanh thu đạt ít nhất 6 triệu đồng, điều kiện tương đương là:",
    options: ["A. $8x + 5y \\ge 600$", "B. $8x + 5y \\le 600$", "C. $5x + 8y \\ge 600$", "D. $80x + 50y < 6000$"],
    answer: "A",
    solution: "$80x + 50y \\ge 6000 \\iff 8x + 5y \\ge 600$."
  },
  {
    id: 25,
    question: "Một quầy sách bán sách loại A giá 25 nghìn đồng/quyển và loại B giá 40 nghìn đồng/quyển. Quầy cần doanh thu ít nhất 2000 nghìn đồng. Gọi $x, y$ là số sách hai loại bán được. Nếu không bán sách loại A thì cần bán ít nhất bao nhiêu quyển loại B?",
    options: ["A. 50", "B. 25", "C. 30", "D. 40"],
    answer: "A",
    solution: "Khi $x = 0$, ta có $40y \\ge 2000 \\iff y \\ge 50$. Cần bán ít nhất 50 quyển loại B."
  },
  {
    id: 26,
    question: "Một gian hàng bán hai loại sản phẩm: Loại A lãi 30 nghìn đồng, loại B lãi 45 nghìn đồng. Để doanh thu đạt ít nhất 1800 nghìn đồng thì $x, y$ phải thỏa mãn:",
    options: ["A. $2x + 3y \\le 120$", "B. $3x + 2y \\ge 120$", "C. $2x + 3y \\ge 120$", "D. $30x + 45y < 1800$"],
    answer: "C",
    solution: "$30x + 45y \\ge 1800 \\iff 2x + 3y \\ge 120$."
  },
  {
    id: 27,
    question: "Trong một cuộc thi pha chế, mỗi đội được dùng tối đa 24g hương liệu, 9 lít nước và 210g đường. Pha 1 lít nước ngọt I cần 10g đường, 1 lít nước, 4g hương liệu (thưởng 80 điểm). Pha 1 lít loại II cần 30g đường, 1 lít nước, 1g hương liệu (thưởng 60 điểm). Điểm thưởng cao nhất mỗi đội có thể đạt là:",
    options: ["A. 540", "B. 600", "C. 640", "D. 720"],
    answer: "C",
    solution: "Hệ: $x + y \\le 9; 10x + 30y \\le 210; 4x + y \\le 24$. Giao $x + y = 9$ và $4x + y = 24 \\implies x = 5, y = 4$. Khi đó $F = 80(5) + 60(4) = 400 + 240 = 640$ điểm."
  },
  {
    id: 28,
    question: "Có bao nhiêu giá trị nguyên dương của tham số $m$ để điểm $M(m; 1)$ thuộc miền nghiệm của hệ $\\begin{cases} x - y \\le 2 \\\\ 2x + y > 0 \\end{cases}$?",
    options: ["A. 5", "B. 3", "C. 4", "D. 1"],
    answer: "B",
    solution: "Thay $(m; 1)$: $m - 1 \\le 2 \\iff m \\le 3$; $2m + 1 > 0 \\iff m > -0.5$. Vì $m$ nguyên dương nên $m \\in \\{1; 2; 3\\}$. Có 3 giá trị."
  },
  {
    id: 29,
    question: "Cho hai lực $F_1 = F_2 = 100\\text{ N}$ có điểm đặt tại $O$ và tạo với nhau góc $60^\\circ$. Cường độ lực tổng hợp của hai lực ấy bằng bao nhiêu?",
    options: ["A. $100\\text{ N}$", "B. $50\\sqrt{3}\\text{ N}$", "C. $100\\sqrt{3}\\text{ N}$", "D. $200\\text{ N}$"],
    answer: "C",
    solution: "$F^2 = 100^2 + 100^2 + 2(100)(100)\\cos 60^\\circ = 30000 \\implies F = 100\\sqrt{3}\\text{ N}$."
  },
  {
    id: 30,
    question: "Cho ba lực $\\vec{F}_1 = \\vec{MA}, \\vec{F}_2 = \\vec{MB}, \\vec{F}_3 = \\vec{MC}$ cùng tác động vào một vật tại điểm $M$ và vật đứng yên. Cho biết cường độ của $\\vec{F}_1, \\vec{F}_2$ đều bằng $25\\text{ N}$ và $\\widehat{AMB} = 60^\\circ$. Khi đó cường độ của lực $\\vec{F}_3$ là:",
    options: ["A. $100\\sqrt{3}\\text{ N}$", "B. $25\\sqrt{3}\\text{ N}$", "C. $50\\sqrt{3}\\text{ N}$", "D. $50\\sqrt{2}\\text{ N}$"],
    answer: "B",
    solution: "Vật đứng yên nên $\\vec{F}_3 = -(\\vec{F}_1 + \\vec{F}_2) \\implies |\\vec{F}_3| = |\\vec{F}_1 + \\vec{F}_2| = 2(25)\\cos 30^\\circ = 25\\sqrt{3}\\text{ N}$."
  },
  {
    id: 31,
    question: "Cho tam giác đều $ABC$ có cạnh bằng 2. Bình phương độ dài của vectơ $2\\vec{AB} + 3\\vec{AC}$ bằng:",
    options: ["A. $2\\sqrt{19}$", "B. $2\\sqrt{7}$", "C. 76", "D. 28"],
    answer: "C",
    solution: "$|2\\vec{AB} + 3\\vec{AC}|^2 = 4AB^2 + 9AC^2 + 12\\vec{AB}\\cdot\\vec{AC} = 4(4) + 9(4) + 12(2 \\times 2 \\times 0.5) = 16 + 36 + 24 = 76$."
  },
  {
    id: 32,
    question: "Trong mặt phẳng $Oxy$, cho bốn điểm $A(-1; -1), B(1; 0), C(2; 3), D(6; 1)$. Biết $\\vec{AD} = m\\vec{AB} + n\\vec{AC}$. Tính tổng $m + n$:",
    options: ["A. 5", "B. 3.8", "C. -5", "D. -3.8"],
    answer: "B",
    solution: "$\\vec{AB} = (2; 1), \\vec{AC} = (3; 4), \\vec{AD} = (7; 2)$. Giải hệ $2m + 3n = 7; m + 4n = 2 \\implies m = 4.4; n = -0.6 \\implies m + n = 3.8$."
  },
  {
    id: 33,
    question: "Trong mặt phẳng $Oxy$, cho tam giác $ABC$ với $A(2; 1), B(-3; 4), C(1; 7)$. Gọi $G$ là trọng tâm của tam giác. Hai số thực $m, n$ thỏa mãn $m\\vec{AB} + n\\vec{AC} = \\vec{OG}$. Tính $27(m + n)$.",
    options: ["A. 24", "B. 16", "C. 16", "D. -24"],
    answer: "B",
    solution: "Trọng tâm $G(0; 4) \\implies \\vec{OG} = (0; 4)$. $\\vec{AB} = (-5; 3), \\vec{AC} = (-1; 6)$. Ta có $-5m - n = 0; 3m + 6n = 4 \\implies m = -4/27; n = 20/27 \\implies m + n = 16/27 \\implies 27(m + n) = 16$."
  },
  {
    id: 34,
    question: "Trong mặt phẳng $Oxy$, cho các điểm $A(-3; 3), B(1; 4), C(2; -5)$. Tọa độ điểm $M$ thỏa mãn $2\\vec{MA} - \\vec{BC} = 4\\vec{CM}$ là:",
    options: ["A. $M(\\frac{1}{6}; \\frac{5}{6})$", "B. $M(-\\frac{1}{6}; -\\frac{5}{6})$", "C. $M(\\frac{1}{6}; -\\frac{5}{6})$", "D. $M(\\frac{5}{6}; -\\frac{1}{6})$"],
    answer: "C",
    solution: "$2\\vec{MA} - \\vec{BC} = 4\\vec{CM} \\iff 6\\vec{OM} = 2\\vec{OA} + \\vec{OB} + 3\\vec{OC} \\implies x_M = \\frac{2(-3) + 1 + 3(2)}{6} = \\frac{1}{6}; y_M = \\frac{2(3) + 4 + 3(-5)}{6} = -\\frac{5}{6} \\implies M(\\frac{1}{6}; -\\frac{5}{6})$."
  },
  {
    id: 35,
    question: "Trên màn hình radar kiểm soát không lưu (hệ trục tọa độ $Oxy$, đơn vị: km), hai máy bay đang ở vị trí $A(-1; 2)$ và $B(5; -4)$. Trạm điều khiển yêu cầu drone tiếp nhiên liệu bay đến vị trí $M$ nằm trên đoạn thẳng $AB$ sao cho khoảng cách từ $M$ đến $A$ gấp đôi khoảng cách từ $M$ đến $B$ ($MA = 2MB$). Tọa độ vị trí $M$ là:",
    options: ["A. $(3; -2)$", "B. $(11; -10)$", "C. $(1; 0)$", "D. $(2; -1)$"],
    answer: "A",
    solution: "Vì $M$ nằm trên đoạn $AB$ và $MA = 2MB$ nên $\\vec{AM} = \\frac{2}{3}\\vec{AB}$. Với $\\vec{AB} = (6; -6) \\implies \\vec{AM} = (4; -4) \\implies M(-1 + 4; 2 - 4) = (3; -2)$."
  },
  {
    id: 36,
    question: "Cho hình bình hành $ABCD$. Gọi $I$ là trung điểm của $CD$, $G$ là trọng tâm tam giác $BCI$. Đặt $\\vec{a} = \\vec{AB}, \\vec{b} = \\vec{AD}$. Khẳng định nào sau đây đúng?",
    options: [
      "A. $\\vec{AG} = \\frac{5}{6}\\vec{a} + \\frac{2}{3}\\vec{b}$",
      "B. $\\vec{AG} = \\frac{5}{6}\\vec{a} + \\vec{b}$",
      "C. $\\vec{AG} = \\vec{a} + \\frac{5}{6}\\vec{b}$",
      "D. $\\vec{AG} = \\frac{4}{3}\\vec{a} + \\frac{2}{3}\\vec{b}$"
    ],
    answer: "A",
    solution: "$\\vec{AG} = \\frac{1}{3}(\\vec{AB} + \\vec{AC} + \\vec{AI}) = \\frac{1}{3}(\\vec{a} + (\\vec{a} + \\vec{b}) + (\\vec{b} + \\frac{1}{2}\\vec{a})) = \\frac{5}{6}\\vec{a} + \\frac{2}{3}\\vec{b}$."
  },
  {
    id: 37,
    question: "Cho tam giác $ABC$ có trọng tâm $G$. Gọi các điểm $D, E, F$ lần lượt là trung điểm của các cạnh $BC, CA$ và $AB$. Khẳng định nào đúng?",
    options: [
      "A. $\\vec{AG} = \\frac{1}{2}\\vec{AE} + \\frac{1}{2}\\vec{AF}$",
      "B. $\\vec{AG} = \\frac{1}{3}\\vec{AE} + \\frac{1}{3}\\vec{AF}$",
      "C. $\\vec{AG} = \\frac{3}{2}\\vec{AE} + \\frac{3}{2}\\vec{AF}$",
      "D. $\\vec{AG} = \\frac{2}{3}\\vec{AE} + \\frac{2}{3}\\vec{AF}$"
    ],
    answer: "D",
    solution: "$\\vec{AG} = \\frac{2}{3}\\vec{AD} = \\frac{2}{3}(\\frac{1}{2}\\vec{AB} + \\frac{1}{2}\\vec{AC}) = \\frac{2}{3}(\\vec{AF} + \\vec{AE}) = \\frac{2}{3}\\vec{AE} + \\frac{2}{3}\\vec{AF}$."
  },
  {
    id: 38,
    question: "Trong hệ trục tọa độ $Oxy$, cho bốn điểm $A(2; -3), B(0; 4), C(3; 0)$ và $D(3; 3)$. Gọi $M$ là điểm thuộc trục $Oy$ sao cho biểu thức $|\\vec{MA} + \\vec{MB} + \\vec{MC} + \\vec{MD}|$ đạt giá trị nhỏ nhất. Tọa độ của $M$ là:",
    options: ["A. $M(0; -1)$", "B. $M(2; 1)$", "C. $M(2; 0)$", "D. $M(0; 1)$"],
    answer: "D",
    solution: "Gọi $I$ là trọng tâm của 4 điểm: $x_I = \\frac{2 + 0 + 3 + 3}{4} = 2; y_I = \\frac{-3 + 4 + 0 + 3}{4} = 1 \\implies I(2; 1)$. Tổng vectơ bằng $4\\vec{MI}$. Độ dài nhỏ nhất khi $M$ là hình chiếu vuông góc của $I$ lên trục $Oy \\implies M(0; 1)$."
  },
  {
    id: 39,
    question: "Trong hệ trục tọa độ $Oxy$, cho ba điểm $A(0; -2), B(-2; -4), C(1; 3)$. Tìm điểm $M$ sao cho biểu thức $MA^2 + MB^2 + 2MC^2$ đạt giá trị nhỏ nhất.",
    options: ["A. $M(0; 0)$", "B. $M(-\\frac{1}{2}; -\\frac{1}{2})$", "C. $M(2; 2)$", "D. $M(-2; -2)$"],
    answer: "A",
    solution: "Gọi $I$ là tâm tỉ cự thỏa mãn $\\vec{IA} + \\vec{IB} + 2\\vec{IC} = \\vec{0}$. Khi đó $x_I = \\frac{0 + (-2) + 2(1)}{4} = 0; y_I = \\frac{-2 + (-4) + 2(3)}{4} = 0 \\implies I(0; 0)$. Biểu thức đạt giá trị nhỏ nhất khi $M \\equiv I(0; 0)$."
  },
  {
    id: 40,
    question: "Trong hệ tọa độ $Oxy$, cho điểm $A(1; 3)$ và $B(4; 7)$. Tìm điểm $M$ trên trục $Oy$ sao cho $MA + MB$ là nhỏ nhất.",
    options: ["A. $M(0; \\frac{19}{5})$", "B. $M(0; \\frac{1}{5})$", "C. $M(0; \\frac{3}{5})$", "D. $M(0; \\frac{11}{5})$"],
    answer: "A",
    solution: "Vì $A, B$ cùng phía so với $Oy$ ($x_A, x_B > 0$), lấy điểm đối xứng của $A$ qua $Oy$ là $A'(-1; 3)$. Khi đó $MA + MB = MA' + MB \\ge A'B$. Dấu '=' xảy ra khi $M = A'B \\cap Oy$. Đường thẳng $A'B$ đi qua $A'(-1; 3)$ và $B(4; 7)$ có phương trình $4x - 5y + 19 = 0$. Giao điểm với $Oy$ ($x = 0$) cho $y = \\frac{19}{5} \\implies M(0; \\frac{19}{5})$."
  }
];

// Helper to create exam objects
function createExam(code, title, p1Questions, p2Questions, p3Questions) {
  return {
    id: code,
    code: code,
    title: title,
    timeMinutes: 90,
    part1: p1Questions,
    part2: p2Questions,
    part3: p3Questions
  };
}

// Generate 12 varied exams (Mã đề: 1001 đến 1012)
const generatedExams = [];

// Codes: 1001, 1002, 1003, 1004, 1005, 1006, 1007, 1008, 1009, 1010, 1011, 1012
const examCodes = [
  "1001", "1002", "1003", "1004", "1005", "1006",
  "1007", "1008", "1009", "1010", "1011", "1012"
];

examCodes.forEach((code, index) => {
  // Select 12 questions for Part 1 from bank40 with a pseudo-random rotation
  const p1 = [];
  for (let i = 0; i < 12; i++) {
    const qIndex = (index * 3 + i) % bank40.length;
    const baseQ = bank40[qIndex];
    p1.push({
      id: i + 1,
      question: baseQ.question,
      options: baseQ.options,
      answer: baseQ.answer,
      solution: baseQ.solution
    });
  }

  // Part 2: 4 True/False multi-part questions
  const p2 = [
    {
      id: 1,
      question: `Cho bất phương trình bậc nhất hai ẩn: ${index % 2 === 0 ? 'x - 2y > 4' : '3x - 2y \\le 6'}. Xét tính đúng, sai của các mệnh đề sau:`,
      statements: [
        { id: "a", text: `Đường thẳng biên của miền nghiệm có phương trình là ${index % 2 === 0 ? 'x - 2y - 4 = 0' : '3x - 2y - 6 = 0'}.`, answer: true, solution: "Đúng theo định nghĩa đường thẳng biên." },
        { id: "b", text: `Gốc tọa độ O(0; 0) thuộc miền nghiệm của bất phương trình.`, answer: index % 2 !== 0, solution: index % 2 === 0 ? "Thay (0; 0) vào bất phương trình ta thấy sai." : "Thay (0; 0) vào thỏa mãn 0 <= 6." },
        { id: "c", text: `Điểm M(2; 1) thuộc miền nghiệm của bất phương trình.`, answer: index % 2 !== 0, solution: index % 2 === 0 ? "2 - 2(1) = 0 không lớn hơn 4." : "3(2) - 2(1) = 4 <= 6 (đúng)." },
        { id: "d", text: `Miền nghiệm là nửa mặt phẳng kể cả bờ.`, answer: index % 2 !== 0, solution: index % 2 === 0 ? "Bất phương trình mang dấu '>' nên không kể bờ." : "Bất phương trình mang dấu '<=' nên kể cả bờ." }
      ]
    },
    {
      id: 2,
      question: "Một cơ sở sản xuất đồ gỗ làm bàn và ghế. Một cái bàn cần 1.5 giờ công cắt và 1 giờ công lắp ráp; một cái ghế cần 1 giờ công cắt và 2 giờ công lắp ráp. Thời gian cắt tối đa là 15 giờ, thời gian lắp ráp tối đa là 20 giờ. Gọi x, y lần lượt là số bàn và ghế sản xuất. Xét tính đúng, sai:",
      statements: [
        { id: "a", text: "Điều kiện của x và y là x >= 0, y >= 0.", answer: true, solution: "Số bàn và số ghế là số không âm." },
        { id: "b", text: "Điều kiện về thời gian cắt là 1.5x + y <= 15.", answer: true, solution: "Đúng theo lượng thời gian cắt tối đa 15 giờ." },
        { id: "c", text: "Nếu lãi mỗi cái bàn là 300 nghìn, mỗi cái ghế là 200 nghìn thì hàm mục tiêu lợi nhuận là F = 300x + 200y.", answer: true, solution: "Hàm mục tiêu chuẩn." },
        { id: "d", text: "Phương án tối ưu đem lại lợi nhuận cao nhất đạt 3 triệu đồng.", answer: true, solution: "Đỉnh tối ưu đạt giá trị F = 3000 nghìn đồng = 3 triệu đồng." }
      ]
    },
    {
      id: 3,
      question: "Cho tam giác ABC có trọng tâm G. Gọi M, N lần lượt là trung điểm của AB và AC. Xét tính đúng, sai của các mệnh đề sau:",
      statements: [
        { id: "a", text: "$\\vec{MN} = \\frac{1}{2}\\vec{BC}$.", answer: true, solution: "Đường trung bình tam giác cùng hướng và bằng nửa đáy." },
        { id: "b", text: "$\\vec{GA} + \\vec{GB} + \\vec{GC} = \\vec{0}$.", answer: true, solution: "Tính chất trọng tâm tam giác chuẩn." },
        { id: "c", text: "$\\vec{BM} = \\vec{MA}$.", answer: true, solution: "M là trung điểm AB nên hai vectơ bằng nhau." },
        { id: "d", text: "$|\\vec{AB} + \\vec{AC}| = 3|\\vec{AG}|$.", answer: true, solution: "Vì $\\vec{AB} + \\vec{AC} = 3\\vec{AG}$ nên độ dài bằng nhau." }
      ]
    },
    {
      id: 4,
      question: "Trong hệ tọa độ Oxy, cho ba điểm A(2; 1), B(0; -3), C(3; 1). Xét tính đúng, sai của các mệnh đề sau:",
      statements: [
        { id: "a", text: "Tọa độ vectơ $\\vec{AB} = (-2; -4)$.", answer: true, solution: "$\\vec{AB} = (0 - 2; -3 - 1) = (-2; -4)$." },
        { id: "b", text: "Độ dài đoạn thẳng AB bằng $2\\sqrt{5}$.", answer: true, solution: "$AB = \\sqrt{(-2)^2 + (-4)^2} = \\sqrt{20} = 2\\sqrt{5}$." },
        { id: "c", text: "Tọa độ trung điểm I của đoạn thẳng BC là $(1.5; -1)$.", answer: true, solution: "$x = (0+3)/2 = 1.5; y = (-3+1)/2 = -1$." },
        { id: "d", text: "Tọa độ điểm D để tứ giác ABCD là hình bình hành là D(5; 5).", answer: true, solution: "$\\vec{DC} = \\vec{AB} \\implies D(5; 5)$." }
      ]
    }
  ];

  // Part 3: 6 Short Answer questions (Advanced application questions from bank)
  // Rotating advanced questions: Câu 27 (pha chế 640), Câu 31 (76), Câu 32 (3.8), Câu 33 (16), Câu 35 (drone 3), Câu 38 (1), Câu 39 (0), Câu 40 (3.8)
  const p3 = [
    {
      id: 1,
      question: "Trong một cuộc thi pha chế, mỗi đội được sử dụng tối đa 24 gam hương liệu, 9 lít nước và 210 gam đường để pha chế nước ngọt loại I và loại II. Mỗi lít nước ngọt loại I được 80 điểm thưởng, mỗi lít loại II được 60 điểm thưởng (cần 10g đường, 1L nước, 4g hương liệu cho loại I; 30g đường, 1L nước, 1g hương liệu cho loại II). Hỏi số điểm thưởng cao nhất có thể đạt được là bao nhiêu?",
      answer: "640",
      solution: "Giao điểm tối ưu là x = 5 lít loại I và y = 4 lít loại II. Số điểm thưởng cao nhất là 80(5) + 60(4) = 640 điểm."
    },
    {
      id: 2,
      question: "Cho tam giác đều ABC có cạnh bằng 2. Tính bình phương độ dài của vectơ $\\vec{u} = 2\\vec{AB} + 3\\vec{AC}$.",
      answer: "76",
      solution: "$|\\vec{u}|^2 = 4AB^2 + 9AC^2 + 12\\vec{AB}\\cdot\\vec{AC} = 4(4) + 9(4) + 12(2 \\times 2 \\times 0.5) = 16 + 36 + 24 = 76$."
    },
    {
      id: 3,
      question: "Trong mặt phẳng tọa độ Oxy, cho bốn điểm A(-1; -1), B(1; 0), C(2; 3), D(6; 1). Biết phân tích $\\vec{AD} = m\\vec{AB} + n\\vec{AC}$. Hãy tính giá trị của tổng $m + n$.",
      answer: "3.8",
      solution: "$\\vec{AB} = (2; 1), \\vec{AC} = (3; 4), \\vec{AD} = (7; 2)$. Giải hệ phương trình ta được m = 4.4 và n = -0.6. Tổng m + n = 4.4 - 0.6 = 3.8."
    },
    {
      id: 4,
      question: "Trên màn hình radar kiểm soát không lưu Oxy, hai máy bay ở vị trí A(-1; 2) và B(5; -4). Trạm điều khiển yêu cầu drone tiếp nhiên liệu bay đến vị trí điểm M trên đoạn AB sao cho MA = 2MB. Tìm hoành độ của điểm M.",
      answer: "3",
      solution: "$\\vec{AM} = \\frac{2}{3}\\vec{AB} = \\frac{2}{3}(6; -6) = (4; -4) \\implies M(3; -2)$. Hoành độ của M là 3."
    },
    {
      id: 5,
      question: "Trong hệ trục tọa độ Oxy, cho ba điểm A(0; -2), B(-2; -4), C(1; 3). Tìm tung độ của điểm M sao cho biểu thức $MA^2 + MB^2 + 2MC^2$ đạt giá trị nhỏ nhất.",
      answer: "0",
      solution: "Điểm M trùng với tâm tỉ cự I(0; 0) của hệ điểm. Do đó tung độ của M là 0."
    },
    {
      id: 6,
      question: "Trong hệ tọa độ Oxy, cho hai điểm A(1; 3) và B(4; 7). Tìm tung độ của điểm M trên trục Oy sao cho tổng khoảng cách $MA + MB$ đạt giá trị nhỏ nhất (làm tròn hoặc viết dạng số thập phân).",
      answer: "3.8",
      solution: "Lấy đối xứng của A qua Oy là A'(-1; 3). Đường thẳng A'B cắt Oy tại M(0; 19/5). Tung độ của điểm M là 19/5 = 3.8."
    }
  ];

  generatedExams.push(createExam(
    code,
    `ĐỀ THI TẬP TRUNG TOÁN 10 - MÃ ĐỀ ${code}`,
    p1,
    p2,
    p3
  ));
});

const fileContent = `// Ngân hàng Đề Thi Trắc Nghiệm Môn Toán 10 (Chương trình mới GDPT 2018)
// Tuyển chọn các câu hỏi KTTT lần 3 và các câu vận dụng cao thực tế

window.EXAM_DATA = ${JSON.stringify(generatedExams, null, 2)};
`;

fs.writeFileSync(path.join(__dirname, 'data', 'exams.js'), fileContent, 'utf8');
console.log(`Successfully generated ${generatedExams.length} complete exams in data/exams.js!`);
