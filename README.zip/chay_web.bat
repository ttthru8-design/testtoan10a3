@echo off
title He Thong Luyen Thi Trac Nghiem Toan 10 OMR
echo ========================================================
echo   HE THONG THI TRAC NGHIEM TOAN 10 - PHIEU TO OMR
echo   Chuong trinh GDPT moi 2018 - KTTT Lan 3
echo ========================================================
echo.
echo Dang mo ung dung tren trinh duyet...
start index.html
echo.
echo Da khoi chay thanh cong! Ban co the lam bai truc tiep.
pause
