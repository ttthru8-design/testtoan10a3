// Antigravity OMR Online Exam Application Logic (Upgraded Version)
// Authentic Examination Flow: Lobby -> Randomized Exam Ticket -> Blank OMR Sheet -> Bubble-in Code to Unlock -> Real-time Grading

(function () {
  'use strict';

  // Global App State
  const state = {
    // Current Screen: 'lobby' | 'exam'
    currentScreen: 'lobby',

    // Assigned ticket for this exam session
    assignedTicket: {
      name: "",
      className: "",
      sbd: "",
      targetCode: "" // The randomly drawn exam code (e.g. "1005")
    },

    // OMR Sheet State
    omrState: {
      studentName: "",
      studentClass: "",
      sbdDigits: ["", "", "", "", "", ""],      // 6 columns
      codeDigits: ["", "", "", ""],            // 4 columns (must be bubbled by student!)
      isCodeUnlocked: false                    // true when codeDigits matches targetCode
    },

    // Student Answers
    answers: {
      part1: {}, // questionId -> 'A' | 'B' | 'C' | 'D'
      part2: {}, // questionId -> { a: boolean, b: boolean, c: boolean, d: boolean }
      part3: {}  // questionId -> string
    },

    isSubmitted: false,
    results: null,

    timer: {
      totalSeconds: 90 * 60,
      remainingSeconds: 90 * 60,
      intervalId: null,
      isRunning: false
    },

    settings: {
      fontSize: 15,
      soundEnabled: true
    }
  };

  // Sound effects using Web Audio API
  const audioContext = window.AudioContext || window.webkitAudioContext ? new (window.AudioContext || window.webkitAudioContext)() : null;
  function playBeep(freq = 600, duration = 0.05, type = 'sine') {
    if (!state.settings.soundEnabled || !audioContext) return;
    try {
      if (audioContext.state === 'suspended') audioContext.resume();
      const osc = audioContext.createOscillator();
      const gain = audioContext.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, audioContext.currentTime);
      gain.gain.setValueAtTime(0.08, audioContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + duration);
      osc.connect(gain);
      gain.connect(audioContext.destination);
      osc.start();
      osc.stop(audioContext.currentTime + duration);
    } catch (e) {}
  }

  function playSuccessChime() {
    if (!state.settings.soundEnabled) return;
    playBeep(523, 0.1);
    setTimeout(() => playBeep(659, 0.1), 100);
    setTimeout(() => playBeep(784, 0.15), 200);
  }

  // Get list of all available exams
  function getAvailableExams() {
    return window.EXAM_DATA || [];
  }

  // Get current exam object based on targetCode
  function getCurrentExam() {
    const exams = getAvailableExams();
    let exam = exams.find(e => e.code === state.assignedTicket.targetCode);
    if (!exam && exams.length > 0) {
      exam = exams[0];
    }
    return exam;
  }

  // Generate random 6-digit SBD
  function generateRandomSbd() {
    return String(Math.floor(100000 + Math.random() * 900000));
  }

  // Initialize
  function init() {
    setupLobbyEvents();
    setupExamRoomEvents();
    loadProfileFromStorage();
    renderLobbyExamList();
  }

  function loadProfileFromStorage() {
    try {
      const saved = JSON.parse(localStorage.getItem('omr_student_profile') || '{}');
      if (saved.name) {
        const nameInput = document.getElementById('lobbyNameInput');
        if (nameInput) nameInput.value = saved.name;
      }
      if (saved.className) {
        const classInput = document.getElementById('lobbyClassInput');
        if (classInput) classInput.value = saved.className;
      }
    } catch (e) {}
  }

  function renderLobbyExamList() {
    const listEl = document.getElementById('lobbyExamsList');
    if (!listEl) return;
    const exams = getAvailableExams();
    listEl.innerHTML = exams.map(e => `
      <span class="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-mono font-bold bg-blue-50 text-blue-700 border border-blue-200">
        Mã ${e.code}
      </span>
    `).join(' ');
  }

  // Setup Lobby Events
  function setupLobbyEvents() {
    const startBtn = document.getElementById('lobbyStartBtn');
    if (startBtn) {
      startBtn.addEventListener('click', () => handleStartExam(false));
    }

    const quickStartBtn = document.getElementById('lobbyQuickStartBtn');
    if (quickStartBtn) {
      quickStartBtn.addEventListener('click', () => {
        handleStartExam(true);
      });
    }

    // Modal Admission Ticket Confirm Button
    const confirmTicketBtn = document.getElementById('confirmTicketBtn');
    if (confirmTicketBtn) {
      confirmTicketBtn.addEventListener('click', enterExamRoom);
    }
  }

  // Start Exam Flow
  function handleStartExam(autoFillName = false) {
    const nameInput = document.getElementById('lobbyNameInput');
    const classInput = document.getElementById('lobbyClassInput');

    let name = nameInput ? nameInput.value.trim() : "";
    let className = classInput ? classInput.value.trim() : "";

    if (!name) {
      if (autoFillName) {
        name = "Thí sinh tự do";
        className = "10A1";
      } else {
        alert("Vui lòng nhập Họ và tên thí sinh để đăng ký dự thi!");
        if (nameInput) nameInput.focus();
        return;
      }
    }
    if (!className) className = "10A";

    // Save to profile
    localStorage.setItem('omr_student_profile', JSON.stringify({ name, className }));

    // Pick a random exam code from available exams!
    const exams = getAvailableExams();
    if (exams.length === 0) {
      alert("Chưa nạp được dữ liệu đề thi! Vui lòng tải lại trang.");
      return;
    }
    const randomIndex = Math.floor(Math.random() * exams.length);
    const selectedExam = exams[randomIndex];
    const generatedSbd = generateRandomSbd();

    state.assignedTicket = {
      name: name,
      className: className,
      sbd: generatedSbd,
      targetCode: selectedExam.code
    };

    // Prepare fresh OMR state (blank bubbles)
    state.omrState = {
      studentName: name,
      studentClass: className,
      sbdDigits: ["", "", "", "", "", ""],
      codeDigits: ["", "", "", ""],
      isCodeUnlocked: false
    };

    state.answers = { part1: {}, part2: {}, part3: {} };
    state.isSubmitted = false;
    state.results = null;
    state.timer.remainingSeconds = 90 * 60;
    state.timer.isRunning = false;

    // Show Admission Ticket Modal
    showAdmissionModal();
  }

  function showAdmissionModal() {
    const ticket = state.assignedTicket;
    document.getElementById('ticketStudentName').innerText = ticket.name;
    document.getElementById('ticketStudentClass').innerText = ticket.className;
    document.getElementById('ticketSbd').innerText = ticket.sbd;
    document.getElementById('ticketExamCode').innerText = ticket.targetCode;

    const modal = document.getElementById('admissionModal');
    if (modal) {
      modal.classList.remove('hidden');
      modal.classList.add('flex');
    }
    playSuccessChime();
  }

  function enterExamRoom() {
    const modal = document.getElementById('admissionModal');
    if (modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }

    // Switch screen from Lobby to Exam Room
    document.getElementById('lobbyScreen').classList.add('hidden');
    document.getElementById('examRoomScreen').classList.remove('hidden');
    state.currentScreen = 'exam';

    // Update floating pin card
    updatePinBadge();

    // Render OMR Sheet (blank 4 digits code matrix)
    renderOmrSheet();

    // Render Exam Paper (Locked state)
    checkAndRenderExamPaper();

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
    showToast(`Đã phát mã đề [${state.assignedTicket.targetCode}]. Hãy tô 4 chữ số trên phiếu OMR để mở đề thi!`);
  }

  function updatePinBadge() {
    const ticket = state.assignedTicket;
    const badgeEl = document.getElementById('pinStudentInfo');
    if (badgeEl) {
      badgeEl.innerHTML = `
        <div class="flex flex-wrap items-center gap-2 text-xs">
          <span>Thí sinh: <b>${ticket.name}</b> (${ticket.className})</span>
          <span>• SBD: <b class="font-mono text-blue-700">${ticket.sbd}</b></span>
          <span>• Mã đề được phát: <b class="font-mono text-amber-600 bg-amber-50 px-2 py-0.5 rounded border border-amber-300 text-sm animate-pulse">${ticket.targetCode}</b></span>
        </div>
      `;
    }
  }

  // Check if student has bubbled the correct 4 digits code
  function checkAndRenderExamPaper() {
    const bubbledCode = state.omrState.codeDigits.join('');
    const targetCode = state.assignedTicket.targetCode;

    const sealedContainer = document.getElementById('examSealedNotice');
    const questionsContainer = document.getElementById('examQuestions');
    const examHeaderBadge = document.getElementById('examCodeBadge');
    const examTitleEl = document.getElementById('examTitle');

    if (bubbledCode === targetCode) {
      // CODE IS CORRECT -> UNLOCK EXAM!
      if (!state.omrState.isCodeUnlocked) {
        state.omrState.isCodeUnlocked = true;
        playSuccessChime();
        showToast("🎉 Mã đề chính xác! Đề thi đã mở niêm phong. Bắt đầu tính giờ làm bài.");
        startTimer();
      }

      if (sealedContainer) sealedContainer.classList.add('hidden');
      if (questionsContainer) questionsContainer.classList.remove('hidden');

      const exam = getCurrentExam();
      if (examTitleEl) examTitleEl.innerText = exam.title;
      if (examHeaderBadge) examHeaderBadge.innerText = `Mã đề: ${exam.code}`;

      renderQuestions(exam);
      renderMath();
    } else {
      // CODE NOT FILLED OR WRONG
      state.omrState.isCodeUnlocked = false;
      if (sealedContainer) sealedContainer.classList.remove('hidden');
      if (questionsContainer) questionsContainer.classList.add('hidden');

      const sealMsg = document.getElementById('sealStatusMessage');
      if (sealMsg) {
        if (bubbledCode.length === 4 && bubbledCode !== targetCode) {
          sealMsg.innerHTML = `
            <span class="text-rose-600 font-bold">⚠️ Mã đề bạn vừa tô là [${bubbledCode}], không khớp với mã đề bạn được phát là [${targetCode}]!</span><br>
            <span class="text-slate-500 text-xs">Hãy kiểm tra lại thẻ dự thi và tô lại đúng 4 cột số trên phiếu OMR.</span>
          `;
        } else {
          sealMsg.innerHTML = `
            <span class="text-slate-700 font-semibold">Đề thi đang được niêm phong.</span><br>
            <span class="text-slate-500 text-xs">Vui lòng dùng bút chì tô đúng 4 chữ số của Mã đề thi <b class="text-blue-600 font-mono text-sm">[${targetCode}]</b> vào Phiếu trả lời bên phải để mở khóa đề.</span>
          `;
        }
      }
    }

    updateProgress();
  }

  // Setup Exam Room Events
  function setupExamRoomEvents() {
    // Back to Lobby button
    const backBtn = document.getElementById('backToLobbyBtn');
    if (backBtn) {
      backBtn.addEventListener('click', () => {
        if (confirm("Bạn có muốn quay về Trang chủ? Toàn bộ tiến trình làm bài hiện tại sẽ kết thúc.")) {
          clearInterval(state.timer.intervalId);
          state.timer.isRunning = false;
          document.getElementById('examRoomScreen').classList.add('hidden');
          document.getElementById('lobbyScreen').classList.remove('hidden');
          state.currentScreen = 'lobby';
        }
      });
    }

    // Auto-fill code button (Helper for quick test)
    const autoFillCodeBtn = document.getElementById('autoFillCodeBtn');
    if (autoFillCodeBtn) {
      autoFillCodeBtn.addEventListener('click', () => {
        state.omrState.codeDigits = state.assignedTicket.targetCode.split('');
        state.omrState.sbdDigits = state.assignedTicket.sbd.split('');
        renderOmrSheet();
        checkAndRenderExamPaper();
      });
    }

    // New Exam / Draw Another Exam Code
    const drawNewExamBtn = document.getElementById('drawNewExamBtn');
    if (drawNewExamBtn) {
      drawNewExamBtn.addEventListener('click', () => {
        if (confirm("Bạn có muốn bốc một mã đề thi ngẫu nhiên mới?")) {
          handleStartExam(true);
        }
      });
    }

    // Submit Exam
    const submitBtn = document.getElementById('submitExamBtn');
    if (submitBtn) {
      submitBtn.addEventListener('click', () => submitExam(false));
    }

    // Timer pause/resume
    const pauseBtn = document.getElementById('pauseTimerBtn');
    if (pauseBtn) {
      pauseBtn.addEventListener('click', toggleTimerPause);
    }

    // Reset current exam answers
    const resetBtn = document.getElementById('resetExamBtn');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        if (confirm("Làm lại đề này từ đầu? Tất cả các câu trả lời sẽ được xóa trắng.")) {
          state.answers = { part1: {}, part2: {}, part3: {} };
          state.isSubmitted = false;
          state.results = null;
          state.timer.remainingSeconds = 90 * 60;
          renderOmrSheet();
          checkAndRenderExamPaper();
        }
      });
    }

    // Sound toggle
    const soundToggle = document.getElementById('soundToggleBtn');
    if (soundToggle) {
      soundToggle.addEventListener('click', () => {
        state.settings.soundEnabled = !state.settings.soundEnabled;
        soundToggle.innerHTML = state.settings.soundEnabled 
          ? `<i data-lucide="volume-2" class="w-4 h-4 text-emerald-600"></i>` 
          : `<i data-lucide="volume-x" class="w-4 h-4 text-slate-400"></i>`;
        if (window.lucide) window.lucide.createIcons();
        showToast(state.settings.soundEnabled ? "Đã bật âm thanh" : "Đã tắt âm thanh");
      });
    }

    // Font size controls
    const incFont = document.getElementById('incFontSizeBtn');
    const decFont = document.getElementById('decFontSizeBtn');
    if (incFont && decFont) {
      incFont.addEventListener('click', () => {
        state.settings.fontSize = Math.min(22, state.settings.fontSize + 1);
        document.getElementById('examPaperContainer').style.fontSize = `${state.settings.fontSize}px`;
      });
      decFont.addEventListener('click', () => {
        state.settings.fontSize = Math.max(13, state.settings.fontSize - 1);
        document.getElementById('examPaperContainer').style.fontSize = `${state.settings.fontSize}px`;
      });
    }

    // Print button
    const printBtn = document.getElementById('printExamBtn');
    if (printBtn) {
      printBtn.addEventListener('click', () => window.print());
    }

    // Close result modal
    const closeResBtn = document.getElementById('closeResultModalBtn');
    if (closeResBtn) {
      closeResBtn.addEventListener('click', () => {
        document.getElementById('resultModal').classList.add('hidden');
        document.getElementById('resultModal').classList.remove('flex');
      });
    }

    // View History Modal
    const historyBtn = document.getElementById('viewHistoryBtn');
    if (historyBtn) historyBtn.addEventListener('click', showHistoryModal);

    const closeHistoryBtn = document.getElementById('closeHistoryModalBtn');
    if (closeHistoryBtn) {
      closeHistoryBtn.addEventListener('click', () => {
        document.getElementById('historyModal').classList.add('hidden');
        document.getElementById('historyModal').classList.remove('flex');
      });
    }
  }

  // Render OMR Sheet
  function renderOmrSheet() {
    renderStudentInfoSection();
    renderPart1Omr();
    renderPart2Omr();
    renderPart3Omr();
  }

  // Render Information & 4-digit Code Matrix on OMR Sheet
  function renderStudentInfoSection() {
    const nameInput = document.getElementById('omrStudentName');
    if (nameInput) nameInput.value = state.omrState.studentName || state.assignedTicket.name;

    const classInput = document.getElementById('omrStudentClass');
    if (classInput) classInput.value = state.omrState.studentClass || state.assignedTicket.className;

    // Render 4-digit code matrix
    const codeContainer = document.getElementById('omrCodeMatrix');
    if (codeContainer) {
      const digits = state.omrState.codeDigits;
      
      let html = `
        <div class="border border-slate-300 rounded-lg p-2 bg-white">
          <div class="text-[11px] font-bold text-center text-slate-700 uppercase mb-1 tracking-wider flex items-center justify-center gap-1">
            <span>MÃ ĐỀ THI</span>
            ${state.omrState.isCodeUnlocked ? '<span class="text-emerald-600 text-xs font-bold">✓ ĐÃ MỞ</span>' : '<span class="text-amber-500 text-xs animate-pulse font-bold">● CẦN TÔ</span>'}
          </div>
          <!-- 4 Display boxes -->
          <div class="grid grid-cols-4 gap-1.5 mb-2">
            ${[0, 1, 2, 3].map(colIdx => `
              <div class="h-7 border-2 ${digits[colIdx] ? 'border-blue-600 bg-blue-50/50 text-blue-900' : 'border-slate-400 bg-slate-50 text-slate-300'} font-mono font-bold text-base flex items-center justify-center rounded">
                ${digits[colIdx] || '_'}
              </div>
            `).join('')}
          </div>
          <!-- 4 Columns of 0-9 Bubbles -->
          <div class="grid grid-cols-4 gap-1.5 text-center">
            ${[0, 1, 2, 3].map(colIdx => {
              const currentVal = digits[colIdx];
              return `
                <div class="flex flex-col gap-1 items-center">
                  ${[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => {
                    const isFilled = currentVal === String(num);
                    return `
                      <div data-code-col="${colIdx}" data-code-num="${num}"
                           class="code-bubble omr-bubble-sm ${isFilled ? 'filled' : ''}"
                           title="Cột ${colIdx + 1}: Số ${num}">
                        ${num}
                      </div>
                    `;
                  }).join('')}
                </div>
              `;
            }).join('')}
          </div>
        </div>
      `;
      codeContainer.innerHTML = html;

      codeContainer.querySelectorAll('[data-code-col]').forEach(b => {
        b.addEventListener('click', () => {
          if (state.isSubmitted) return;
          const col = parseInt(b.getAttribute('data-code-col'));
          const num = b.getAttribute('data-code-num');
          
          if (state.omrState.codeDigits[col] === num) {
            state.omrState.codeDigits[col] = "";
          } else {
            state.omrState.codeDigits[col] = num;
            playBeep(750, 0.04);
          }
          
          renderStudentInfoSection();
          checkAndRenderExamPaper();
        });
      });
    }

    // Render SBD matrix (6 columns)
    const sbdContainer = document.getElementById('omrSbdMatrix');
    if (sbdContainer) {
      const sbdDigits = state.omrState.sbdDigits;
      let html = `
        <div class="border border-slate-300 rounded-lg p-2 bg-white">
          <div class="text-[11px] font-bold text-center text-slate-700 uppercase mb-1 tracking-wider">
            SỐ BÁO DANH
          </div>
          <div class="grid grid-cols-6 gap-1 mb-2">
            ${[0, 1, 2, 3, 4, 5].map(colIdx => `
              <div class="h-7 border-2 ${sbdDigits[colIdx] ? 'border-slate-800 bg-slate-100 text-slate-900' : 'border-slate-300 bg-slate-50 text-slate-300'} font-mono font-bold text-xs flex items-center justify-center rounded">
                ${sbdDigits[colIdx] || '_'}
              </div>
            `).join('')}
          </div>
          <div class="grid grid-cols-6 gap-1 text-center">
            ${[0, 1, 2, 3, 4, 5].map(colIdx => {
              const currentVal = sbdDigits[colIdx];
              return `
                <div class="flex flex-col gap-1 items-center">
                  ${[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => {
                    const isFilled = currentVal === String(num);
                    return `
                      <div data-sbd-col="${colIdx}" data-sbd-num="${num}"
                           class="sbd-bubble omr-bubble-sm ${isFilled ? 'filled' : ''}">
                        ${num}
                      </div>
                    `;
                  }).join('')}
                </div>
              `;
            }).join('')}
          </div>
        </div>
      `;
      sbdContainer.innerHTML = html;

      sbdContainer.querySelectorAll('[data-sbd-col]').forEach(b => {
        b.addEventListener('click', () => {
          if (state.isSubmitted) return;
          const col = parseInt(b.getAttribute('data-sbd-col'));
          const num = b.getAttribute('data-sbd-num');
          state.omrState.sbdDigits[col] = (state.omrState.sbdDigits[col] === num) ? "" : num;
          renderStudentInfoSection();
          playBeep(650, 0.04);
        });
      });
    }
  }

  // Render Part 1 OMR
  function renderPart1Omr() {
    const container = document.getElementById('omrPart1Grid');
    if (!container) return;

    const exam = getCurrentExam();
    if (!exam || !exam.part1) return;

    let html = '';
    exam.part1.forEach(q => {
      const selected = state.answers.part1[q.id];
      html += `
        <div class="flex items-center justify-between py-1 px-1.5 rounded hover:bg-blue-50/50 transition-colors">
          <span class="font-mono text-xs font-bold text-slate-700 w-6 text-right mr-1.5 cursor-pointer hover:text-blue-600" 
                onclick="window.scrollToQuestion('q_p1_${q.id}')">
            ${q.id}
          </span>
          <div class="flex items-center gap-2">
            ${['A', 'B', 'C', 'D'].map(opt => {
              const isFilled = selected === opt;
              let extraClass = '';
              
              if (state.isSubmitted) {
                if (isFilled && opt === q.answer) {
                  extraClass = 'is-correct';
                } else if (isFilled && opt !== q.answer) {
                  extraClass = 'is-wrong';
                } else if (!isFilled && opt === q.answer) {
                  extraClass = 'should-be-correct';
                }
              } else if (isFilled) {
                extraClass = 'filled';
              }

              return `
                <div data-p1-bubble="${q.id}" data-opt="${opt}"
                     class="omr-bubble ${extraClass}">
                  ${opt}
                </div>
              `;
            }).join('')}
          </div>
        </div>
      `;
    });

    container.innerHTML = html;

    container.querySelectorAll('[data-p1-bubble]').forEach(bubble => {
      bubble.addEventListener('click', () => {
        if (state.isSubmitted) return;
        if (!state.omrState.isCodeUnlocked) {
          alert("Vui lòng tô đúng Mã Đề Thi trước để mở đề và bắt đầu làm bài!");
          return;
        }
        const qid = parseInt(bubble.getAttribute('data-p1-bubble'));
        const opt = bubble.getAttribute('data-opt');
        togglePart1Answer(qid, opt);
      });
    });
  }

  // Render Part 2 OMR
  function renderPart2Omr() {
    const container = document.getElementById('omrPart2Grid');
    if (!container) return;

    const exam = getCurrentExam();
    if (!exam || !exam.part2) return;

    let html = '';
    exam.part2.forEach(q => {
      const qAnswers = state.answers.part2[q.id] || {};
      html += `
        <div class="border border-slate-200 rounded-lg p-2 mb-2 bg-white shadow-xs">
          <div class="flex items-center justify-between mb-1">
            <span class="font-bold text-xs text-indigo-800 cursor-pointer hover:underline"
                  onclick="window.scrollToQuestion('q_p2_${q.id}')">
              Câu ${q.id}
            </span>
            <div class="text-[10px] font-semibold text-slate-500 flex gap-4 pr-1">
              <span>Đ</span>
              <span>S</span>
            </div>
          </div>
          <div class="space-y-1">
            ${q.statements.map(stmt => {
              const userVal = qAnswers[stmt.id];
              const isTrueFilled = userVal === true;
              const isFalseFilled = userVal === false;

              let trueClass = isTrueFilled ? 'filled' : '';
              let falseClass = isFalseFilled ? 'filled' : '';

              if (state.isSubmitted) {
                if (isTrueFilled) {
                  trueClass = stmt.answer === true ? 'is-correct' : 'is-wrong';
                } else if (stmt.answer === true) {
                  trueClass = 'should-be-correct';
                }

                if (isFalseFilled) {
                  falseClass = stmt.answer === false ? 'is-correct' : 'is-wrong';
                } else if (stmt.answer === false) {
                  falseClass = 'should-be-correct';
                }
              }

              return `
                <div class="flex items-center justify-between py-0.5">
                  <span class="text-xs font-semibold text-slate-700 font-mono w-4">${stmt.id})</span>
                  <div class="flex items-center gap-2">
                    <div data-p2-bubble="${q.id}" data-stmt="${stmt.id}" data-val="true"
                         class="omr-bubble text-[11px] ${trueClass}">
                      Đ
                    </div>
                    <div data-p2-bubble="${q.id}" data-stmt="${stmt.id}" data-val="false"
                         class="omr-bubble text-[11px] ${falseClass}">
                      S
                    </div>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>
      `;
    });

    container.innerHTML = html;

    container.querySelectorAll('[data-p2-bubble]').forEach(bubble => {
      bubble.addEventListener('click', () => {
        if (state.isSubmitted) return;
        if (!state.omrState.isCodeUnlocked) {
          alert("Vui lòng tô đúng Mã Đề Thi trước để mở đề và bắt đầu làm bài!");
          return;
        }
        const qid = parseInt(bubble.getAttribute('data-p2-bubble'));
        const stmt = bubble.getAttribute('data-stmt');
        const val = bubble.getAttribute('data-val') === 'true';
        setPart2Answer(qid, stmt, val);
      });
    });
  }

  // Render Part 3 OMR
  function renderPart3Omr() {
    const container = document.getElementById('omrPart3Grid');
    if (!container) return;

    const exam = getCurrentExam();
    if (!exam || !exam.part3) return;

    let html = '';
    exam.part3.forEach(q => {
      const userAns = state.answers.part3[q.id] || '';
      let isCorrect = false;
      if (state.isSubmitted) {
        isCorrect = (userAns.trim().replace(',', '.') === q.answer.trim().replace(',', '.'));
      }

      html += `
        <div class="flex items-center justify-between p-2 rounded-lg border border-slate-200 bg-white mb-2 shadow-xs">
          <span class="font-mono text-xs font-bold text-emerald-800 cursor-pointer hover:underline"
                onclick="window.scrollToQuestion('q_p3_${q.id}')">
            Câu ${q.id}
          </span>
          <div class="flex items-center gap-1.5">
            <input type="text" 
                   data-p3-omr-input="${q.id}" 
                   value="${userAns}"
                   placeholder="Nhập số..."
                   ${state.isSubmitted || !state.omrState.isCodeUnlocked ? 'disabled' : ''}
                   class="w-24 px-2 py-1 border border-slate-300 rounded font-mono font-bold text-xs text-center focus:border-emerald-500 focus:outline-none ${
                     state.isSubmitted
                       ? (isCorrect ? 'bg-emerald-100 border-emerald-500 text-emerald-900 font-bold' : 'bg-rose-100 border-rose-500 text-rose-900 font-bold')
                       : 'bg-white'
                   }" />
            ${state.isSubmitted ? `
              <span class="text-[11px] font-mono font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                ${q.answer}
              </span>
            ` : ''}
          </div>
        </div>
      `;
    });

    container.innerHTML = html;

    container.querySelectorAll('[data-p3-omr-input]').forEach(input => {
      input.addEventListener('input', (e) => {
        if (state.isSubmitted) return;
        const qid = parseInt(input.getAttribute('data-p3-omr-input'));
        setPart3Answer(qid, e.target.value);
      });
    });
  }

  // Answer Toggles
  function togglePart1Answer(qid, opt) {
    if (state.answers.part1[qid] === opt) {
      delete state.answers.part1[qid];
    } else {
      state.answers.part1[qid] = opt;
      playBeep(650, 0.04);
    }
    updateUiAfterAnswer();
  }

  function setPart2Answer(qid, stmt, val) {
    if (!state.answers.part2[qid]) state.answers.part2[qid] = {};
    if (state.answers.part2[qid][stmt] === val) {
      delete state.answers.part2[qid][stmt];
    } else {
      state.answers.part2[qid][stmt] = val;
      playBeep(720, 0.04);
    }
    updateUiAfterAnswer();
  }

  function setPart3Answer(qid, val) {
    state.answers.part3[qid] = val;
    updateUiAfterAnswer();
  }

  function updateUiAfterAnswer() {
    renderPart1Omr();
    renderPart2Omr();
    renderPart3Omr();

    const exam = getCurrentExam();
    if (state.omrState.isCodeUnlocked) {
      renderQuestions(exam);
      renderMath();
    }
    updateProgress();
  }

  // Render Exam Questions in Left Panel
  function renderQuestions(exam) {
    const container = document.getElementById('examQuestions');
    if (!container || !exam) return;

    let html = '';

    // PHẦN I
    html += `
      <div class="mb-10">
        <div class="flex items-center gap-2 mb-4 pb-2 border-b-2 border-blue-600">
          <span class="bg-blue-600 text-white text-xs font-bold px-2.5 py-1 rounded">PHẦN I</span>
          <h2 class="text-base font-bold text-slate-800 uppercase tracking-wide">
            Câu trắc nghiệm nhiều phương án lựa chọn (12 câu - 3.0 điểm)
          </h2>
        </div>
        <p class="text-xs text-slate-500 italic mb-4">
          Thí sinh trả lời từ câu 1 đến câu 12. Mỗi câu hỏi thí sinh chỉ chọn một phương án.
        </p>
        <div class="space-y-6">
    `;

    exam.part1.forEach(q => {
      const userAns = state.answers.part1[q.id];
      html += `
        <div id="q_p1_${q.id}" class="question-item p-4 rounded-xl border border-slate-200 bg-white hover:border-blue-300 transition-all shadow-sm">
          <div class="flex items-start gap-2.5 mb-3">
            <span class="inline-flex items-center justify-center bg-blue-100 text-blue-800 text-xs font-bold px-2.5 py-1 rounded-md shrink-0">
              Câu ${q.id}
            </span>
            <div class="text-slate-800 font-medium leading-relaxed text-[15px] question-text">
              ${q.question}
            </div>
          </div>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-2.5 pl-2">
            ${q.options.map((opt, idx) => {
              const letter = ['A', 'B', 'C', 'D'][idx];
              const isSelected = userAns === letter;
              let extraClasses = 'hover:bg-slate-50 border-slate-200 text-slate-700';
              
              if (state.isSubmitted) {
                if (letter === q.answer) {
                  extraClasses = 'bg-emerald-50 border-emerald-500 text-emerald-800 font-semibold';
                } else if (isSelected && letter !== q.answer) {
                  extraClasses = 'bg-rose-50 border-rose-400 text-rose-800 line-through';
                }
              } else if (isSelected) {
                extraClasses = 'bg-blue-50 border-blue-500 text-blue-900 font-medium shadow-sm';
              }

              return `
                <div data-p1-qid="${q.id}" data-opt="${letter}"
                     class="option-item flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer transition-all ${extraClasses}">
                  <span class="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                    isSelected ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'
                  }">
                    ${letter}
                  </span>
                  <span class="text-sm">${opt.replace(/^[A-D]\.\s*/, '')}</span>
                </div>
              `;
            }).join('')}
          </div>

          ${state.isSubmitted ? `
            <div class="mt-4 p-3 bg-amber-50/70 border-l-4 border-amber-400 rounded-r-lg text-xs leading-relaxed text-slate-700">
              <span class="font-bold text-amber-800">Lời giải chi tiết:</span>
              <div class="mt-1">${q.solution}</div>
            </div>
          ` : ''}
        </div>
      `;
    });
    html += `</div></div>`;

    // PHẦN II
    html += `
      <div class="mb-10">
        <div class="flex items-center gap-2 mb-4 pb-2 border-b-2 border-indigo-600">
          <span class="bg-indigo-600 text-white text-xs font-bold px-2.5 py-1 rounded">PHẦN II</span>
          <h2 class="text-base font-bold text-slate-800 uppercase tracking-wide">
            Câu trắc nghiệm đúng sai (4 câu - 4.0 điểm)
          </h2>
        </div>
        <p class="text-xs text-slate-500 italic mb-4">
          Thí sinh trả lời từ câu 1 đến câu 4. Trong mỗi ý a), b), c), d) ở mỗi câu, thí sinh chọn đúng hoặc sai.
        </p>
        <div class="space-y-6">
    `;

    exam.part2.forEach(q => {
      const qAns = state.answers.part2[q.id] || {};
      html += `
        <div id="q_p2_${q.id}" class="question-item p-4 rounded-xl border border-slate-200 bg-white hover:border-indigo-300 transition-all shadow-sm">
          <div class="flex items-start gap-2.5 mb-3">
            <span class="inline-flex items-center justify-center bg-indigo-100 text-indigo-800 text-xs font-bold px-2.5 py-1 rounded-md shrink-0">
              Câu ${q.id}
            </span>
            <div class="text-slate-800 font-medium leading-relaxed text-[15px] question-text">
              ${q.question}
            </div>
          </div>
          <div class="space-y-2 pl-2">
            ${q.statements.map(stmt => {
              const userVal = qAns[stmt.id];
              const isTrueSelected = userVal === true;
              const isFalseSelected = userVal === false;

              let aClass = 'text-slate-700';
              if (state.isSubmitted) {
                if (userVal === stmt.answer) {
                  aClass = 'text-emerald-800 font-medium';
                } else if (userVal !== undefined) {
                  aClass = 'text-rose-800 font-medium';
                }
              }

              return `
                <div class="p-2.5 rounded-lg border border-slate-100 bg-slate-50/60 flex flex-col md:flex-row md:items-center justify-between gap-2">
                  <div class="text-sm ${aClass}">
                    <span class="font-bold text-indigo-700 mr-1">${stmt.id})</span>
                    <span>${stmt.text}</span>
                  </div>
                  <div class="flex items-center gap-2 shrink-0 self-end md:self-auto">
                    <button type="button" 
                            data-p2-qid="${q.id}" data-stmt="${stmt.id}" data-val="true"
                            class="p2-toggle-btn px-3 py-1 text-xs font-bold rounded border transition-all ${
                              isTrueSelected 
                                ? 'bg-indigo-600 text-white border-indigo-700' 
                                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                            }">
                      ĐÚNG
                    </button>
                    <button type="button" 
                            data-p2-qid="${q.id}" data-stmt="${stmt.id}" data-val="false"
                            class="p2-toggle-btn px-3 py-1 text-xs font-bold rounded border transition-all ${
                              isFalseSelected 
                                ? 'bg-rose-600 text-white border-rose-700' 
                                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
                            }">
                      SAI
                    </button>
                    ${state.isSubmitted ? `
                      <span class="text-xs font-bold px-2 py-0.5 rounded ${stmt.answer ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}">
                        Đáp án: ${stmt.answer ? 'Đ' : 'S'}
                      </span>
                    ` : ''}
                  </div>
                </div>
              `;
            }).join('')}
          </div>

          ${state.isSubmitted ? `
            <div class="mt-4 p-3 bg-amber-50/70 border-l-4 border-amber-400 rounded-r-lg text-xs leading-relaxed text-slate-700">
              <span class="font-bold text-amber-800">Lời giải chi tiết:</span>
              <ul class="mt-1 list-disc list-inside space-y-1">
                ${q.statements.map(s => `<li><b>${s.id})</b> [${s.answer ? 'Đúng' : 'Sai'}]: ${s.solution}</li>`).join('')}
              </ul>
            </div>
          ` : ''}
        </div>
      `;
    });
    html += `</div></div>`;

    // PHẦN III
    html += `
      <div class="mb-10">
        <div class="flex items-center gap-2 mb-4 pb-2 border-b-2 border-emerald-600">
          <span class="bg-emerald-600 text-white text-xs font-bold px-2.5 py-1 rounded">PHẦN III</span>
          <h2 class="text-base font-bold text-slate-800 uppercase tracking-wide">
            Câu trắc nghiệm trả lời ngắn (6 câu - 3.0 điểm)
          </h2>
        </div>
        <p class="text-xs text-slate-500 italic mb-4">
          Thí sinh trả lời từ câu 1 đến câu 6. Điền hoặc tô kết quả số tương ứng.
        </p>
        <div class="space-y-6">
    `;

    exam.part3.forEach(q => {
      const userAns = state.answers.part3[q.id] || '';
      let isCorrect = false;
      if (state.isSubmitted) {
        isCorrect = (userAns.trim().replace(',', '.') === q.answer.trim().replace(',', '.'));
      }

      html += `
        <div id="q_p3_${q.id}" class="question-item p-4 rounded-xl border border-slate-200 bg-white hover:border-emerald-300 transition-all shadow-sm">
          <div class="flex items-start gap-2.5 mb-3">
            <span class="inline-flex items-center justify-center bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-1 rounded-md shrink-0">
              Câu ${q.id}
            </span>
            <div class="text-slate-800 font-medium leading-relaxed text-[15px] question-text">
              ${q.question}
            </div>
          </div>
          <div class="mt-3 flex items-center gap-3">
            <label class="text-xs font-semibold text-slate-600">Đáp số của bạn:</label>
            <input type="text" 
                   data-p3-qid="${q.id}" 
                   value="${userAns}"
                   placeholder="Nhập số..."
                   ${state.isSubmitted ? 'disabled' : ''}
                   class="p3-text-input px-3 py-1.5 border border-slate-300 rounded-lg text-sm font-mono font-bold w-36 text-center focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 ${
                     state.isSubmitted 
                       ? (isCorrect ? 'bg-emerald-50 border-emerald-500 text-emerald-800' : 'bg-rose-50 border-rose-500 text-rose-800') 
                       : 'bg-white text-slate-800'
                   }" />
            ${state.isSubmitted ? `
              <span class="text-xs font-bold px-2.5 py-1 rounded-md bg-emerald-100 text-emerald-800">
                Đáp án chuẩn: <b>${q.answer}</b>
              </span>
            ` : ''}
          </div>

          ${state.isSubmitted ? `
            <div class="mt-4 p-3 bg-amber-50/70 border-l-4 border-amber-400 rounded-r-lg text-xs leading-relaxed text-slate-700">
              <span class="font-bold text-amber-800">Lời giải chi tiết:</span>
              <div class="mt-1">${q.solution}</div>
            </div>
          ` : ''}
        </div>
      `;
    });
    html += `</div></div>`;

    container.innerHTML = html;

    // Attach listeners on paper options
    container.querySelectorAll('.option-item').forEach(el => {
      el.addEventListener('click', () => {
        if (state.isSubmitted) return;
        const qid = parseInt(el.getAttribute('data-p1-qid'));
        const opt = el.getAttribute('data-opt');
        togglePart1Answer(qid, opt);
      });
    });

    container.querySelectorAll('.p2-toggle-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        if (state.isSubmitted) return;
        const qid = parseInt(btn.getAttribute('data-p2-qid'));
        const stmt = btn.getAttribute('data-stmt');
        const val = btn.getAttribute('data-val') === 'true';
        setPart2Answer(qid, stmt, val);
      });
    });

    container.querySelectorAll('.p3-text-input').forEach(input => {
      input.addEventListener('input', (e) => {
        if (state.isSubmitted) return;
        const qid = parseInt(input.getAttribute('data-p3-qid'));
        setPart3Answer(qid, e.target.value);
      });
    });
  }

  // KaTeX rendering
  function renderMath() {
    if (typeof renderMathInElement === 'function') {
      try {
        renderMathInElement(document.getElementById('examPaperContainer'), {
          delimiters: [
            { left: '$$', right: '$$', display: true },
            { left: '$', right: '$', display: false },
            { left: '\\(', right: '\\)', display: false },
            { left: '\\[', right: '\\]', display: true }
          ],
          throwOnError: false
        });
      } catch (err) {}
    }
  }

  // Progress Bar
  function updateProgress() {
    let total = 12 + 4 + 6;
    let answered = 0;

    answered += Object.keys(state.answers.part1).length;

    for (let i = 1; i <= 4; i++) {
      if (state.answers.part2[i] && Object.keys(state.answers.part2[i]).length === 4) {
        answered++;
      }
    }

    for (let i = 1; i <= 6; i++) {
      if (state.answers.part3[i] && state.answers.part3[i].trim() !== '') {
        answered++;
      }
    }

    const pct = Math.round((answered / total) * 100);
    const bar = document.getElementById('examProgressBar');
    if (bar) bar.style.width = `${pct}%`;

    const text = document.getElementById('examProgressText');
    if (text) text.innerText = `${answered}/${total} câu (${pct}%)`;
  }

  // Timer
  function startTimer() {
    if (state.timer.isRunning) return;
    state.timer.isRunning = true;
    updateTimerDisplay();

    state.timer.intervalId = setInterval(() => {
      if (!state.timer.isRunning || state.isSubmitted) return;

      if (state.timer.remainingSeconds > 0) {
        state.timer.remainingSeconds--;
        updateTimerDisplay();
        if (state.timer.remainingSeconds === 300) {
          playBeep(900, 0.3);
          showToast("Còn 5 phút cuối cùng! Thí sinh kiểm tra lại bài làm.");
        }
      } else {
        clearInterval(state.timer.intervalId);
        state.timer.isRunning = false;
        alert("Đã hết thời gian 90 phút! Hệ thống tiến hành thu bài và chấm điểm.");
        submitExam(true);
      }
    }, 1000);
  }

  function toggleTimerPause() {
    state.timer.isRunning = !state.timer.isRunning;
    const btn = document.getElementById('pauseTimerBtn');
    if (btn) {
      btn.innerHTML = state.timer.isRunning 
        ? `<i data-lucide="pause" class="w-4 h-4"></i> Tạm dừng` 
        : `<i data-lucide="play" class="w-4 h-4"></i> Tiếp tục`;
      if (window.lucide) window.lucide.createIcons();
    }
  }

  function updateTimerDisplay() {
    const mins = Math.floor(state.timer.remainingSeconds / 60);
    const secs = state.timer.remainingSeconds % 60;
    const formatted = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    const timerEl = document.getElementById('examTimer');
    if (timerEl) {
      timerEl.innerText = formatted;
      if (state.timer.remainingSeconds <= 300) {
        timerEl.classList.add('text-rose-600', 'animate-pulse');
      } else {
        timerEl.classList.remove('text-rose-600', 'animate-pulse');
      }
    }
  }

  function showToast(msg) {
    const toast = document.createElement('div');
    toast.className = 'fixed bottom-6 right-6 bg-slate-900 text-white px-4 py-2.5 rounded-xl text-xs sm:text-sm shadow-2xl z-50 transition-all transform translate-y-2 opacity-0 flex items-center gap-2 border border-slate-700';
    toast.innerHTML = `<span class="w-2.5 h-2.5 rounded-full bg-amber-400 shrink-0"></span> <span>${msg}</span>`;
    document.body.appendChild(toast);
    setTimeout(() => toast.classList.remove('translate-y-2', 'opacity-0'), 10);
    setTimeout(() => {
      toast.classList.add('translate-y-2', 'opacity-0');
      setTimeout(() => toast.remove(), 300);
    }, 4500);
  }

  // Submit and Scoring
  function submitExam(force = false) {
    if (state.isSubmitted) return;

    if (!state.omrState.isCodeUnlocked) {
      alert("Bạn chưa tô mã đề thi hợp lệ để mở đề!");
      return;
    }

    const exam = getCurrentExam();
    
    // Check missing questions
    let missingP1 = 0;
    exam.part1.forEach(q => { if (!state.answers.part1[q.id]) missingP1++; });

    let missingP2 = 0;
    exam.part2.forEach(q => {
      const qAns = state.answers.part2[q.id] || {};
      q.statements.forEach(s => { if (qAns[s.id] === undefined) missingP2++; });
    });

    let missingP3 = 0;
    exam.part3.forEach(q => {
      if (!state.answers.part3[q.id] || state.answers.part3[q.id].trim() === '') missingP3++;
    });

    const totalMissing = missingP1 + Math.ceil(missingP2 / 4) + missingP3;

    if (!force && totalMissing > 0) {
      const ok = confirm(`Bạn còn ${totalMissing} câu/ý chưa hoàn thành (Phần I: ${missingP1} câu, Phần II: ${missingP2} ý, Phần III: ${missingP3} câu).\n\nBạn có chắc chắn muốn nộp bài và chấm điểm ngay?`);
      if (!ok) return;
    }

    state.isSubmitted = true;
    state.timer.isRunning = false;

    // Score Part I: 12 * 0.25 = max 3.0
    let p1Correct = 0;
    exam.part1.forEach(q => {
      if (state.answers.part1[q.id] === q.answer) p1Correct++;
    });
    const p1Score = p1Correct * 0.25;

    // Score Part II: MoET grading (0.1, 0.25, 0.5, 1.0)
    let p2TotalScore = 0;
    exam.part2.forEach(q => {
      const qAns = state.answers.part2[q.id] || {};
      let count = 0;
      q.statements.forEach(s => {
        if (qAns[s.id] === s.answer) count++;
      });
      if (count === 1) p2TotalScore += 0.1;
      else if (count === 2) p2TotalScore += 0.25;
      else if (count === 3) p2TotalScore += 0.5;
      else if (count === 4) p2TotalScore += 1.0;
    });

    // Score Part III: 6 * 0.5 = max 3.0
    let p3Correct = 0;
    exam.part3.forEach(q => {
      const u = (state.answers.part3[q.id] || '').trim().replace(',', '.');
      const t = q.answer.trim().replace(',', '.');
      if (u === t) p3Correct++;
    });
    const p3Score = p3Correct * 0.5;

    const totalScore = Math.min(10, Math.round((p1Score + p2TotalScore + p3Score) * 100) / 100);

    state.results = {
      p1Score,
      p1Correct,
      p2Score: Math.round(p2TotalScore * 100) / 100,
      p3Score,
      p3Correct,
      totalScore,
      submittedAt: new Date().toLocaleString('vi-VN')
    };

    saveHistory();

    // Re-render to show solutions and feedback
    renderPart1Omr();
    renderPart2Omr();
    renderPart3Omr();
    renderQuestions(exam);
    renderMath();

    // Confetti celebration
    if (totalScore >= 7.0 && typeof confetti === 'function') {
      confetti({ particleCount: 150, spread: 90, origin: { y: 0.6 } });
    }

    showResultModal();
  }

  function saveHistory() {
    try {
      const history = JSON.parse(localStorage.getItem('omr_exam_history') || '[]');
      history.unshift({
        name: state.assignedTicket.name,
        className: state.assignedTicket.className,
        code: state.assignedTicket.targetCode,
        score: state.results.totalScore,
        date: state.results.submittedAt
      });
      localStorage.setItem('omr_exam_history', JSON.stringify(history.slice(0, 30)));
    } catch (e) {}
  }

  function showResultModal() {
    const modal = document.getElementById('resultModal');
    if (!modal) return;
    const res = state.results;

    document.getElementById('resScore').innerText = res.totalScore.toFixed(2);

    let rank = "Trung bình";
    let rankColor = "text-amber-700 bg-amber-50 border-amber-200";
    if (res.totalScore >= 9.0) {
      rank = "Xuất sắc";
      rankColor = "text-emerald-700 bg-emerald-50 border-emerald-300";
    } else if (res.totalScore >= 8.0) {
      rank = "Giỏi";
      rankColor = "text-blue-700 bg-blue-50 border-blue-300";
    } else if (res.totalScore >= 6.5) {
      rank = "Khá";
      rankColor = "text-indigo-700 bg-indigo-50 border-indigo-300";
    } else if (res.totalScore < 5.0) {
      rank = "Chưa đạt";
      rankColor = "text-rose-700 bg-rose-50 border-rose-300";
    }

    const rankEl = document.getElementById('resRankBadge');
    if (rankEl) {
      rankEl.className = `px-3 py-1 rounded-full text-xs font-bold border ${rankColor}`;
      rankEl.innerText = rank;
    }

    document.getElementById('resP1').innerText = `${res.p1Score.toFixed(2)} / 3.0 điểm (${res.p1Correct}/12 câu đúng)`;
    document.getElementById('resP2').innerText = `${res.p2Score.toFixed(2)} / 4.0 điểm`;
    document.getElementById('resP3').innerText = `${res.p3Score.toFixed(2)} / 3.0 điểm (${res.p3Correct}/6 câu đúng)`;

    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }

  function showHistoryModal() {
    const modal = document.getElementById('historyModal');
    if (!modal) return;
    const historyList = document.getElementById('historyListContainer');
    const history = JSON.parse(localStorage.getItem('omr_exam_history') || '[]');

    if (history.length === 0) {
      historyList.innerHTML = `<div class="p-8 text-center text-slate-400 text-sm">Chưa có lịch sử làm bài nào. Hãy bấm Bắt đầu thi để rèn luyện ngay!</div>`;
    } else {
      historyList.innerHTML = `
        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs border-collapse">
            <thead>
              <tr class="bg-slate-100 text-slate-700 uppercase border-b">
                <th class="p-2.5">Thời gian</th>
                <th class="p-2.5">Thí sinh</th>
                <th class="p-2.5">Lớp</th>
                <th class="p-2.5 text-center">Mã đề</th>
                <th class="p-2.5 text-center">Điểm số</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100">
              ${history.map(item => `
                <tr class="hover:bg-slate-50">
                  <td class="p-2.5 text-slate-500">${item.date}</td>
                  <td class="p-2.5 font-medium text-slate-800">${item.name}</td>
                  <td class="p-2.5 text-slate-600">${item.className}</td>
                  <td class="p-2.5 text-center font-mono font-bold text-blue-600">${item.code}</td>
                  <td class="p-2.5 text-center font-bold text-emerald-600 text-sm">${item.score.toFixed(2)}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      `;
    }

    modal.classList.remove('hidden');
    modal.classList.add('flex');
  }

  window.scrollToQuestion = function (elementId) {
    const el = document.getElementById(elementId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.classList.add('active-target');
      setTimeout(() => el.classList.remove('active-target'), 2000);
    }
  };

  // Run on load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
