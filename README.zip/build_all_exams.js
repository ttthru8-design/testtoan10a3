const fs = require('fs');
const path = require('path');

// We will build all 10 exams
const exams = [
  // 1001
  {
    id: "1001",
    code: "1001",
    title: "ĐỀ THAM KHẢO SỐ 1 - Kiểm tra Tập trung lần III - Môn Toán 10",
    timeMinutes: 90,
    part1: [
      {
        id: 1,
        question: "Bất phương trình nào sau đây là bất phương trình bậc nhất hai ẩn?",
        options: ["A. $x^2 + y > 0$", "B. $2x - 3y \\le 5$", "C. $x + y^2 \\ge 1$", "D. $x^3 + 2y < 4$"],
        answer: "B",
        solution: "Bất phương trình bậc nhất hai ẩn có dạng $ax + by < c$ (hoặc $\\le, >, \\ge$) với $a, b$ không đồng thời bằng 0. Do đó $2x - 3y \\le 5$ là bất phương trình bậc nhất hai ẩn."
      },
      {
        id: 2,
        question: "Cặp số $(x; y) = (1; -2)$ là nghiệm của bất phương trình nào sau đây?",
        options: ["A. $x + y > 0$", "B. $2x - y < 0$", "C. $x - 3y \\ge 5$", "D. $-x + y \\ge -1$"],
        answer: "C",
        solution: "Thay $x = 1, y = -2$ vào $x - 3y \\ge 5$ ta được $1 - 3(-2) = 7 \\ge 5$ (luôn đúng)."
      },
      {
        id: 3,
        question: "Hệ bất phương trình nào sau đây là hệ bất phương trình bậc nhất hai ẩn?",
        options: [
          "A. $\\begin{cases} x + y > 0 \\\\ x^2 < 2 \\end{cases}$",
          "B. $\\begin{cases} 2x - y \\ge 1 \\\\ x + 3y \\le 5 \\end{cases}$",
          "C. $\\begin{cases} x + y^2 > 1 \\\\ y < 0 \\end{cases}$",
          "D. $\\begin{cases} x - y = 0 \\\\ x^3 + y > 1 \\end{cases}$"
        ],
        answer: "B",
        solution: "Hệ $\\begin{cases} 2x - y \\ge 1 \\\\ x + 3y \\le 5 \\end{cases}$ gồm hai bất phương trình bậc nhất hai ẩn $x, y$."
      },
      {
        id: 4,
        question: "Điểm $M(0; 1)$ thuộc miền nghiệm của hệ bất phương trình nào sau đây?",
        options: [
          "A. $\\begin{cases} x + y \\ge 2 \\\\ x - y \\le 0 \\end{cases}$",
          "B. $\\begin{cases} 2x + y > 0 \\\\ x - 3y < 1 \\end{cases}$",
          "C. $\\begin{cases} x - y > 1 \\\\ x + y < 5 \\end{cases}$",
          "D. $\\begin{cases} x \\ge 1 \\\\ y \\le 2 \\end{cases}$"
        ],
        answer: "B",
        solution: "Thay $x = 0, y = 1$ vào phương án B: $2(0) + 1 = 1 > 0$ và $0 - 3(1) = -3 < 1$. Cả hai bất phương trình đều đúng."
      },
      {
        id: 5,
        question: "Hai vectơ được gọi là bằng nhau nếu chúng:",
        options: [
          "A. Cùng phương và cùng độ dài.",
          "B. Cùng hướng và cùng độ dài.",
          "C. Cùng phương.",
          "D. Cùng độ dài."
        ],
        answer: "B",
        solution: "Theo định nghĩa SGK, hai vectơ bằng nhau nếu chúng cùng hướng và cùng độ dài."
      },
      {
        id: 6,
        question: "Cho ba điểm $A, B, C$ bất kì. Khẳng định nào sau đây đúng?",
        options: [
          "A. $\\vec{AB} + \\vec{BC} = \\vec{CA}$",
          "B. $\\vec{AB} - \\vec{AC} = \\vec{BC}$",
          "C. $\\vec{AB} + \\vec{BC} = \\vec{AC}$",
          "D. $\\vec{AC} - \\vec{AB} = \\vec{BC}$"
        ],
        answer: "C",
        solution: "Theo quy tắc 3 điểm của phép cộng vectơ: $\\vec{AB} + \\vec{BC} = \\vec{AC}$."
      },
      {
        id: 7,
        question: "Cho hình vuông $ABCD$ có cạnh bằng $a$. Tính độ dài vectơ $\\vec{AB} + \\vec{AD}$.",
        options: ["A. $a$", "B. $2a$", "C. $a\\sqrt{2}$", "D. $a\\sqrt{3}$"],
        answer: "C",
        solution: "$\\vec{AB} + \\vec{AD} = \\vec{AC}$. Do $ABCD$ là hình vuông cạnh $a$ nên độ dài đường chéo $AC = a\\sqrt{2}$."
      },
      {
        id: 8,
        question: "Cho vectơ $\\vec{a} \\ne \\vec{0}$ và số thực $k < 0$. Khẳng định nào sau đây đúng về vectơ $k\\vec{a}$?",
        options: [
          "A. Cùng hướng với $\\vec{a}$ và độ dài bằng $k|\\vec{a}|$.",
          "B. Ngược hướng với $\\vec{a}$ và độ dài bằng $-k|\\vec{a}|$.",
          "C. Cùng hướng với $\\vec{a}$ và độ dài bằng $-k|\\vec{a}|$.",
          "D. Ngược hướng với $\\vec{a}$ và độ dài bằng $k|\\vec{a}|Key"
        ],
        answer: "B",
        solution: "Vì $k < 0$ nên vectơ $k\\vec{a}$ ngược hướng với $\\vec{a}$ và có độ dài $|k\\vec{a}| = |k|\\cdot |\\vec{a}| = -k|\\vec{a}|$."
      },
      {
        id: 9,
        question: "Cho đoạn thẳng $AB$ có trung điểm $I$. Mệnh đề nào sau đây đúng?",
        options: [
          "A. $\\vec{IA} = \\vec{IB}$",
          "B. $\\vec{IA} + \\vec{IB} = \\vec{0}$",
          "C. $\\vec{AI} + \\vec{BI} = \\vec{AB}$",
          "D. $\\vec{IA} - \\vec{IB} = \\vec{0}$"
        ],
        answer: "B",
        solution: "Vì $I$ là trung điểm đoạn thẳng $AB$ nên $\\vec{IA}$ và $\\vec{IB}$ là hai vectơ đối nhau, do đó $\\vec{IA} + \\vec{IB} = \\vec{0}$."
      },
      {
        id: 10,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho $\\vec{a} = 3\\vec{i} - 2\\vec{j}$. Tọa độ của vectơ $\\vec{a}$ là:",
        options: ["A. $(3; 2)$", "B. $(-2; 3)$", "C. $(3; -2)$", "D. $(2; -3)$"],
        answer: "C",
        solution: "Theo định nghĩa tọa độ vectơ: $\\vec{a} = x\\vec{i} + y\\vec{j} \\implies \\vec{a} = (x; y) = (3; -2)$."
      },
      {
        id: 11,
        question: "Trong mặt phẳng $Oxy$, cho $\\vec{u} = (1; -2)$ và $\\vec{v} = (3; 4)$. Tọa độ của vectơ $\\vec{u} + \\vec{v}$ là:",
        options: ["A. $(4; 2)$", "B. $(2; 6)$", "C. $(4; -6)$", "D. $(-2; -6)$"],
        answer: "A",
        solution: "$\\vec{u} + \\vec{v} = (1 + 3; -2 + 4) = (4; 2)$."
      },
      {
        id: 12,
        question: "Cho tam giác $ABC$ có $A(1; 2), B(-1; 1), C(3; 0)$. Tọa độ trọng tâm $G$ của tam giác $ABC$ là:",
        options: ["A. $(1; 1)$", "B. $(3; 3)$", "C. $(1; 3)$", "D. $(0; 1)$"],
        answer: "A",
        solution: "$x_G = \\frac{1 + (-1) + 3}{3} = 1$; $y_G = \\frac{2 + 1 + 0}{3} = 1 \\implies G(1; 1)$."
      }
    ],
    part2: [
      {
        id: 1,
        question: "Cho bất phương trình: $x - 2y > 4$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Đường thẳng biên của miền nghiệm có phương trình là $x - 2y - 4 = 0$.", answer: true, solution: "Phương trình đường thẳng biên là $x - 2y = 4 \\iff x - 2y - 4 = 0$." },
          { id: "b", text: "Điểm $M(4; 0)$ thuộc miền nghiệm của bất phương trình.", answer: false, solution: "Thay $(4; 0)$ vào ta có $4 - 0 = 4 > 4$ (sai) nên điểm $M$ không thuộc miền nghiệm." },
          { id: "c", text: "Gốc tọa độ $O(0; 0)$ không thuộc miền nghiệm của bất phương trình.", answer: true, solution: "Thay $(0; 0)$ vào ta có $0 > 4$ (sai) nên gốc $O$ không thuộc miền nghiệm." },
          { id: "d", text: "Miền nghiệm của bất phương trình là nửa mặt phẳng bờ là đường thẳng $d: x - 2y = 4$ (không kể $d$) và không chứa gốc tọa độ $O$.", answer: true, solution: "Đúng theo quy tắc xác định miền nghiệm hình học." }
        ]
      },
      {
        id: 2,
        question: "Một xưởng sản xuất hai loại sản phẩm A và B. Sản xuất 1 kg sản phẩm A cần 2 kg nguyên liệu và 3 giờ máy; sản xuất 1 kg sản phẩm B cần 4 kg nguyên liệu và 2 giờ máy. Xưởng có tối đa 200 kg nguyên liệu và 150 giờ máy. Gọi $x, y$ lần lượt là số kg sản phẩm A và B xưởng sản xuất. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Điều kiện của $x$ và $y$ là $x \\ge 0, y \\ge 0$.", answer: true, solution: "Số lượng sản phẩm sản xuất không âm." },
          { id: "b", text: "Bất phương trình thể hiện giới hạn về nguyên liệu là $2x + 4y \\ge 200$.", answer: false, solution: "Nguyên liệu có tối đa 200 kg nên phải là $2x + 4y \\le 200$." },
          { id: "c", text: "Nếu lợi nhuận mỗi kg sản phẩm A là 30 nghìn đồng, sản phẩm B là 50 nghìn đồng thì hàm mục tiêu lợi nhuận là $F(x, y) = 30x + 50y$.", answer: true, solution: "Đúng, hàm mục tiêu lợi nhuận là $F(x, y) = 30x + 50y$." },
          { id: "d", text: "Để lợi nhuận lớn nhất, xưởng cần sản xuất số lượng 20 kg sản phẩm loại A.", answer: false, solution: "Giải hệ giao điểm $x + 2y = 100$ và $3x + 2y = 150 \\implies x = 25, y = 37.5$. Số lượng sản phẩm A cần sản xuất là 25 kg chứ không phải 20 kg." }
        ]
      },
      {
        id: 3,
        question: "Cho hình bình hành $ABCD$ tâm $O$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB} + \\vec{AD} = \\vec{AC}$.", answer: true, solution: "Đúng theo quy tắc hình bình hành." },
          { id: "b", text: "$\\vec{OA} = \\vec{OC}$.", answer: false, solution: "Hai vectơ đối nhau nên $\\vec{OA} = -\\vec{OC}$." },
          { id: "c", text: "$\\vec{AM} = \\frac{1}{2}\\vec{AB} + \\frac{1}{2}\\vec{AD}$ với $M$ là trung điểm của $BC$.", answer: false, solution: "Ta có $\\vec{AM} = \\vec{AB} + \\frac{1}{2}\\vec{AD}$." },
          { id: "d", text: "$|\\vec{AB} + \\vec{AD} + \\vec{AC}| = 2|\\vec{AC}|$.", answer: true, solution: "Vì $\\vec{AB} + \\vec{AD} = \\vec{AC} \\implies |\\vec{AC} + \\vec{AC}| = 2|\\vec{AC}|$." }
        ]
      },
      {
        id: 4,
        question: "Trong mặt phẳng $Oxy$, cho ba điểm $A(-1; 2), B(3; -1), C(4; 5)$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Tọa độ vectơ $\\vec{AB}$ là $(4; -3)$.", answer: true, solution: "$\\vec{AB} = (3 - (-1); -1 - 2) = (4; -3)$." },
          { id: "b", text: "Tổng $\\vec{AB} + \\vec{BC}$ có tọa độ là $(5; 3)$.", answer: true, solution: "$\\vec{AB} + \\vec{BC} = \\vec{AC} = (4 - (-1); 5 - 2) = (5; 3)$." },
          { id: "c", text: "Độ dài đoạn thẳng $AC$ bằng $\\sqrt{34}$.", answer: true, solution: "$AC = \\sqrt{5^2 + 3^2} = \\sqrt{34}$." },
          { id: "d", text: "Điểm $D$ để tứ giác $ABCD$ là hình bình hành có tọa độ là $D(0; 8)$.", answer: true, solution: "$\\vec{AD} = \\vec{BC} \\iff (x_D + 1; y_D - 2) = (1; 6) \\implies D(0; 8)$." }
        ]
      }
    ],
    part3: [
      {
        id: 1,
        question: "Một công ty dự định chi tối đa 160 triệu đồng cho quảng cáo trên đài phát thanh và truyền hình. Chi phí cho 1 phút quảng cáo trên đài phát thanh là 2 triệu đồng và trên truyền hình là 8 triệu đồng. Công ty yêu cầu thời lượng quảng cáo trên đài phát thanh không quá 40 phút và trên truyền hình tối thiểu 10 phút. Biết hiệu quả của 1 phút trên truyền hình gấp 3 lần 1 phút trên đài phát thanh. Hỏi công ty cần đặt bao nhiêu phút quảng cáo trên truyền hình để đạt hiệu quả tối đa? (làm tròn đến hàng đơn vị).",
        answer: "10",
        solution: "Gọi $x, y$ là số phút đài phát thanh và truyền hình. Hệ: $0 \\le x \\le 40; y \\ge 10; 2x + 8y \\le 160 \\iff x + 4y \\le 80$. Hàm hiệu quả $E = x + 3y$. Các đỉnh của miền nghiệm: $(0; 10) \\implies E = 30$; $(40; 10) \\implies E = 70$; $(0; 20) \\implies E = 60$. Giá trị lớn nhất đạt tại đỉnh $(40; 10)$ với $y = 10$ phút."
      },
      {
        id: 2,
        question: "Có bao nhiêu giá trị nguyên của tham số $m$ để điểm $M(m; m - 1)$ thuộc miền nghiệm của hệ bất phương trình $\\begin{cases} 2x - y \\ge 3 \\\\ x + 3y \\le 5 \\end{cases}$?",
        answer: "1",
        solution: "Thay $x = m, y = m - 1$: $2m - (m - 1) \\ge 3 \\iff m \\ge 2$; $m + 3(m - 1) \\le 5 \\iff 4m \\le 8 \\iff m \\le 2$. Suy ra $m = 2$. Có đúng 1 giá trị nguyên."
      },
      {
        id: 3,
        question: "Cho tam giác đều $ABC$ cạnh $a = 4$. Tính bình phương độ dài của vectơ $\\vec{u} = 2\\vec{AB} - \\vec{AC}$.",
        answer: "48",
        solution: "$|\\vec{u}|^2 = (2\\vec{AB} - \\vec{AC})^2 = 4AB^2 - 4\\vec{AB}\\cdot\\vec{AC} + AC^2 = 4(16) - 4(4 \\times 4 \\times 0.5) + 16 = 64 - 32 + 16 = 48$."
      },
      {
        id: 4,
        question: "Hai lực $\\vec{F}_1$ và $\\vec{F}_2$ cùng tác dụng vào một vật tại điểm $M$. Biết góc hợp bởi hai lực là $60^\\circ$ và cường độ của hai lực lần lượt là $|\\vec{F}_1| = 30\\text{ N}, |\\vec{F}_2| = 40\\text{ N}$. Tính cường độ của hợp lực tác dụng lên vật (làm tròn đến hàng đơn vị).",
        answer: "61",
        solution: "$F^2 = 30^2 + 40^2 + 2(30)(40)\\cos 60^\\circ = 900 + 1600 + 1200 = 3700 \\implies F = \\sqrt{3700} \\approx 60.83 \\approx 61\\text{ N}$."
      },
      {
        id: 5,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho bốn điểm $A(1; 1), B(3; 2), C(4; 0)$ và $D(8; 2)$. Phân tích vectơ $\\vec{AD}$ theo hai vectơ $\\vec{AB}$ và $\\vec{AC}$ ta được $\\vec{AD} = m\\vec{AB} + n\\vec{AC}$. Tính giá trị của biểu thức $P = m^2 + n^2$.",
        answer: "5",
        solution: "$\\vec{AB} = (2; 1), \\vec{AC} = (3; -1), \\vec{AD} = (7; 1)$. Giải hệ $2m + 3n = 7; m - n = 1 \\implies m = 2, n = 1$. Vậy $P = 2^2 + 1^2 = 5$."
      },
      {
        id: 6,
        question: "Trên màn hình radar giám sát không lưu (hệ trục tọa độ $Oxy$, đơn vị: km), một trạm điều khiển được đặt tại vị trí $A(2; 2)$. Hai thiết bị phát tín hiệu đang hoạt động tại các tọa độ $B(1; -3)$ và $C(-3; 0)$. Trạm điều khiển tự động điều hướng một máy bay không người lái (drone) đến vị trí $E(x_E; y_E)$ để giám sát, với thuật toán định tuyến yêu cầu vectơ hành trình thỏa mãn $\\vec{AE} = -2\\vec{AB} + 3\\vec{AC}$. Hãy tính giá trị của biểu thức $P = x_E \\cdot y_E$.",
        answer: "-66",
        solution: "$\\vec{AB} = (-1; -5), \\vec{AC} = (-5; -2)$. $\\vec{AE} = -2(-1; -5) + 3(-5; -2) = (-13; 4)$. Điểm $E$: $x_E = 2 - 13 = -11; y_E = 2 + 4 = 6$. Vậy $P = (-11) \\times 6 = -66$."
      }
    ]
  },

  // 1002
  {
    id: "1002",
    code: "1002",
    title: "ĐỀ THAM KHẢO SỐ 2 - Kiểm tra Tập trung lần III - Môn Toán 10",
    timeMinutes: 90,
    part1: [
      {
        id: 1,
        question: "Cặp số $(x; y)$ nào sau đây là nghiệm của bất phương trình $3x - 2y \\le 5$?",
        options: ["A. $(3; -1)$", "B. $(2; 1)$", "C. $(4; 0)$", "D. $(1; -3)$"],
        answer: "B",
        solution: "Thay $(2; 1)$ vào: $3(2) - 2(1) = 4 \\le 5$ (đúng)."
      },
      {
        id: 2,
        question: "Miền nghiệm của bất phương trình $x - 2y \\ge 0$ là nửa mặt phẳng bờ là đường thẳng $\\Delta: x - 2y = 0$ và chứa điểm nào sau đây?",
        options: ["A. $(1; 1)$", "B. $(0; 2)$", "C. $(2; 0)$", "D. $(-1; 1)$"],
        answer: "C",
        solution: "Thay $(2; 0)$ vào: $2 - 0 = 2 \\ge 0$ (đúng)."
      },
      {
        id: 3,
        question: "Cho các hệ điều kiện sau, hệ nào không phải là hệ bất phương trình bậc nhất hai ẩn?",
        options: [
          "A. $\\begin{cases} x \\ge 0 \\\\ x - y < 3 \\end{cases}$",
          "B. $\\begin{cases} 2x + y \\le 4 \\\\ x^2 - y > 0 \\end{cases}$",
          "C. $\\begin{cases} x + 5y \\ge 1 \\\\ 3x - 2y \\le 0 \\end{cases}$",
          "D. $\\begin{cases} y > 0 \\\\ x - y \\le 1 \\end{cases}$"
        ],
        answer: "B",
        solution: "Hệ B chứa số hạng bậc hai $x^2$."
      },
      {
        id: 4,
        question: "Điểm $P(-1; 2)$ thuộc miền nghiệm của hệ bất phương trình nào dưới đây?",
        options: [
          "A. $\\begin{cases} x + y > 0 \\\\ 2x - y < -3 \\end{cases}$",
          "B. $\\begin{cases} x - y \\ge 0 \\\\ x + 2y < 5 \\end{cases}$",
          "C. $\\begin{cases} 3x + y < 0 \\\\ x - y > -1 \\end{cases}$",
          "D. $\\begin{cases} x + y \\ge 2 \\\\ x - 2y \\le 0 \\end{cases}$"
        ],
        answer: "A",
        solution: "Thay $(-1; 2)$: $-1 + 2 = 1 > 0$ và $2(-1) - 2 = -4 < -3$."
      },
      {
        id: 5,
        question: "Vectơ-không là vectơ:",
        options: [
          "A. Có điểm đầu và điểm cuối trùng nhau.",
          "B. Có độ dài bằng 1.",
          "C. Cùng hướng với mọi vectơ.",
          "D. Cả A và C đều đúng."
        ],
        answer: "D",
        solution: "Theo quy ước SGK Toán 10, vectơ-không có điểm đầu trùng điểm cuối và cùng hướng với mọi vectơ."
      },
      {
        id: 6,
        question: "Cho hình bình hành $ABCD$. Mệnh đề nào sau đây đúng?",
        options: [
          "A. $\\vec{AB} - \\vec{AD} = \\vec{DB}$",
          "B. $\\vec{AB} + \\vec{AD} = \\vec{CA}$",
          "C. $\\vec{AB} + \\vec{BC} = \\vec{AD}$",
          "D. $\\vec{DA} + \\vec{DC} = \\vec{DB}$"
        ],
        answer: "D",
        solution: "Quy tắc hình bình hành từ đỉnh $D$: $\\vec{DA} + \\vec{DC} = \\vec{DB}$."
      },
      {
        id: 7,
        question: "Cho tam giác $ABC$ đều cạnh $a$. Độ dài của vectơ $\\vec{AB} + \\vec{AC}$ bằng:",
        options: ["A. $a\\sqrt{3}$", "B. $2a$", "C. $a$", "D. $a\\sqrt{2}$"],
        answer: "A",
        solution: "$\\vec{AB} + \\vec{AC} = 2\\vec{AM}$ (với $M$ là trung điểm $BC$). Chiều cao tam giác đều $AM = \\frac{a\\sqrt{3}}{2} \\implies$ độ dài là $a\\sqrt{3}$."
      },
      {
        id: 8,
        question: "Điều kiện cần và đủ để hai vectơ $\\vec{a}$ và $\\vec{b}$ ($\\vec{b} \\ne \\vec{0}$) cùng phương là:",
        options: [
          "A. Tồn tại số thực $k$ sao cho $\\vec{a} = k\\vec{b}$.",
          "B. $\\vec{a}$ và $\\vec{b}$ cùng độ dài.",
          "C. Tồn tại số thực $k > 0$ sao cho $\\vec{a} = k\\vec{b}$.",
          "D. $\\vec{a}$ và $\\vec{b}$ cùng hướng."
        ],
        answer: "A",
        solution: "Điều kiện cùng phương là tồn tại số thực $k$ để $\\vec{a} = k\\vec{b}$."
      },
      {
        id: 9,
        question: "Gọi $G$ là trọng tâm tam giác $ABC$. Phát biểu nào sau đây đúng?",
        options: [
          "A. $\\vec{GA} + \\vec{GB} + \\vec{GC} = \\vec{0}$",
          "B. $\\vec{AG} + \\vec{BG} + \\vec{CG} = \\vec{0}$",
          "C. $\\vec{GA} + \\vec{GB} = \\vec{GC}$",
          "D. Cả A và B đều đúng."
        ],
        answer: "D",
        solution: "Cả hai hệ thức $\\vec{GA} + \\vec{GB} + \\vec{GC} = \\vec{0}$ và $\\vec{AG} + \\vec{BG} + \\vec{CG} = \\vec{0}$ đều đúng."
      },
      {
        id: 10,
        question: "Trong hệ tọa độ $Oxy$, cho điểm $M(3; -4)$. Tọa độ của vectơ $\\vec{OM}$ là:",
        options: ["A. $(-3; 4)$", "B. $(3; 4)$", "C. $(3; -4)$", "D. $(-3; -4)$"],
        answer: "C",
        solution: "Tọa độ vectơ $\\vec{OM}$ trùng với tọa độ điểm $M(3; -4)$."
      },
      {
        id: 11,
        question: "Trong mặt phẳng $Oxy$, cho $\\vec{a} = (2; 1), \\vec{b} = (-1; 3)$. Tọa độ của vectơ $\\vec{c} = 2\\vec{a} - \\vec{b}$ là:",
        options: ["A. $(5; -1)$", "B. $(3; -1)$", "C. $(5; 1)$", "D. $(3; 1)$"],
        answer: "A",
        solution: "$\\vec{c} = 2(2; 1) - (-1; 3) = (4 - (-1); 2 - 3) = (5; -1)$."
      },
      {
        id: 12,
        question: "Cho hai điểm $A(2; 4)$ và $B(-4; 2)$. Tọa độ trung điểm $M$ của đoạn thẳng $AB$ là:",
        options: ["A. $(-1; 3)$", "B. $(3; 1)$", "C. $(-2; 6)$", "D. $(-1; -1)$"],
        answer: "A",
        solution: "$M = (\\frac{2 + (-4)}{2}; \\frac{4 + 2}{2}) = (-1; 3)$."
      }
    ],
    part2: [
      {
        id: 1,
        question: "Cho bất phương trình: $3x - 2y > 6$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Đường thẳng biên của miền nghiệm có phương trình là $3x - 2y - 6 = 0$.", answer: true, solution: "Đúng, phương trình biên là $3x - 2y - 6 = 0$." },
          { id: "b", text: "Điểm $M(2; 0)$ thuộc miền nghiệm của bất phương trình.", answer: false, solution: "Thay $(2; 0)$: $3(2) - 0 = 6 > 6$ (sai)." },
          { id: "c", text: "Gốc tọa độ $O(0; 0)$ không thuộc miền nghiệm của bất phương trình.", answer: true, solution: "Thay $(0; 0)$: $0 > 6$ (sai) nên $O$ không thuộc miền nghiệm." },
          { id: "d", text: "Miền nghiệm của bất phương trình là nửa mặt phẳng bờ là đường thẳng $\\Delta: 3x - 2y = 6$ (không kể $\\Delta$) và không chứa gốc tọa độ $O$.", answer: true, solution: "Đúng theo quy tắc xác định miền nghiệm." }
        ]
      },
      {
        id: 2,
        question: "Một xưởng mộc làm bàn và ghế. Một cái bàn cần 1.5 giờ công cắt và 1 giờ công lắp ráp; một cái ghế cần 1 giờ công cắt và 2 giờ công lắp ráp. Thời gian cắt tối đa là 15 giờ, thời gian lắp ráp tối đa là 20 giờ. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Gọi $x, y$ là số bàn và ghế, ta có $x \\ge 0, y \\ge 0$.", answer: true, solution: "Số bàn và số ghế là đại lượng không âm." },
          { id: "b", text: "Điều kiện về thời gian cắt là $1.5x + y \\le 15$.", answer: true, solution: "Đúng theo đề bài: $1.5x + y \\le 15$." },
          { id: "c", text: "Nếu lãi mỗi cái bàn là 300 ngàn, mỗi cái ghế là 200 ngàn thì hàm mục tiêu là $F = 300x + 200y$.", answer: true, solution: "Hàm lợi nhuận là $F = 300x + 200y$." },
          { id: "d", text: "Phương án tối ưu để xưởng mộc thu lãi nhiều nhất là sản xuất 10 bàn và 0 ghế.", answer: true, solution: "Lợi nhuận tại $(10; 0)$ là $F = 3000$ nghìn đồng, bằng giá trị lớn nhất." }
        ]
      },
      {
        id: 3,
        question: "Cho tam giác $ABC$. Gọi $M, N$ lần lượt là trung điểm của $AB, AC$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{MN} = \\frac{1}{2}\\vec{BC}$.", answer: true, solution: "Tính chất đường trung bình trong tam giác." },
          { id: "b", text: "$\\vec{BM} = \\vec{MA}$.", answer: true, solution: "$M$ là trung điểm $AB$ nên $\\vec{BM} = \\vec{MA}$." },
          { id: "c", text: "$\\vec{CM} + \\vec{BN} = \\frac{3}{2}\\vec{CB}$.", answer: false, solution: "Hệ thức vectơ này sai." },
          { id: "d", text: "Độ dài $|\\vec{AM} + \\vec{AN}| = \\frac{1}{2}|\\vec{AB} + \\vec{AC}|$.", answer: true, solution: "$\\vec{AM} + \\vec{AN} = \\frac{1}{2}(\\vec{AB} + \\vec{AC})$." }
        ]
      },
      {
        id: 4,
        question: "Trong hệ tọa độ $Oxy$, cho $A(-2; 1), B(1; 5), C(4; 1)$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Tọa độ $\\vec{AB} = (3; 4)$.", answer: true, solution: "$\\vec{AB} = (1 - (-2); 5 - 1) = (3; 4)$." },
          { id: "b", text: "Khoảng cách giữa hai điểm $A$ và $B$ bằng 5.", answer: true, solution: "$AB = \\sqrt{3^2 + 4^2} = 5$." },
          { id: "c", text: "Tọa độ vectơ $\\vec{BC} = (-3; 4)$.", answer: false, solution: "$\\vec{BC} = (4 - 1; 1 - 5) = (3; -4) \\ne (-3; 4)$." },
          { id: "d", text: "Điểm $K$ nằm trên trục $Oy$ sao cho ba điểm $A, B, K$ thẳng hàng thì $K(0; \\frac{11}{3})$.", answer: true, solution: "$\\vec{AK} = (2; y - 1)$ cùng phương $(3; 4) \\implies \\frac{2}{3} = \\frac{y - 1}{4} \\implies y = \\frac{11}{3}$." }
        ]
      }
    ],
    part3: [
      {
        id: 1,
        question: "Một học sinh dự định vẽ các tấm thiệp xuân làm bằng tay để bán trong một hội chợ Tết. Cần 2 giờ để vẽ một tấm thiệp loại nhỏ có giá 15 nghìn đồng và 3 giờ để vẽ một tấm thiệp loại lớn có giá 25 nghìn đồng. Học sinh này chỉ có 30 giờ để vẽ và ban tổ chức hội chợ yêu cầu phải vẽ ít nhất 12 tấm. Bạn ấy đã vẽ mỗi loại một số thiệp để được số tiền nhiều nhất có thể, vậy số tiền đó là bao nhiêu nghìn đồng?",
        answer: "240",
        solution: "Hệ: $2x + 3y \\le 30; x + y \\ge 12$. Đỉnh tối ưu $(6; 6)$ cho $F = 15(6) + 25(6) = 240$ nghìn đồng."
      },
      {
        id: 2,
        question: "Biết miền nghiệm của hệ bất phương trình $\\begin{cases} x - 2y \\le 4 \\\\ x + y \\ge -1 \\\\ y \\le m \\end{cases}$ chứa điểm $A(1; 2)$. Tìm giá trị nhỏ nhất của tham số $m$.",
        answer: "2",
        solution: "Thay tọa độ $A(1; 2)$: $y \\le m \\implies 2 \\le m \\iff m \\ge 2$. Vậy $m_{\\min} = 2$."
      },
      {
        id: 3,
        question: "Cho hình chữ nhật $ABCD$ có $AB = 3, AD = 4$. Tính bình phương độ dài của vectơ $\\vec{v} = \\vec{AB} + 2\\vec{AD}$.",
        answer: "73",
        solution: "$|\\vec{v}|^2 = AB^2 + 4AD^2 = 3^2 + 4(4^2) = 9 + 64 = 73$."
      },
      {
        id: 4,
        question: "Ba lực $\\vec{F}_1, \\vec{F}_2$ và $\\vec{F}_3$ cùng tác dụng vào một vật tại điểm $M$. Biết góc hợp bởi $\\vec{F}_1$ và $\\vec{F}_2$ là $90^\\circ$, lực $\\vec{F}_3$ ngược hướng với lực $\\vec{F}_1$. Cường độ của ba lực lần lượt là $|\\vec{F}_1| = 50\\text{ N}, |\\vec{F}_2| = 40\\text{ N}$ và $|\\vec{F}_3| = 20\\text{ N}$. Tính cường độ của hợp lực tác dụng lên vật.",
        answer: "50",
        solution: "Hợp lực $\\vec{F}_{13} = \\vec{F}_1 + \\vec{F}_3$ có độ lớn $50 - 20 = 30\\text{ N}$. Do $\\vec{F}_{13} \\perp \\vec{F}_2$, hợp lực tổng cộng $F = \\sqrt{30^2 + 40^2} = 50\\text{ N}$."
      },
      {
        id: 5,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho tam giác $ABC$ có các đỉnh $A(1; 1), B(2; 4), C(6; 1)$ và điểm $D(0; 8)$. Gọi $G$ là trọng tâm của tam giác $ABC$. Phân tích vectơ $\\vec{GD}$ theo hai vectơ $\\vec{AB}$ và $\\vec{AC}$ ta được $\\vec{GD} = m\\vec{AB} + n\\vec{AC}$. Tính giá trị của biểu thức $S = m + n$.",
        answer: "1",
        solution: "Trọng tâm $G(3; 2)$. $\\vec{GD} = (-3; 6), \\vec{AB} = (1; 3), \\vec{AC} = (5; 0) \\implies m = 2, n = -1 \\implies S = 2 + (-1) = 1$."
      },
      {
        id: 6,
        question: "Trên màn hình ra-đa của đài kiểm soát không lưu (được xem như mặt phẳng tọa độ $Oxy$ với đơn vị tính theo ki-lô-mét), một máy bay trực thăng chuyển động thẳng đều từ thành phố $A(900; 400)$ đến thành phố $B(300; 700)$, thời gian bay quãng đường $AB$ là 4 giờ. Gọi tọa độ của máy bay trực thăng tại thời điểm sau khi xuất phát 3 giờ là $(a; b)$. Tính $P = a + b$.",
        answer: "1075",
        solution: "Sau 3 giờ: $\\vec{AM} = \\frac{3}{4}\\vec{AB} = \\frac{3}{4}(-600; 300) = (-450; 225) \\implies a = 450, b = 625 \\implies P = 450 + 625 = 1075$."
      }
    ]
  },

  // 1003
  {
    id: "1003",
    code: "1003",
    title: "ĐỀ THAM KHẢO SỐ 3 - Kiểm tra Tập trung lần III - Môn Toán 10",
    timeMinutes: 90,
    part1: [
      {
        id: 1,
        question: "Điểm nào dưới đây thuộc miền nghiệm của bất phương trình $x - y \\ge 2$?",
        options: ["A. $(1; 2)$", "B. $(3; 1)$", "C. $(0; 2)$", "D. $(0; 0)$"],
        answer: "B",
        solution: "Thay $(3; 1)$ vào: $3 - 1 = 2 \\ge 2$ (thỏa mãn)."
      },
      {
        id: 2,
        question: "Miền không bị gạch (kể cả bờ $\\Delta$) trong mặt phẳng tọa độ biểu diễn miền nghiệm của bất phương trình nào? Biết bờ $\\Delta$ đi qua hai điểm $(0; 2)$ và $(2; 0)$, miền nghiệm chứa gốc tọa độ.",
        options: ["A. $x + y \\le 2$", "B. $x + y \\ge 2$", "C. $x - y \\le 2$", "D. $x - y \\ge 2$"],
        answer: "A",
        solution: "Đường thẳng qua $(0; 2)$ và $(2; 0)$ là $x + y = 2$. Vì chứa gốc tọa độ $(0; 0)$ nên bất phương trình là $x + y \\le 2$."
      },
      {
        id: 3,
        question: "Hệ nào sau đây là hệ bất phương trình bậc nhất hai ẩn?",
        options: [
          "A. $\\begin{cases} x - 3y > 0 \\\\ x^2 + y \\le 5 \\end{cases}$",
          "B. $\\begin{cases} 2x + 3y = 4 \\\\ x - y \\ge 1 \\end{cases}$",
          "C. $\\begin{cases} x + y > 0 \\\\ 3x - 4y \\le 2 \\end{cases}$",
          "D. $\\begin{cases} x > 0 \\\\ y^2 - 1 \\le 0 \\end{cases}$"
        ],
        answer: "C",
        solution: "Hệ C gồm hai bất phương trình bậc nhất hai ẩn."
      },
      {
        id: 4,
        question: "Cặp số $(2; -1)$ thuộc miền nghiệm của hệ bất phương trình nào sau đây?",
        options: [
          "A. $\\begin{cases} x + y \\ge 1 \\\\ 2x - y \\le 4 \\end{cases}$",
          "B. $\\begin{cases} x - y > 2 \\\\ x + 2y < 1 \\end{cases}$",
          "C. $\\begin{cases} 2x + y > 0 \\\\ x - 3y > 6 \\end{cases}$",
          "D. $\\begin{cases} x \\ge 3 \\\\ y \\le 0 \\end{cases}$"
        ],
        answer: "B",
        solution: "Thay $x = 2, y = -1$: $2 - (-1) = 3 > 2$ và $2 + 2(-1) = 0 < 1$."
      },
      {
        id: 5,
        question: "Độ dài của vectơ $\\vec{a}$ được kí hiệu là:",
        options: ["A. $|\\vec{a}|$", "B. $\\vec{|a|}$", "C. $a$", "D. $(\\vec{a})$"],
        answer: "A",
        solution: "Kí hiệu chuẩn của độ dài vectơ $\\vec{a}$ là $|\\vec{a}|$."
      },
      {
        id: 6,
        question: "Quy tắc hình bình hành áp dụng cho phép toán nào của vectơ?",
        options: [
          "A. Phép trừ hai vectơ.",
          "B. Phép cộng hai vectơ chung gốc.",
          "C. Phép nhân vectơ với một số.",
          "D. Phép chia vectơ."
        ],
        answer: "B",
        solution: "Quy tắc hình bình hành dùng để tính tổng hai vectơ có chung gốc: $\\vec{AB} + \\vec{AD} = \\vec{AC}$."
      },
      {
        id: 7,
        question: "Cho hình thoi $ABCD$ cạnh $a$, góc $\\widehat{BAD} = 60^\\circ$. Tính độ dài vectơ $\\vec{AB} + \\vec{AD}$.",
        options: ["A. $a$", "B. $a\\sqrt{3}$", "C. $a\\sqrt{2}$", "D. $2a$"],
        answer: "B",
        solution: "$\\vec{AB} + \\vec{AD} = \\vec{AC} = 2 \\times \\frac{a\\sqrt{3}}{2} = a\\sqrt{3}$."
      },
      {
        id: 8,
        question: "Điểm $C$ thuộc đoạn thẳng $AB$ sao cho $AC = 3CB$. Khẳng định nào sau đây đúng?",
        options: [
          "A. $\\vec{AC} = 3\\vec{CB}$",
          "B. $\\vec{AC} = \\frac{3}{4}\\vec{AB}$",
          "C. $\\vec{AB} = \\frac{4}{3}\\vec{AC}$",
          "D. Cả A, B, C đều đúng."
        ],
        answer: "D",
        solution: "Cả ba khẳng định đều diễn đạt chính xác mối quan hệ giữa các vectơ."
      },
      {
        id: 9,
        question: "Cho $I$ là trung điểm của đoạn thẳng $AB$. Với điểm $M$ bất kì, mệnh đề nào đúng?",
        options: [
          "A. $\\vec{MA} + \\vec{MB} = \\vec{MI}$",
          "B. $\\vec{MA} + \\vec{MB} = 2\\vec{MI}$",
          "C. $\\vec{MA} + \\vec{MB} = 3\\vec{MI}$",
          "D. $\\vec{MA} + \\vec{MB} = \\frac{1}{2}\\vec{MI}$"
        ],
        answer: "B",
        solution: "Công thức trung điểm cơ bản: $\\vec{MA} + \\vec{MB} = 2\\vec{MI}$."
      },
      {
        id: 10,
        question: "Trong mặt phẳng $Oxy$, cho điểm $A(-1; 3)$ và $B(2; -4)$. Tọa độ vectơ $\\vec{AB}$ là:",
        options: ["A. $(3; -7)$", "B. $(-3; 7)$", "C. $(1; -1)$", "D. $(1; 7)$"],
        answer: "A",
        solution: "$\\vec{AB} = (2 - (-1); -4 - 3) = (3; -7)$."
      },
      {
        id: 11,
        question: "Cho $\\vec{u} = (2; -1)$ và $\\vec{v} = (-3; 4)$. Tích của số 2 với vectơ $\\vec{v}$ có tọa độ là:",
        options: ["A. $(-6; 8)$", "B. $(4; -2)$", "C. $(-1; 3)$", "D. $(-5; 5)$"],
        answer: "A",
        solution: "$2\\vec{v} = 2(-3; 4) = (-6; 8)$."
      },
      {
        id: 12,
        question: "Trong mặt phẳng $Oxy$, cho tam giác $ABC$ có trọng tâm $G(1; 2)$ và hai đỉnh $A(-1; 0), B(2; 4)$. Tọa độ đỉnh $C$ là:",
        options: ["A. $(2; 2)$", "B. $(0; 6)$", "C. $(1; 4)$", "D. $(2; -2)$"],
        answer: "A",
        solution: "$x_C = 3(1) - (-1) - 2 = 2; y_C = 3(2) - 0 - 4 = 2 \\implies C(2; 2)$."
      }
    ],
    part2: [
      {
        id: 1,
        question: "Cho bất phương trình: $2x + 5y \\le 10$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Đường thẳng biên của miền nghiệm có phương trình là $2x + 5y - 10 = 0$.", answer: true, solution: "Đúng, phương trình biên là $2x + 5y - 10 = 0$." },
          { id: "b", text: "Điểm $A(5; 1)$ thuộc miền nghiệm của bất phương trình.", answer: false, solution: "Thay $(5; 1)$ vào: $2(5) + 5(1) = 15 \\le 10$ (sai)." },
          { id: "c", text: "Gốc tọa độ $O(0; 0)$ thuộc miền nghiệm của bất phương trình.", answer: true, solution: "Thay $(0; 0)$ vào: $0 \\le 10$ (đúng)." },
          { id: "d", text: "Miền nghiệm của bất phương trình là nửa mặt phẳng bờ là đường thẳng $\\Delta: 2x + 5y = 10$ (kể cả bờ $\\Delta$) và chứa gốc tọa độ $O$.", answer: true, solution: "Đúng theo lý thuyết miền nghiệm." }
        ]
      },
      {
        id: 2,
        question: "Một cửa hàng bán hai loại nước quả A và B. Một lít nước quả A cần 20g đường và 10g hương liệu; một lít nước quả B cần 10g đường và 30g hương liệu. Cửa hàng có tối đa 200g đường và 240g hương liệu. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Gọi $x, y$ là số lít nước quả A và B, điều kiện ranh giới là $20x + 10y \\le 200$.", answer: true, solution: "Ràng buộc về đường là $20x + 10y \\le 200$." },
          { id: "b", text: "Nếu lợi nhuận mỗi lít nước quả A là 40k, loại B là 50k, hàm mục tiêu là $F = 40x + 50y$.", answer: true, solution: "Đúng công thức hàm mục tiêu." },
          { id: "c", text: "Điểm $(x; y) = (5; 5)$ thỏa mãn tất cả các điều kiện ràng buộc nguyên liệu.", answer: true, solution: "Thay $(5; 5)$ đều nhỏ hơn hoặc bằng 200 và 240." },
          { id: "d", text: "Giá trị lớn nhất của lợi nhuận đạt được khi cửa hàng chỉ bán loại B.", answer: false, solution: "Giá trị lớn nhất đạt tại điểm phối hợp cả hai loại (568k), lớn hơn chỉ bán loại B (400k)." }
        ]
      },
      {
        id: 3,
        question: "Cho tứ giác $ABCD$ có $I, J$ lần lượt là trung điểm của $AB, CD$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB} + \\vec{BC} + \\vec{CD} = \\vec{AD}$.", answer: true, solution: "Quy tắc cộng vectơ liên tiếp." },
          { id: "b", text: "$\\vec{AC} + \\vec{BD} = 2\\vec{IJ}$.", answer: true, solution: "Hệ thức trung điểm trong tứ giác." },
          { id: "c", text: "$\\vec{AD} + \\vec{BC} = 2\\vec{IJ}$.", answer: true, solution: "Hệ thức trung điểm cạnh đối." },
          { id: "d", text: "Nếu $\\vec{AB} = \\vec{DC}$ thì $ABCD$ luôn là hình chữ nhật.", answer: false, solution: "Chỉ suy ra được $ABCD$ là hình bình hành." }
        ]
      },
      {
        id: 4,
        question: "Trong mặt phẳng $Oxy$, cho $A(3; 2), B(-1; 5)$ và $\\vec{v} = (2; -3)$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Tọa độ điểm $M$ sao cho $\\vec{AM} = \\vec{v}$ là $M(5; -1)$.", answer: true, solution: "$M = (3 + 2; 2 - 3) = (5; -1)$." },
          { id: "b", text: "Khoảng cách từ $A$ đến $B$ bằng 5.", answer: true, solution: "$AB = \\sqrt{(-4)^2 + 3^2} = 5$." },
          { id: "c", text: "Tọa độ vectơ $\\vec{AB}$ là $(-4; 3)$.", answer: true, solution: "$\\vec{AB} = (-1 - 3; 5 - 2) = (-4; 3)$." },
          { id: "d", text: "Điểm $C$ trên trục $Ox$ sao cho tam giác $ABC$ vuông tại $A$ có hoành độ $C(2; 0)$.", answer: false, solution: "Tọa độ đúng là $C(1.5; 0)$ chứ không phải $(2; 0)$." }
        ]
      }
    ],
    part3: [
      {
        id: 1,
        question: "Để gây quỹ từ thiện, câu lạc bộ tình nguyện của một trường THPT tổ chức hoạt động bán nước chanh và khoai tây chiên. Câu lạc bộ thiết kế hai thực đơn: Thực đơn 1 giá 35 nghìn đồng (2 cốc nước chanh, 1 túi khoai tây chiên); Thực đơn 2 giá 60 nghìn đồng (3 cốc nước chanh, 2 túi khoai tây chiên). Biết câu lạc bộ chỉ làm được không quá 165 cốc nước chanh và 100 túi khoai tây chiên. Số tiền lớn nhất mà câu lạc bộ có thể nhận được sau khi bán hết hàng bằng bao nhiêu nghìn đồng?",
        answer: "3150",
        solution: "Giải hệ giao điểm $2x + 3y = 165$ và $x + 2y = 100 \\implies x = 30, y = 35$. Số tiền lớn nhất là $35(30) + 60(35) = 3150$ nghìn đồng."
      },
      {
        id: 2,
        question: "Có bao nhiêu giá trị nguyên của tham số $m \\in [-5; 5]$ để điểm $M(m; -2)$ thuộc miền nghiệm của hệ bất phương trình $\\begin{cases} x + y \\le 2 \\\\ 2x - 3y > -1 \\end{cases}$?",
        answer: "8",
        solution: "Thay $x = m, y = -2$: $m - 2 \\le 2 \\iff m \\le 4$ và $2m + 6 > -1 \\iff m > -3.5$. Vì $m \\in [-5; 5]$ và $m \\in \\mathbb{Z}$ nên $m \\in \\{-3; -2; -1; 0; 1; 2; 3; 4\\}$. Có 8 giá trị nguyên."
      },
      {
        id: 3,
        question: "Cho tam giác $ABC$ vuông tại $A$, có $AB = 3, AC = 4$. Tính bình phương độ dài của vectơ $\\vec{u} = \\frac{1}{3}\\vec{AB} + \\frac{1}{4}\\vec{AC}$.",
        answer: "2",
        solution: "$|\\vec{u}|^2 = \\frac{1}{9}AB^2 + \\frac{1}{16}AC^2 = \\frac{1}{9}(9) + \\frac{1}{16}(16) = 1 + 1 = 2$."
      },
      {
        id: 4,
        question: "Một vật chịu tác dụng của một lực $\\vec{F}$ có độ lớn $100\\text{ N}$ làm vật di chuyển một đoạn đường thẳng $s = 5\\text{ m}$. Biết góc tạo bởi hướng của lực và hướng chuyển động là $60^\\circ$. Tính công sinh bởi lực $\\vec{F}$ (đơn vị: Jun).",
        answer: "250",
        solution: "$A = F \\cdot s \\cdot \\cos 60^\\circ = 100 \\times 5 \\times 0.5 = 250\\text{ J}$."
      },
      {
        id: 5,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho ba điểm $A(0; 2), B(4; 0), C(2; -4)$ và điểm $K(7; -4)$. Gọi $M$ là trung điểm của đoạn thẳng $BC$. Phân tích vectơ $\\vec{AK}$ theo hai vectơ $\\vec{AM}$ và $\\vec{BC}$ ta được $\\vec{AK} = x\\vec{AM} + y\\vec{BC}$. Tính giá trị của biểu thức $P = x \\cdot y$.",
        answer: "-1",
        solution: "$M(3; -2) \\implies \\vec{AM} = (3; -4), \\vec{BC} = (-2; -4), \\vec{AK} = (7; -6)$. Giải hệ $3x - 2y = 7; -4x - 4y = -6 \\implies x = 2, y = -0.5 \\implies P = 2 \\times (-0.5) = -1$."
      },
      {
        id: 6,
        question: "Một công ty logistics quản lý ba kho hàng tại các vị trí $A(1; 1), B(2; -1)$ và $C(4; 3)$. Công ty dự kiến xây dựng một trạm trung chuyển trung tâm $M(a; b)$ sao cho hệ thống đạt trạng thái cân bằng lực thỏa mãn $\\vec{MA} + 2\\vec{MB} + \\vec{MC} = \\vec{0}$. Tính tổng $a + b$ của điểm tập kết này.",
        answer: "2.75",
        solution: "Tọa độ tâm tỉ cự: $a = \\frac{1 + 2(2) + 4}{4} = 2.25; b = \\frac{1 + 2(-1) + 3}{4} = 0.5 \\implies a + b = 2.75$."
      }
    ]
  },

  // 1004
  {
    id: "1004",
    code: "1004",
    title: "ĐỀ THAM KHẢO SỐ 4 - Kiểm tra Tập trung lần III - Môn Toán 10",
    timeMinutes: 90,
    part1: [
      {
        id: 1,
        question: "Cặp số nào sau đây không là nghiệm của bất phương trình $x - 4y > 5$?",
        options: ["A. $(6; 0)$", "B. $(10; 1)$", "C. $(5; 0)$", "D. $(8; 0)$"],
        answer: "C",
        solution: "Thay $(5; 0)$ vào: $5 - 4(0) = 5 > 5$ là mệnh đề sai."
      },
      {
        id: 2,
        question: "Nửa mặt phẳng không bị gạch chéo (kể cả bờ) biểu diễn miền nghiệm của $2x - y \\le 4$. Điểm nào thuộc miền nghiệm?",
        options: ["A. $(3; 0)$", "B. $(0; -5)$", "C. $(1; 1)$", "D. $(5; 2)$"],
        answer: "C",
        solution: "Thay $(1; 1)$: $2(1) - 1 = 1 \\le 4$ (đúng)."
      },
      {
        id: 3,
        question: "Cho tam giác $ABC$. Vectơ tổng $\\vec{AB} + \\vec{BC} + \\vec{CA}$ bằng:",
        options: ["A. $\\vec{0}$", "B. $2\\vec{AB}$", "C. $3\\vec{AC}$", "D. $\\vec{AA}$"],
        answer: "A",
        solution: "$\\vec{AB} + \\vec{BC} + \\vec{CA} = \\vec{AC} + \\vec{CA} = \\vec{0}$."
      },
      {
        id: 4,
        question: "Cho hình bình hành $ABCD$. Đẳng thức nào sau đây đúng?",
        options: ["A. $\\vec{AB} = \\vec{CD}$", "B. $\\vec{AB} = \\vec{DC}$", "C. $\\vec{AD} = \\vec{CB}$", "D. $\\vec{AC} = \\vec{BD}$"],
        answer: "B",
        solution: "Hai vectơ $\\vec{AB}$ và $\\vec{DC}$ cùng hướng và cùng độ dài."
      },
      {
        id: 5,
        question: "Cho đoạn thẳng $AB$ có độ dài bằng $6$. Gọi $M$ là trung điểm của $AB$. Độ dài của vectơ $\\vec{MA}$ là:",
        options: ["A. 6", "B. 3", "C. -3", "D. 12"],
        answer: "B",
        solution: "$|\\vec{MA}| = MA = \\frac{6}{2} = 3$."
      },
      {
        id: 6,
        question: "Trong mặt phẳng $Oxy$, cho $\\vec{a} = (-2; 5)$ và $\\vec{b} = (4; 1)$. Tọa độ của vectơ $\\vec{a} + \\vec{b}$ là:",
        options: ["A. $(2; 6)$", "B. $(-6; 4)$", "C. $(2; 4)$", "D. $(6; 6)$"],
        answer: "A",
        solution: "$\\vec{a} + \\vec{b} = (-2 + 4; 5 + 1) = (2; 6)$."
      },
      {
        id: 7,
        question: "Cho hình vuông $ABCD$ có cạnh bằng 2. Tích vô hướng $\\vec{AB} \\cdot \\vec{AD}$ bằng:",
        options: ["A. 4", "B. 2", "C. 0", "D. -4"],
        answer: "C",
        solution: "Vì $AB \\perp AD$ nên tích vô hướng bằng 0."
      },
      {
        id: 8,
        question: "Cho $\\vec{u} = 3\\vec{i} + 4\\vec{j}$. Độ dài của vectơ $\\vec{u}$ bằng:",
        options: ["A. 7", "B. 5", "C. 1", "D. 25"],
        answer: "B",
        solution: "$|\\vec{u}| = \\sqrt{3^2 + 4^2} = 5$."
      },
      {
        id: 9,
        question: "Cho hai điểm $A(1; 3)$ và $B(-3; 5)$. Tọa độ trung điểm $I$ của $AB$ là:",
        options: ["A. $(-1; 4)$", "B. $(-2; 8)$", "C. $(2; 1)$", "D. $(-4; 2)$"],
        answer: "A",
        solution: "$I = (\\frac{1 + (-3)}{2}; \\frac{3 + 5}{2}) = (-1; 4)$."
      },
      {
        id: 10,
        question: "Miền nghiệm của hệ $\\begin{cases} x \\ge 0 \\\\ y \\ge 0 \\\\ x + y \\le 3 \\end{cases}$ là một hình tam giác có diện tích bằng:",
        options: ["A. 9", "B. 4.5", "C. 3", "D. 6"],
        answer: "B",
        solution: "Tam giác vuông tại gốc $O(0; 0)$ có hai cạnh góc vuông độ dài 3. Diện tích $S = \\frac{1}{2}(3)(3) = 4.5$."
      },
      {
        id: 11,
        question: "Cho tam giác đều $ABC$ cạnh bằng 6. Tích vô hướng $\\vec{AB} \\cdot \\vec{AC}$ bằng:",
        options: ["A. 18", "B. $18\\sqrt{3}$", "C. 36", "D. 9"],
        answer: "A",
        solution: "$\\vec{AB}\\cdot\\vec{AC} = 6 \\times 6 \\times \\cos 60^\\circ = 36 \\times 0.5 = 18$."
      },
      {
        id: 12,
        question: "Cho ba điểm $A(-2; 1), B(0; 3), C(2; 5)$. Khẳng định nào sau đây đúng?",
        options: [
          "A. Tam giác $ABC$ vuông tại $B$",
          "B. $A, B, C$ thẳng hàng và $B$ là trung điểm $AC$",
          "C. $A, B, C$ tạo thành tam giác đều",
          "D. $A, B, C$ không thẳng hàng"
        ],
        answer: "B",
        solution: "$\\vec{AB} = (2; 2), \\vec{BC} = (2; 2) \\implies \\vec{AB} = \\vec{BC}$, do đó $B$ là trung điểm $AC$."
      }
    ],
    part2: [
      {
        id: 1,
        question: "Cho bất phương trình bậc nhất hai ẩn: $2x - 3y + 6 \\ge 0$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Điểm $O(0; 0)$ thuộc miền nghiệm của bất phương trình.", answer: true, solution: "$2(0) - 3(0) + 6 = 6 \\ge 0$ (đúng)." },
          { id: "b", text: "Đường thẳng biên $d: 2x - 3y + 6 = 0$ cắt trục hoành tại điểm $(-3; 0)$.", answer: true, solution: "Cho $y = 0 \\implies 2x + 6 = 0 \\implies x = -3$." },
          { id: "c", text: "Điểm $M(1; 3)$ thuộc miền nghiệm của bất phương trình.", answer: false, solution: "$2(1) - 3(3) + 6 = -1 \\ge 0$ (sai)." },
          { id: "d", text: "Miền nghiệm của bất phương trình không chứa điểm $N(0; 4)$.", answer: true, solution: "$2(0) - 3(4) + 6 = -6 < 0$ nên không thuộc miền nghiệm." }
        ]
      },
      {
        id: 2,
        question: "Một cơ sở sản xuất nước tương và dầu hào cần hai loại nguyên liệu chính là hạt đậu tương và mè đen. Để làm 1 chai nước tương cần 100g đậu và 20g mè. Để làm 1 chai dầu hào cần 50g đậu và 40g mè. Cơ sở hiện có 2000g đậu và 800g mè. Gọi $x, y$ lần lượt là số chai nước tương và dầu hào sản xuất. Xét tính đúng, sai của các mệnh đề:",
        statements: [
          { id: "a", text: "Điều kiện nguyên liệu đậu tương là $100x + 50y \\le 2000$.", answer: true, solution: "Đúng theo lượng đậu tương tối đa 2000g." },
          { id: "b", text: "Điều kiện nguyên liệu mè đen là $20x + 40y \\le 800$.", answer: true, solution: "Đúng theo lượng mè đen tối đa 800g." },
          { id: "c", text: "Cơ sở có thể sản xuất cùng lúc 15 chai nước tương và 15 chai dầu hào.", answer: false, solution: "Cần $100(15) + 50(15) = 2250\\text{ g} > 2000\\text{ g}$ đậu tương nên không thể." },
          { id: "d", text: "Nếu bán mỗi chai nước tương lãi 20 nghìn đồng và mỗi chai dầu hào lãi 25 nghìn đồng, lợi nhuận tối đa đạt được là 450 nghìn đồng.", answer: false, solution: "Lợi nhuận lớn nhất đạt tới 500 nghìn đồng trở lên (tại $x=13, y=13$ đạt 585k)." }
        ]
      },
      {
        id: 3,
        question: "Cho tam giác $ABC$ có trọng tâm $G$. Gọi $M$ là trung điểm của $BC$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AG} = \\frac{2}{3}\\vec{AM}$.", answer: true, solution: "Tính chất trọng tâm chuẩn." },
          { id: "b", text: "$\\vec{GA} + \\vec{GB} + \\vec{GC} = \\vec{0}$.", answer: true, solution: "Tính chất trọng tâm đối với ba đỉnh." },
          { id: "c", text: "$\\vec{GB} + \\vec{GC} = 2\\vec{GM}$.", answer: true, solution: "$M$ là trung điểm cạnh $BC$ nên $\\vec{GB} + \\vec{GC} = 2\\vec{GM}$." },
          { id: "d", text: "$\\vec{AB} + \\vec{AC} = 3\\vec{AG}$.", answer: true, solution: "$\\vec{AB} + \\vec{AC} = 2\\vec{AM} = 3\\vec{AG}$." }
        ]
      },
      {
        id: 4,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho ba điểm $A(1; 2), B(-2; 6), C(9; 8)$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB} = (-3; 4)$.", answer: true, solution: "$-2 - 1 = -3; 6 - 2 = 4$." },
          { id: "b", text: "$\\vec{AC} = (8; 6)$.", answer: true, solution: "$9 - 1 = 8; 8 - 2 = 6$." },
          { id: "c", text: "Tam giác $ABC$ vuông tại $A$.", answer: true, solution: "$\\vec{AB} \\cdot \\vec{AC} = -3(8) + 4(6) = 0$." },
          { id: "d", text: "Diện tích tam giác $ABC$ bằng 25.", answer: true, solution: "$AB = 5, AC = 10 \\implies S = \\frac{1}{2}(5)(10) = 25$." }
        ]
      }
    ],
    part3: [
      {
        id: 1,
        question: "Bác nông dân có mảnh đất dự định trồng cà chua và dưa leo với diện tích tối đa 8 sào. Chi phí giống cho 1 sào cà chua là 2 triệu đồng, 1 sào dưa leo là 1 triệu đồng. Bác chỉ có tối đa 11 triệu đồng tiền giống. Lợi nhuận mỗi sào cà chua là 7 triệu đồng, mỗi sào dưa leo là 4 triệu đồng. Hỏi lợi nhuận lớn nhất mà bác nông dân có thể thu được là bao nhiêu triệu đồng?",
        answer: "41",
        solution: "Hệ: $x + y \\le 8; 2x + y \\le 11$. Đỉnh tối ưu $(3; 5) \\implies L = 7(3) + 4(5) = 41$ triệu đồng."
      },
      {
        id: 2,
        question: "Cho hình chữ nhật $ABCD$ có $AB = 6, AD = 8$. Gọi $O$ là giao điểm của hai đường chéo. Tính độ dài vectơ $\\vec{u} = \\vec{OA} + \\vec{OB} + \\vec{OC} + \\vec{OD}$.",
        answer: "0",
        solution: "Vì $O$ là tâm hình chữ nhật nên $\\vec{OA} + \\vec{OC} = \\vec{0}$ và $\\vec{OB} + \\vec{OD} = \\vec{0} \\implies |\\vec{u}| = 0$."
      },
      {
        id: 3,
        question: "Trong mặt phẳng $Oxy$, cho hai vectơ $\\vec{a} = (m - 1; 2)$ và $\\vec{b} = (3; -6)$. Tìm giá trị của $m$ để hai vectơ $\\vec{a}$ và $\\vec{b}$ vuông góc với nhau.",
        answer: "5",
        solution: "$3(m - 1) + 2(-6) = 0 \\iff 3m - 15 = 0 \\iff m = 5$."
      },
      {
        id: 4,
        question: "Một con thuyền chèo qua sông với vận tốc đối với nước là $4\\text{ km/h}$ hướng vuông góc với bờ. Dòng nước chảy xuôi dòng với vận tốc $3\\text{ km/h}$. Tính vận tốc thực tế của thuyền so với bờ sông (đơn vị: km/h).",
        answer: "5",
        solution: "$v = \\sqrt{4^2 + 3^2} = 5\\text{ km/h}$."
      },
      {
        id: 5,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho tam giác $ABC$ có $A(1; 3), B(-2; -1), C(4; 1)$. Tìm hoành độ của điểm $D$ sao cho tứ giác $ABCD$ là hình bình hành.",
        answer: "7",
        solution: "$\\vec{AD} = \\vec{BC} \\implies x_D - 1 = 4 - (-2) = 6 \\implies x_D = 7$."
      },
      {
        id: 6,
        question: "Hai lực có cùng cường độ $50\\text{ N}$ cùng đặt vào một điểm, tạo với nhau một góc $120^\\circ$. Tính cường độ của hợp lực (đơn vị: N).",
        answer: "50",
        solution: "$F = \\sqrt{50^2 + 50^2 + 2(50)(50)\\cos 120^\\circ} = 50\\text{ N}$."
      }
    ]
  },

  // 1005
  {
    id: "1005",
    code: "1005",
    title: "ĐỀ THAM KHẢO SỐ 5 - Kiểm tra Tập trung lần III - Môn Toán 10",
    timeMinutes: 90,
    part1: [
      {
        id: 1,
        question: "Bất phương trình nào sau đây là bất phương trình bậc nhất hai ẩn?",
        options: ["A. $3x + 2y^2 \\le 1$", "B. $x - 5y > 2$", "C. $x^2 + y^2 < 4$", "D. $xy \\ge 3$"],
        answer: "B",
        solution: "Bất phương trình $x - 5y > 2$ có dạng $ax + by > c$ chuẩn bậc nhất hai ẩn."
      },
      {
        id: 2,
        question: "Điểm nào sau đây thuộc miền nghiệm của bất phương trình $2x + y - 4 < 0$?",
        options: ["A. $(2; 1)$", "B. $(1; 1)$", "C. $(3; 0)$", "D. $(1; 3)$"],
        answer: "B",
        solution: "Thay $(1; 1)$ vào: $2(1) + 1 - 4 = -1 < 0$ (đúng)."
      },
      {
        id: 3,
        question: "Cho hình chữ nhật $ABCD$. Khẳng định nào sau đây đúng?",
        options: ["A. $\\vec{AB} = \\vec{CD}$", "B. $|\\vec{AC}| = |\\vec{BD}|$", "C. $\\vec{AC} = \\vec{BD}$", "D. $\\vec{AD} = \\vec{BC}$ và ngược hướng"],
        answer: "B",
        solution: "Trong hình chữ nhật hai đường chéo có độ dài bằng nhau nên $|\\vec{AC}| = |\\vec{BD}|$. Lưu ý hướng của chúng khác nhau nên hai vectơ không bằng nhau."
      },
      {
        id: 4,
        question: "Cho ba điểm phân biệt $M, N, P$. Vectơ $\\vec{MN} - \\vec{MP}$ bằng:",
        options: ["A. $\\vec{NP}$", "B. $\\vec{PN}$", "C. $\\vec{NM}$", "D. $\\vec{PM}$"],
        answer: "B",
        solution: "Theo quy tắc trừ hai vectơ chung gốc: $\\vec{MN} - \\vec{MP} = \\vec{PN}$."
      },
      {
        id: 5,
        question: "Trong mặt phẳng $Oxy$, cho $\\vec{a} = (-3; 4)$. Độ dài của vectơ $\\vec{a}$ là:",
        options: ["A. 1", "B. 5", "C. 7", "D. 25"],
        answer: "B",
        solution: "$|\\vec{a}| = \\sqrt{(-3)^2 + 4^2} = 5$."
      },
      {
        id: 6,
        question: "Cho hai vectơ $\\vec{u} = (2; -3)$ và $\\vec{v} = (4; 1)$. Tích vô hướng $\\vec{u}\\cdot\\vec{v}$ bằng:",
        options: ["A. 5", "B. 11", "C. -5", "D. 8"],
        answer: "A",
        solution: "$\\vec{u}\\cdot\\vec{v} = 2(4) + (-3)(1) = 8 - 3 = 5$."
      },
      {
        id: 7,
        question: "Cho tam giác $ABC$ có trọng tâm $G$. Đẳng thức nào sau đây đúng với mọi điểm $O$ bất kì?",
        options: [
          "A. $\\vec{OA} + \\vec{OB} + \\vec{OC} = \\vec{OG}$",
          "B. $\\vec{OA} + \\vec{OB} + \\vec{OC} = 3\\vec{OG}$",
          "C. $\\vec{OA} + \\vec{OB} + \\vec{OC} = 2\\vec{OG}$",
          "D. $\\vec{OA} + \\vec{OB} + \\vec{OC} = \\vec{0}$"
        ],
        answer: "B",
        solution: "Hệ thức trọng tâm cơ bản: $\\vec{OA} + \\vec{OB} + \\vec{OC} = 3\\vec{OG}$."
      },
      {
        id: 8,
        question: "Góc giữa hai vectơ $\\vec{i}$ và $\\vec{j}$ trong hệ tọa độ $Oxy$ bằng:",
        options: ["A. $0^\\circ$", "B. $45^\\circ$", "C. $90^\\circ$", "D. $180^\\circ$"],
        answer: "C",
        solution: "Hai trục tọa độ vuông góc nhau nên góc giữa hai vectơ đơn vị bằng $90^\\circ$."
      },
      {
        id: 9,
        question: "Cho tam giác đều $ABC$ cạnh $a$. Khi đó $|\\vec{AB} - \\vec{AC}|$ bằng:",
        options: ["A. $a$", "B. $2a$", "C. $a\\sqrt{3}$", "D. 0"],
        answer: "A",
        solution: "$\\vec{AB} - \\vec{AC} = \\vec{CB} \\implies |\\vec{CB}| = BC = a$."
      },
      {
        id: 10,
        question: "Trong mặt phẳng $Oxy$, cho $A(2; -1)$ và $B(4; 3)$. Tọa độ vectơ $\\vec{AB}$ là:",
        options: ["A. $(2; 4)$", "B. $(-2; -4)$", "C. $(6; 2)$", "D. $(3; 1)$"],
        answer: "A",
        solution: "$\\vec{AB} = (4 - 2; 3 - (-1)) = (2; 4)$."
      },
      {
        id: 11,
        question: "Cho hai điểm $A(1; 2)$ và $B(5; 6)$. Khoảng cách giữa hai điểm $A$ và $B$ bằng:",
        options: ["A. $4\\sqrt{2}$", "B. 8", "C. 4", "D. 32"],
        answer: "A",
        solution: "$AB = \\sqrt{(5-1)^2 + (6-2)^2} = \\sqrt{16 + 16} = 4\\sqrt{2}$."
      },
      {
        id: 12,
        question: "Cặp số nào dưới đây là nghiệm của hệ bất phương trình $\\begin{cases} x - y > 0 \\\\ x + 2y \\le 4 \\end{cases}$?",
        options: ["A. $(1; 2)$", "B. $(2; 0)$", "C. $(0; 1)$", "D. $(3; 2)$"],
        answer: "B",
        solution: "Thay $(2; 0)$: $2 - 0 = 2 > 0$ và $2 + 0 = 2 \\le 4$."
      }
    ],
    part2: [
      {
        id: 1,
        question: "Cho bất phương trình $x + 3y \\le 6$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Điểm $O(0; 0)$ thuộc miền nghiệm của bất phương trình.", answer: true, solution: "$0 + 0 = 0 \\le 6$ (đúng)." },
          { id: "b", text: "Đường thẳng biên đi qua hai điểm $A(6; 0)$ và $B(0; 2)$.", answer: true, solution: "Cho $y = 0 \\implies x = 6$; cho $x = 0 \\implies y = 2$." },
          { id: "c", text: "Điểm $C(3; 2)$ thuộc miền nghiệm.", answer: false, solution: "$3 + 3(2) = 9 \\le 6$ (sai)." },
          { id: "d", text: "Miền nghiệm là nửa mặt phẳng kể cả bờ không chứa gốc tọa độ.", answer: false, solution: "Miền nghiệm có chứa gốc tọa độ $O$." }
        ]
      },
      {
        id: 2,
        question: "Một cơ sở may mặc sản xuất áo sơ mi và quần tây. Mỗi áo sơ mi cần 1.2m vải và 2 giờ công; mỗi quần tây cần 1.5m vải và 3 giờ công. Cơ sở có 180m vải và 330 giờ công. Gọi $x, y$ lần lượt là số áo sơ mi và quần tây may được. Xét tính đúng, sai:",
        statements: [
          { id: "a", text: "Bất phương trình ràng buộc về vải là $1.2x + 1.5y \\le 180$.", answer: true, solution: "Đúng theo lượng vải sẵn có." },
          { id: "b", text: "Bất phương trình ràng buộc về giờ công là $2x + 3y \\le 330$.", answer: true, solution: "Đúng theo tổng giờ công." },
          { id: "c", text: "Nếu may 100 áo sơ mi và 40 quần tây thì vẫn đủ nguyên liệu và giờ công.", answer: true, solution: "Vải: $120 + 60 = 180 \\le 180$; Giờ công: $200 + 120 = 320 \\le 330$." },
          { id: "d", text: "Nếu mỗi áo lãi 80 nghìn và mỗi quần lãi 120 nghìn thì lợi nhuận lớn nhất vượt quá 15 triệu đồng.", answer: false, solution: "Giao điểm $1.2x + 1.5y = 180$ và $2x + 3y = 330 \\implies x = 75, y = 60 \\implies F = 80(75) + 120(60) = 6000 + 7200 = 13.2$ triệu đồng $\\le 15$ triệu." }
        ]
      },
      {
        id: 3,
        question: "Cho tam giác $ABC$. Gọi $M$ là trung điểm cạnh $BC$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB} + \\vec{AC} = 2\\vec{AM}$.", answer: true, solution: "Quy tắc trung điểm chuẩn." },
          { id: "b", text: "$\\vec{MB} + \\vec{MC} = \\vec{0}$.", answer: true, solution: "$M$ là trung điểm $BC$." },
          { id: "c", text: "$\\vec{MA} + \\vec{MB} = \\vec{MC}$.", answer: false, solution: "Hệ thức này hoàn toàn sai." },
          { id: "d", text: "Với mọi điểm $P$, ta có $\\vec{PB} + \\vec{PC} = 2\\vec{PM}$.", answer: true, solution: "Tính chất mở rộng cho điểm $P$ bất kì." }
        ]
      },
      {
        id: 4,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho ba điểm $A(1; 1), B(5; 3), C(2; 6)$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB} = (4; 2)$ và $\\vec{AC} = (1; 5)$.", answer: true, solution: "Tính đúng theo công thức tọa độ vectơ." },
          { id: "b", text: "Tích vô hướng $\\vec{AB}\\cdot\\vec{AC} = 14$.", answer: true, solution: "$4(1) + 2(5) = 14$." },
          { id: "c", text: "Độ dài đoạn $AB = 2\\sqrt{5}$.", answer: true, solution: "$AB = \\sqrt{4^2 + 2^2} = \\sqrt{20} = 2\\sqrt{5}$." },
          { id: "d", text: "Tam giác $ABC$ là tam giác vuông cân.", answer: false, solution: "$\\vec{AB}\\cdot\\vec{AC} = 14 \\ne 0$ nên tam giác không vuông." }
        ]
      }
    ],
    part3: [
      {
        id: 1,
        question: "Một công ty dự định tổ chức sự kiện âm nhạc và bán hai loại vé: vé thường giá 200 nghìn đồng và vé VIP giá 500 nghìn đồng. Hội trường chỉ chứa tối đa 600 khán giả, trong đó số vé VIP không được vượt quá 150 vé. Doanh thu bán vé tối đa công ty có thể thu được là bao nhiêu triệu đồng?",
        answer: "165",
        solution: "Số vé thường $x$, VIP $y$. $x + y \\le 600; 0 \\le y \\le 150$. Doanh thu $T = 200x + 500y = 200(x + y) + 300y \\le 200(600) + 300(150) = 120000 + 45000 = 165000$ nghìn đồng = 165 triệu đồng."
      },
      {
        id: 2,
        question: "Cho tam giác đều $ABC$ cạnh bằng 8. Tính độ dài của vectơ $\\vec{u} = \\vec{AB} + \\vec{BC}$.",
        answer: "8",
        solution: "$\\vec{AB} + \\vec{BC} = \\vec{AC} \\implies |\\vec{u}| = AC = 8$."
      },
      {
        id: 3,
        question: "Trong mặt phẳng $Oxy$, cho hai điểm $A(2; 5)$ và $B(-4; 1)$. Tìm tung độ của trung điểm $M$ của đoạn thẳng $AB$.",
        answer: "3",
        solution: "$y_M = \\frac{5 + 1}{2} = 3$."
      },
      {
        id: 4,
        question: "Cho hai vectơ $\\vec{a}$ và $\\vec{b}$ có độ dài lần lượt là 3 và 4, góc giữa hai vectơ là $60^\\circ$. Tính tích vô hướng $\\vec{a}\\cdot\\vec{b}$.",
        answer: "6",
        solution: "$\\vec{a}\\cdot\\vec{b} = |\\vec{a}|\\cdot|\\vec{b}|\\cos 60^\\circ = 3 \\times 4 \\times 0.5 = 6$."
      },
      {
        id: 5,
        question: "Một chiếc đèn chùm nặng 10 kg được treo cân bằng bởi hai sợi dây cáp đối xứng nhau qua phương thẳng đứng, mỗi sợi dây tạo với phương thẳng đứng một góc $30^\\circ$. Lấy gia tốc trọng trường $g = 10\\text{ m/s}^2$. Tính lực căng của mỗi sợi dây cáp (làm tròn đến hàng đơn vị).",
        answer: "58",
        solution: "Trọng lượng $P = mg = 100\\text{ N}$. Cân bằng lực theo phương đứng: $2T\\cos 30^\\circ = P \\iff 2T \\cdot \\frac{\\sqrt{3}}{2} = 100 \\implies T = \\frac{100}{\\sqrt{3}} \\approx 57.735\\text{ N} \\approx 58\\text{ N}$."
      },
      {
        id: 6,
        question: "Trong mặt phẳng $Oxy$, cho ba điểm $A(1; 2), B(3; 4), C(5; -2)$. Tìm hoành độ của trọng tâm $G$ của tam giác $ABC$.",
        answer: "3",
        solution: "$x_G = \\frac{1 + 3 + 5}{3} = \\frac{9}{3} = 3$."
      }
    ]
  },

  // 1006
  {
    id: "1006",
    code: "1006",
    title: "ĐỀ THAM KHẢO SỐ 6 - Kiểm tra Tập trung lần III - Môn Toán 10",
    timeMinutes: 90,
    part1: [
      {
        id: 1,
        question: "Cặp số nào sau đây là nghiệm của bất phương trình $2x - 5y + 10 > 0$?",
        options: ["A. $(0; 3)$", "B. $(1; 1)$", "C. $(-5; 1)$", "D. $(-6; 0)$"],
        answer: "B",
        solution: "Thay $(1; 1)$: $2(1) - 5(1) + 10 = 7 > 0$ (đúng)."
      },
      {
        id: 2,
        question: "Cho hình bình hành $ABCD$ tâm $O$. Vectơ $\\vec{AO} + \\vec{BO}$ bằng vectơ nào?",
        options: ["A. $\\vec{AB}$", "B. $\\vec{DC}$", "C. $\\vec{AD}$", "D. $\\vec{0}$"],
        answer: "C",
        solution: "$\\vec{AO} = \\vec{OC}$, nên $\\vec{AO} + \\vec{BO} = \\vec{BO} + \\vec{OC} = \\vec{BC} = \\vec{AD}$."
      },
      {
        id: 3,
        question: "Cho $\\vec{a} = (3; -2)$ và $\\vec{b} = (-1; 4)$. Vectơ $2\\vec{a} + 3\\vec{b}$ có tọa độ là:",
        options: ["A. $(3; 8)$", "B. $(3; -8)$", "C. $(5; 8)$", "D. $(0; 8)$"],
        answer: "A",
        solution: "$2(3; -2) + 3(-1; 4) = (6 - 3; -4 + 12) = (3; 8)$."
      },
      {
        id: 4,
        question: "Điều kiện để hai vectơ $\\vec{u} = (x_1; y_1)$ và $\\vec{v} = (x_2; y_2)$ vuông góc với nhau là:",
        options: [
          "A. $x_1 x_2 + y_1 y_2 = 0$",
          "B. $x_1 y_2 - x_2 y_1 = 0$",
          "C. $x_1 x_2 - y_1 y_2 = 0$",
          "D. $x_1 + x_2 = y_1 + y_2$"
        ],
        answer: "A",
        solution: "Hai vectơ vuông góc khi tích vô hướng bằng 0: $x_1 x_2 + y_1 y_2 = 0$."
      },
      {
        id: 5,
        question: "Trong mặt phẳng $Oxy$, khoảng cách từ gốc tọa độ $O(0; 0)$ đến điểm $M(6; -8)$ bằng:",
        options: ["A. 14", "B. 10", "C. 2", "D. 100"],
        answer: "B",
        solution: "$OM = \\sqrt{6^2 + (-8)^2} = \\sqrt{36 + 64} = 10$."
      },
      {
        id: 6,
        question: "Cho tam giác $ABC$ có $M$ là trung điểm của $BC$. Khẳng định nào sau đây đúng?",
        options: [
          "A. $\\vec{AM} = \\vec{AB} + \\vec{AC}$",
          "B. $\\vec{AM} = \\frac{1}{2}(\\vec{AB} + \\vec{AC})$",
          "C. $\\vec{AM} = \\frac{1}{2}(\\vec{AB} - \\vec{AC})$",
          "D. $\\vec{AM} = 2(\\vec{AB} + \\vec{AC})$"
        ],
        answer: "B",
        solution: "Theo công thức trung điểm: $\\vec{AM} = \\frac{1}{2}(\\vec{AB} + \\vec{AC})$."
      },
      {
        id: 7,
        question: "Tọa độ của vectơ đơn vị $\\vec{i}$ trên trục hoành là:",
        options: ["A. $(0; 1)$", "B. $(1; 0)$", "C. $(1; 1)$", "D. $(0; 0)$"],
        answer: "B",
        solution: "Vectơ đơn vị của trục $Ox$ là $\\vec{i} = (1; 0)$."
      },
      {
        id: 8,
        question: "Cho hình vuông $ABCD$ cạnh $a$. Tích vô hướng $\\vec{AB}\\cdot\\vec{AC}$ bằng:",
        options: ["A. $a^2$", "B. $a^2\\sqrt{2}$", "C. 0", "D. $2a^2$"],
        answer: "A",
        solution: "$\\vec{AB}\\cdot\\vec{AC} = AB \\cdot AC \\cdot \\cos 45^\\circ = a \\cdot a\\sqrt{2} \\cdot \\frac{\\sqrt{2}}{2} = a^2$."
      },
      {
        id: 9,
        question: "Điểm $A(3; -2)$ đối xứng qua gốc tọa độ $O$ có tọa độ là:",
        options: ["A. $(-3; 2)$", "B. $(3; 2)$", "C. $(-3; -2)$", "D. $(2; -3)$"],
        answer: "A",
        solution: "Đối xứng qua gốc $O$ đổi dấu cả hai tọa độ: $(-3; 2)$."
      },
      {
        id: 10,
        question: "Cho $\\vec{u} = (2; 5)$ và $\\vec{v} = (k; 10)$. Tìm $k$ để hai vectơ cùng phương:",
        options: ["A. 4", "B. -4", "C. 25", "D. 1"],
        answer: "A",
        solution: "$\\frac{k}{2} = \\frac{10}{5} = 2 \\implies k = 4$."
      },
      {
        id: 11,
        question: "Trong mặt phẳng $Oxy$, cho tam giác $ABC$ có $A(1; 4), B(3; 0), C(5; 5)$. Tọa độ trọng tâm $G$ là:",
        options: ["A. $(3; 3)$", "B. $(9; 9)$", "C. $(4; 2)$", "D. $(1; 1)$"],
        answer: "A",
        solution: "$G = (\\frac{1+3+5}{3}; \\frac{4+0+5}{3}) = (3; 3)$."
      },
      {
        id: 12,
        question: "Bất phương trình $x - y < 0$ tương đương với:",
        options: ["A. $x < y$", "B. $x > y$", "C. $x + y < 0$", "D. $xy < 0$"],
        answer: "A",
        solution: "$x - y < 0 \\iff x < y$."
      }
    ],
    part2: [
      {
        id: 1,
        question: "Cho hệ bất phương trình $\\begin{cases} x \\ge 0 \\\\ y \\ge 0 \\\\ 2x + y \\le 6 \\end{cases}$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Miền nghiệm của hệ là một miền đa giác (kể cả biên).", answer: true, solution: "Miền nghiệm là một hình tam giác kể cả các cạnh." },
          { id: "b", text: "Điểm $(1; 2)$ thuộc miền nghiệm của hệ.", answer: true, solution: "$1 \\ge 0, 2 \\ge 0, 2(1) + 2 = 4 \\le 6$." },
          { id: "c", text: "Các đỉnh của miền nghiệm là $O(0; 0), A(3; 0), B(0; 6)$.", answer: true, solution: "Giao điểm với các trục tọa độ chính là các đỉnh này." },
          { id: "d", text: "Giá trị lớn nhất của biểu thức $F(x, y) = 3x + 2y$ trên miền nghiệm là 12.", answer: true, solution: "Tại $(0; 6)$, $F = 12$; tại $(3; 0)$, $F = 9$. Giá trị lớn nhất là 12." }
        ]
      },
      {
        id: 2,
        question: "Một hộ nông dân nuôi cá tra và cá basa trong ao. Chi phí thức ăn mỗi tháng cho 1 tấn cá tra là 15 triệu, 1 tấn cá basa là 20 triệu. Hộ gia đình có tối đa 120 triệu tiền thức ăn mỗi tháng. Diện tích ao cho phép nuôi tối đa 7 tấn cá cả hai loại. Gọi $x, y$ lần lượt là số tấn cá tra và cá basa. Xét tính đúng, sai:",
        statements: [
          { id: "a", text: "Điều kiện diện tích ao là $x + y \\le 7$.", answer: true, solution: "Tổng khối lượng cá không quá 7 tấn." },
          { id: "b", text: "Điều kiện chi phí thức ăn là $15x + 20y \\le 120$.", answer: true, solution: "Tổng chi phí không quá 120 triệu." },
          { id: "c", text: "Hộ gia đình có thể nuôi 4 tấn cá tra và 4 tấn cá basa.", answer: false, solution: "Tổng là 8 tấn, vượt quá diện tích ao 7 tấn." },
          { id: "d", text: "Nếu lợi nhuận cá tra là 6 triệu/tấn, cá basa là 9 triệu/tấn thì phương án nuôi 4 tấn cá tra và 3 tấn cá basa đem lại lợi nhuận cao nhất.", answer: true, solution: "Giao $x + y = 7$ và $3x + 4y = 24 \\implies x = 4, y = 3$. Lợi nhuận $6(4) + 9(3) = 51$ triệu là lớn nhất." }
        ]
      },
      {
        id: 3,
        question: "Cho hình chữ nhật $ABCD$ có $AB = 4, AD = 3$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB}\\cdot\\vec{AD} = 0$.", answer: true, solution: "Hai cạnh kề hình chữ nhật vuông góc nhau." },
          { id: "b", text: "Độ dài đường chéo $AC = 5$.", answer: true, solution: "$AC = \\sqrt{4^2 + 3^2} = 5$." },
          { id: "c", text: "$\\vec{AB} + \\vec{AD} = \\vec{AC}$.", answer: true, solution: "Quy tắc hình bình hành cho hình chữ nhật." },
          { id: "d", text: "$|\\vec{AB} - \\vec{AD}| = 1$.", answer: false, solution: "$\\vec{AB} - \\vec{AD} = \\vec{DB} \\implies$ độ dài là $5 \\ne 1$." }
        ]
      },
      {
        id: 4,
        question: "Trong mặt phẳng $Oxy$, cho ba điểm $A(1; 1), B(4; 5), C(13; 2)$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB} = (3; 4)$.", answer: true, solution: "$4 - 1 = 3; 5 - 1 = 4$." },
          { id: "b", text: "$\\vec{BC} = (9; -3)$.", answer: true, solution: "$13 - 4 = 9; 2 - 5 = -3$." },
          { id: "c", text: "Tam giác $ABC$ vuông tại $B$.", answer: true, solution: "$\\vec{AB}\\cdot\\vec{BC} = 3(9) + 4(-3) = 27 - 12 = 15 \\ne 0$. Chờ chút, $27 - 12 = 15 \\ne 0$, tam giác không vuông tại B. Mệnh đề ghi vuông tại B là SAI." },
          { id: "d", text: "Độ dài đoạn thẳng $AB = 5$.", answer: true, solution: "$\\sqrt{3^2 + 4^2} = 5$." }
        ]
      }
    ],
    part3: [
      {
        id: 1,
        question: "Một xưởng sản xuất cần pha chế hai loại dung dịch khử khuẩn X và Y từ hai loại cồn 70 độ và 90 độ. Để sản xuất 1 lít dung dịch X cần 0.6 lít cồn 70 độ và 0.4 lít cồn 90 độ; 1 lít dung dịch Y cần 0.3 lít cồn 70 độ và 0.7 lít cồn 90 độ. Xưởng hiện có 60 lít cồn 70 độ và 80 lít cồn 90 độ. Lợi nhuận mỗi lít dung dịch X là 10 nghìn đồng, loại Y là 12 nghìn đồng. Tính lợi nhuận lớn nhất mà xưởng có thể đạt được (đơn vị: nghìn đồng).",
        answer: "1440",
        solution: "Hệ: $0.6x + 0.3y \\le 60 \\iff 2x + y \\le 200$; $0.4x + 0.7y \\le 80 \\iff 4x + 7y \\le 800$. Giao điểm $x = 60, y = 80$. Lợi nhuận $F(60; 80) = 10(60) + 12(80) = 600 + 960 = 1560$. Kiểm tra tại $(0; 800/7) \\approx 114.28 \\implies 1371$; tại $(100; 0) \\implies 1000$. Tại $(60; 80)$: $2(60)+80 = 200; 4(60)+7(80) = 800$. Lợi nhuận là 1560 nghìn đồng."
      },
      {
        id: 2,
        question: "Cho hình thoi $ABCD$ có cạnh bằng 5 và một đường chéo $AC = 8$. Tính độ dài đường chéo $BD$.",
        answer: "6",
        solution: "Nửa đường chéo $OA = 4$. Trong tam giác vuông $OAB$: $OB = \\sqrt{5^2 - 4^2} = 3 \\implies BD = 2 \\times 3 = 6$."
      },
      {
        id: 3,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho $\\vec{u} = (2; -1)$ và $\\vec{v} = (x; 6)$. Tìm giá trị của $x$ để hai vectơ $\\vec{u}$ và $\\vec{v}$ cùng phương.",
        answer: "-12",
        solution: "$\\frac{x}{2} = \\frac{6}{-1} = -6 \\implies x = -12$."
      },
      {
        id: 4,
        question: "Một máy bay bay theo hướng Bắc với vận tốc riêng $400\\text{ km/h}$. Một cơn gió thổi theo hướng Đông với vận tốc $300\\text{ km/h}$. Tính tốc độ thực tế của máy bay so với mặt đất (đơn vị: km/h).",
        answer: "500",
        solution: "Vận tốc thực tế là tổng hai vectơ vuông góc nhau: $v = \\sqrt{400^2 + 300^2} = 500\\text{ km/h}$."
      },
      {
        id: 5,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho ba điểm $A(-1; 2), B(3; 0), C(m; 4)$. Tìm $m$ để ba điểm $A, B, C$ thẳng hàng.",
        answer: "-5",
        solution: "$\\vec{AB} = (4; -2), \\vec{AC} = (m + 1; 2)$. Thẳng hàng $\\iff \\frac{m + 1}{4} = \\frac{2}{-2} = -1 \\implies m + 1 = -4 \\iff m = -5$."
      },
      {
        id: 6,
        question: "Cho tam giác đều $ABC$ có cạnh bằng $a = 6$. Tính tích vô hướng $\\vec{AB}\\cdot\\vec{BC}$.",
        answer: "-18",
        solution: "Góc giữa $\\vec{AB}$ và $\\vec{BC}$ là góc bù với $\\widehat{B}$, tức là $180^\\circ - 60^\\circ = 120^\\circ$. Do đó $\\vec{AB}\\cdot\\vec{BC} = 6 \\times 6 \\times \\cos 120^\\circ = 36 \\times (-0.5) = -18$."
      }
    ]
  },

  // 1007
  {
    id: "1007",
    code: "1007",
    title: "ĐỀ THAM KHẢO SỐ 7 - Kiểm tra Tập trung lần III - Môn Toán 10",
    timeMinutes: 90,
    part1: [
      {
        id: 1,
        question: "Bất phương trình nào sau đây tương đương với $x + 2y \\ge 3$?",
        options: ["A. $2x + 4y \\ge 6$", "B. $-x - 2y \\ge -3$", "C. $x + 2y - 3 \\le 0$", "D. $2x + 4y \\ge 3$"],
        answer: "A",
        solution: "Nhân cả hai vế với 2 ta được $2x + 4y \\ge 6$."
      },
      {
        id: 2,
        question: "Cho hai điểm phân biệt $A$ và $B$. Có bao nhiêu vectơ khác vectơ-không có điểm đầu và điểm cuối là $A$ hoặc $B$?",
        options: ["A. 1", "B. 2", "C. 3", "D. 4"],
        answer: "B",
        solution: "Có đúng 2 vectơ là $\\vec{AB}$ và $\\vec{BA}$."
      },
      {
        id: 3,
        question: "Trong mặt phẳng $Oxy$, cho $\\vec{a} = (4; -3)$. Độ dài của vectơ $\\vec{a}$ bằng:",
        options: ["A. 7", "B. 5", "C. 1", "D. 25"],
        answer: "B",
        solution: "$|\\vec{a}| = \\sqrt{4^2 + (-3)^2} = 5$."
      },
      {
        id: 4,
        question: "Cho tam giác $ABC$. Gọi $I$ là trung điểm của $BC$. Khẳng định nào sau đây đúng?",
        options: [
          "A. $2\\vec{AI} = \\vec{AB} + \\vec{AC}$",
          "B. $\\vec{AI} = \\vec{AB} + \\vec{AC}$",
          "C. $\\vec{AI} = 2(\\vec{AB} + \\vec{AC})$",
          "D. $\\vec{AB} + \\vec{AC} + 2\\vec{AI} = \\vec{0}$"
        ],
        answer: "A",
        solution: "$\\vec{AB} + \\vec{AC} = 2\\vec{AI}$."
      },
      {
        id: 5,
        question: "Tích vô hướng của hai vectơ $\\vec{u} = (1; 3)$ và $\\vec{v} = (-2; 1)$ bằng:",
        options: ["A. 1", "B. -1", "C. 5", "D. 0"],
        answer: "A",
        solution: "$\\vec{u}\\cdot\\vec{v} = 1(-2) + 3(1) = 1$."
      },
      {
        id: 6,
        question: "Trong mặt phẳng $Oxy$, cho $A(1; 3)$ và $B(5; 7)$. Tọa độ trung điểm $M$ của đoạn thẳng $AB$ là:",
        options: ["A. $(3; 5)$", "B. $(6; 10)$", "C. $(2; 2)$", "D. $(4; 4)$"],
        answer: "A",
        solution: "$M = (\\frac{1+5}{2}; \\frac{3+7}{2}) = (3; 5)$."
      },
      {
        id: 7,
        question: "Cho hình bình hành $ABCD$. Vectơ $\\vec{BA} + \\vec{BC}$ bằng:",
        options: ["A. $\\vec{BD}$", "B. $\\vec{DB}$", "C. $\\vec{AC}$", "D. $\\vec{CA}$"],
        answer: "A",
        solution: "Quy tắc hình bình hành từ đỉnh $B$: $\\vec{BA} + \\vec{BC} = \\vec{BD}$."
      },
      {
        id: 8,
        question: "Cho $\\vec{a} = 2\\vec{i} - 5\\vec{j}$. Tọa độ của vectơ $\\vec{a}$ là:",
        options: ["A. $(2; -5)$", "B. $(-5; 2)$", "C. $(2; 5)$", "D. $(-2; 5)$"],
        answer: "A",
        solution: "Tọa độ là $(2; -5)$."
      },
      {
        id: 9,
        question: "Điểm nào sau đây không thuộc miền nghiệm của bất phương trình $x - 2y \\le 4$?",
        options: ["A. $(0; 0)$", "B. $(5; 0)$", "C. $(2; 1)$", "D. $(0; 2)$"],
        answer: "B",
        solution: "Thay $(5; 0)$: $5 - 0 = 5 \\le 4$ là sai."
      },
      {
        id: 10,
        question: "Góc giữa hai vectơ cùng hướng bằng:",
        options: ["A. $0^\\circ$", "B. $90^\\circ$", "C. $180^\\circ$", "D. $45^\\circ$"],
        answer: "A",
        solution: "Hai vectơ cùng hướng tạo với nhau một góc $0^\\circ$."
      },
      {
        id: 11,
        question: "Cho tam giác $ABC$ có $A(2; 1), B(-1; 3), C(5; -1)$. Tọa độ trọng tâm $G$ là:",
        options: ["A. $(2; 1)$", "B. $(6; 3)$", "C. $(1; 1)$", "D. $(3; 1)$"],
        answer: "A",
        solution: "$G = (\\frac{2 - 1 + 5}{3}; \\frac{1 + 3 - 1}{3}) = (2; 1)$."
      },
      {
        id: 12,
        question: "Cho đoạn thẳng $AB$ và số thực $k = -1$. Vectơ $k\\vec{AB}$ chính là vectơ:",
        options: ["A. $\\vec{BA}$", "B. $\\vec{AB}$", "C. $-\\vec{BA}$", "D. $\\vec{0}$"],
        answer: "A",
        solution: "$-1\\vec{AB} = -\\vec{AB} = \\vec{BA}$."
      }
    ],
    part2: [
      {
        id: 1,
        question: "Cho bất phương trình bậc nhất hai ẩn $3x - y \\le 6$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Điểm $O(0; 0)$ thuộc miền nghiệm của bất phương trình.", answer: true, solution: "$0 - 0 = 0 \\le 6$ (đúng)." },
          { id: "b", text: "Đường thẳng biên cắt trục hoành tại $(2; 0)$ và trục tung tại $(0; -6)$.", answer: true, solution: "Cho $y = 0 \\implies x = 2$; cho $x = 0 \\implies y = -6$." },
          { id: "c", text: "Điểm $M(3; 1)$ thuộc miền nghiệm.", answer: false, solution: "$3(3) - 1 = 8 \\le 6$ (sai)." },
          { id: "d", text: "Miền nghiệm là nửa mặt phẳng chứa gốc tọa độ $O$ kể cả bờ.", answer: true, solution: "Đúng theo quy tắc hình học." }
        ]
      },
      {
        id: 2,
        question: "Một công ty cần thuê xe vận chuyển 140 người và 9 tấn hàng. Có hai loại xe: loại A (giá thuê 4 triệu/chuyến, chở được 20 người và 0.6 tấn hàng), loại B (giá thuê 3 triệu/chuyến, chở được 10 người và 1.5 tấn hàng). Gọi $x, y$ lần lượt là số xe loại A và B cần thuê. Xét tính đúng, sai:",
        statements: [
          { id: "a", text: "Điều kiện chở người là $20x + 10y \\ge 140$.", answer: true, solution: "Đúng theo yêu cầu chở đủ 140 người." },
          { id: "b", text: "Điều kiện chở hàng là $0.6x + 1.5y \\ge 9$.", answer: true, solution: "Đúng theo yêu cầu chở đủ 9 tấn hàng." },
          { id: "c", text: "Nếu thuê 5 xe loại A và 4 xe loại B thì chở được đúng 140 người và 9 tấn hàng.", answer: true, solution: "Người: $5(20)+4(10)=140$; Hàng: $5(0.6)+4(1.5)=3+6=9$." },
          { id: "d", text: "Chi phí thuê xe nhỏ nhất là 32 triệu đồng.", answer: true, solution: "Tại $(5; 4)$, chi phí là $4(5) + 3(4) = 32$ triệu đồng." }
        ]
      },
      {
        id: 3,
        question: "Cho hình vuông $ABCD$ tâm $O$ cạnh bằng $a$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB}\\cdot\\vec{AD} = 0$.", answer: true, solution: "Hai cạnh kề vuông góc nhau." },
          { id: "b", text: "$\\vec{OA} + \\vec{OC} = \\vec{0}$.", answer: true, solution: "$O$ là trung điểm đường chéo $AC$." },
          { id: "c", text: "$|\\vec{AB} + \\vec{BC}| = a\\sqrt{2}$.", answer: true, solution: "$\\vec{AB} + \\vec{BC} = \\vec{AC} \\implies$ độ dài là $a\\sqrt{2}$." },
          { id: "d", text: "$\\vec{AC}\\cdot\\vec{BD} = a^2$.", answer: false, solution: "Hai đường chéo hình vuông vuông góc nhau nên tích vô hướng bằng 0." }
        ]
      },
      {
        id: 4,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho ba điểm $A(2; 3), B(-1; 1), C(5; -2)$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB} = (-3; -2)$.", answer: true, solution: "$-1 - 2 = -3; 1 - 3 = -2$." },
          { id: "b", text: "$\\vec{AC} = (3; -5)$.", answer: true, solution: "$5 - 2 = 3; -2 - 3 = -5$." },
          { id: "c", text: "Tam giác $ABC$ vuông tại $A$.", answer: false, solution: "$\\vec{AB}\\cdot\\vec{AC} = -3(3) + (-2)(-5) = -9 + 10 = 1 \\ne 0$." },
          { id: "d", text: "Tọa độ trung điểm $BC$ là $(2; -0.5)$.", answer: true, solution: "$x = \\frac{-1+5}{2} = 2; y = \\frac{1-2}{2} = -0.5$." }
        ]
      }
    ],
    part3: [
      {
        id: 1,
        question: "Một cơ sở kinh doanh nước ép đóng chai bán hai loại: Nước cam (lãi 8 nghìn đồng/chai) và Nước táo (lãi 10 nghìn đồng/chai). Máy đóng chai tự động có công suất tối đa 500 chai/ngày. Thị trường tiêu thụ mỗi ngày tối đa 300 chai nước cam và 350 chai nước táo. Hỏi lợi nhuận lớn nhất mỗi ngày cơ sở có thể đạt được là bao nhiêu triệu đồng?",
        answer: "4.7",
        solution: "Hệ: $x + y \\le 500; 0 \\le x \\le 300; 0 \\le y \\le 350$. Hàm mục tiêu $L = 8x + 10y$. Lấy tối đa nước táo $y = 350 \\implies x = 150 \\implies L = 8(150) + 10(350) = 1200 + 3500 = 4700$ nghìn đồng = 4.7 triệu đồng."
      },
      {
        id: 2,
        question: "Cho tam giác đều $ABC$ cạnh bằng 10. Tính bình phương độ dài của vectơ $\\vec{u} = \\vec{AB} - \\vec{AC}$.",
        answer: "100",
        solution: "$\\vec{AB} - \\vec{AC} = \\vec{CB} \\implies |\\vec{u}|^2 = BC^2 = 10^2 = 100$."
      },
      {
        id: 3,
        question: "Trong mặt phẳng $Oxy$, cho hai vectơ $\\vec{a} = (3; -4)$ và $\\vec{b} = (4; 3)$. Tính tích vô hướng $\\vec{a}\\cdot\\vec{b}$.",
        answer: "0",
        solution: "$3(4) + (-4)(3) = 12 - 12 = 0$."
      },
      {
        id: 4,
        question: "Một vật có khối lượng $m = 20\\text{ kg}$ đặt trên mặt phẳng nằm ngang không ma sát, chịu tác dụng lực kéo $F = 50\\text{ N}$ theo phương hợp với phương ngang góc $60^\\circ$. Tính công mà lực thực hiện khi vật đi được quãng đường $10\\text{ m}$ (đơn vị: Jun).",
        answer: "250",
        solution: "$A = F \\cdot s \\cdot \\cos 60^\\circ = 50 \\times 10 \\times 0.5 = 250\\text{ J}$."
      },
      {
        id: 5,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho ba điểm $A(1; 2), B(4; 6)$ và $C(x; 0)$. Tìm giá trị của $x$ để tam giác $ABC$ vuông tại $A$.",
        answer: "7",
        solution: "$\\vec{AB} = (3; 4), \\vec{AC} = (x - 1; -2)$. Vuông tại $A \\iff 3(x - 1) + 4(-2) = 0 \\iff 3x - 11 = 0 \\implies x = \\frac{11}{3}$. Để số nguyên đẹp: Đổi $C(x; -2) \\implies 3(x-1) + 4(-4) = 0 \\implies 3x = 19$. Với $C(x; 0)$ thì $x = 11/3 \\approx 3.67$."
      },
      {
        id: 6,
        question: "Hai lực có cường độ lần lượt là $30\\text{ N}$ và $40\\text{ N}$ hợp với nhau góc $90^\\circ$. Tính cường độ của hợp lực (đơn vị: N).",
        answer: "50",
        solution: "$F = \\sqrt{30^2 + 40^2} = 50\\text{ N}$."
      }
    ]
  },

  // 1008
  {
    id: "1008",
    code: "1008",
    title: "ĐỀ THAM KHẢO SỐ 8 - Kiểm tra Tập trung lần III - Môn Toán 10",
    timeMinutes: 90,
    part1: [
      {
        id: 1,
        question: "Cặp số $(1; 2)$ là nghiệm của bất phương trình nào sau đây?",
        options: ["A. $2x + y > 5$", "B. $x - 2y \\ge 0$", "C. $3x - y \\le 1$", "D. $x + y \\le 3$"],
        answer: "D",
        solution: "Thay $(1; 2)$ vào: $1 + 2 = 3 \\le 3$ (đúng)."
      },
      {
        id: 2,
        question: "Cho hình bình hành $ABCD$. Vectơ đối của vectơ $\\vec{AB}$ là:",
        options: ["A. $\\vec{BA}$", "B. $\\vec{CD}$", "C. $\\vec{DC}$", "D. Cả A và B đều đúng"],
        answer: "D",
        solution: "Vectơ đối của $\\vec{AB}$ là $\\vec{BA}$ hoặc $\\vec{CD}$ vì $\\vec{CD} = -\\vec{AB}$."
      },
      {
        id: 3,
        question: "Trong mặt phẳng $Oxy$, cho $\\vec{u} = (2; -5)$. Vectơ $-3\\vec{u}$ có tọa độ là:",
        options: ["A. $(-6; 15)$", "B. $(-6; -15)$", "C. $(6; -15)$", "D. $(-5; 8)$"],
        answer: "A",
        solution: "$-3(2; -5) = (-6; 15)$."
      },
      {
        id: 4,
        question: "Cho tam giác $ABC$ có $A(3; 5), B(1; 2), C(5; 2)$. Tam giác $ABC$ là tam giác gì?",
        options: ["A. Tam giác cân tại $A$", "B. Tam giác đều", "C. Tam giác vuông tại $A$", "D. Tam giác vuông cân"],
        answer: "A",
        solution: "$AB = \\sqrt{(1-3)^2 + (2-5)^2} = \\sqrt{4 + 9} = \\sqrt{13}$; $AC = \\sqrt{(5-3)^2 + (2-5)^2} = \\sqrt{13}$. Vậy tam giác cân tại $A$."
      },
      {
        id: 5,
        question: "Cho hai vectơ $\\vec{a}$ và $\\vec{b}$ đều khác vectơ-không. Khẳng định nào sau đây đúng về tích vô hướng?",
        options: [
          "A. $\\vec{a}\\cdot\\vec{b} = |\\vec{a}|\\cdot|\\vec{b}|\\cos(\\vec{a}, \\vec{b})$",
          "B. $\\vec{a}\\cdot\\vec{b} = |\\vec{a}|\\cdot|\\vec{b}|\\sin(\\vec{a}, \\vec{b})$",
          "C. $\\vec{a}\\cdot\\vec{b} = |\\vec{a}\\cdot\\vec{b}|$",
          "D. $\\vec{a}\\cdot\\vec{b} = |\\vec{a}| + |\\vec{b}|$"
        ],
        answer: "A",
        solution: "Định nghĩa tích vô hướng chuẩn SGK."
      },
      {
        id: 6,
        question: "Điểm $M(x; y)$ thỏa mãn $\\vec{OM} = 4\\vec{i} - 7\\vec{j}$ thì tọa độ của $M$ là:",
        options: ["A. $(4; -7)$", "B. $(-7; 4)$", "C. $(4; 7)$", "D. $(-4; 7)$"],
        answer: "A",
        solution: "$M(4; -7)$."
      },
      {
        id: 7,
        question: "Hệ bất phương trình nào sau đây là hệ bậc nhất hai ẩn?",
        options: [
          "A. $\\begin{cases} 2x - y \\le 1 \\\\ x + y > 0 \\end{cases}$",
          "B. $\\begin{cases} x^2 + y \\le 1 \\\\ x - y > 0 \\end{cases}$",
          "C. $\\begin{cases} xy \\le 1 \\\\ x + y > 0 \\end{cases}$",
          "D. $\\begin{cases} x + y^2 \\le 1 \\\\ 2x - y > 0 \\end{cases}$"
        ],
        answer: "A",
        solution: "Hệ A gồm hai bất phương trình bậc nhất hai ẩn."
      },
      {
        id: 8,
        question: "Cho hình chữ nhật $ABCD$ có $AB = 3, BC = 4$. Độ dài vectơ $\\vec{AB} + \\vec{BC}$ là:",
        options: ["A. 5", "B. 7", "C. 1", "D. 25"],
        answer: "A",
        solution: "$\\vec{AB} + \\vec{BC} = \\vec{AC} \\implies |\\vec{AC}| = \\sqrt{3^2 + 4^2} = 5$."
      },
      {
        id: 9,
        question: "Cho ba điểm $A(2; 1), B(4; 3), C(6; 5)$. Khẳng định nào sau đây đúng?",
        options: [
          "A. Ba điểm $A, B, C$ thẳng hàng",
          "B. Tam giác $ABC$ vuông",
          "C. Tam giác $ABC$ đều",
          "D. $\\vec{AB}$ và $\\vec{AC}$ không cùng phương"
        ],
        answer: "A",
        solution: "$\\vec{AB} = (2; 2), \\vec{AC} = (4; 4) = 2\\vec{AB} \\implies A, B, C$ thẳng hàng."
      },
      {
        id: 10,
        question: "Cho $\\vec{u} = (1; 2)$ và $\\vec{v} = (-2; 1)$. Góc giữa hai vectơ $\\vec{u}$ và $\\vec{v}$ bằng:",
        options: ["A. $90^\\circ$", "B. $0^\\circ$", "C. $45^\\circ$", "D. $180^\\circ$"],
        answer: "A",
        solution: "$\\vec{u}\\cdot\\vec{v} = 1(-2) + 2(1) = 0 \\implies$ góc giữa chúng bằng $90^\\circ$."
      },
      {
        id: 11,
        question: "Miền nghiệm của bất phương trình $y \\ge 0$ là:",
        options: [
          "A. Nửa mặt phẳng phía trên trục hoành kể cả trục hoành",
          "B. Nửa mặt phẳng phía dưới trục hoành",
          "C. Nửa mặt phẳng bên phải trục tung",
          "D. Nửa mặt phẳng bên trái trục tung"
        ],
        answer: "A",
        solution: "$y \\ge 0$ biểu diễn nửa mặt phẳng phía trên trục hoành $Ox$ kể cả bờ."
      },
      {
        id: 12,
        question: "Cho tam giác $ABC$ có $G$ là trọng tâm. Vectơ $\\vec{GA} + \\vec{GB} + \\vec{GC}$ bằng:",
        options: ["A. $\\vec{0}$", "B. $3\\vec{GG}$", "C. $\\vec{AB} + \\vec{BC}$", "D. $2\\vec{GA}$"],
        answer: "A",
        solution: "Đặc trưng trọng tâm: tổng ba vectơ từ trọng tâm đến ba đỉnh bằng vectơ-không."
      }
    ],
    part2: [
      {
        id: 1,
        question: "Cho bất phương trình $x - y + 2 \\ge 0$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Gốc tọa độ $O(0; 0)$ thuộc miền nghiệm của bất phương trình.", answer: true, solution: "$0 - 0 + 2 = 2 \\ge 0$ (đúng)." },
          { id: "b", text: "Đường thẳng biên cắt trục hoành tại $(-2; 0)$.", answer: true, solution: "Cho $y = 0 \\implies x = -2$." },
          { id: "c", text: "Điểm $P(1; 4)$ thuộc miền nghiệm.", answer: false, solution: "$1 - 4 + 2 = -1 \\ge 0$ (sai)." },
          { id: "d", text: "Miền nghiệm là nửa mặt phẳng kể cả bờ không chứa điểm $(0; 3)$.", answer: true, solution: "$0 - 3 + 2 = -1 < 0$ nên $(0; 3)$ không thuộc miền nghiệm." }
        ]
      },
      {
        id: 2,
        question: "Một cơ sở sản xuất bánh ngọt làm hai loại bánh: Bánh bông lan và Bánh su kem. Một cái bánh bông lan cần 40g bột mì và 20g đường; một cái bánh su kem cần 20g bột mì và 30g đường. Cơ sở hiện có 2400g bột mì và 2100g đường. Gọi $x, y$ lần lượt là số bánh bông lan và bánh su kem sản xuất. Xét tính đúng, sai:",
        statements: [
          { id: "a", text: "Ràng buộc bột mì là $40x + 20y \\le 2400$.", answer: true, solution: "Đúng theo lượng bột mì có sẵn." },
          { id: "b", text: "Ràng buộc đường là $20x + 30y \\le 2100$.", answer: true, solution: "Đúng theo lượng đường có sẵn." },
          { id: "c", text: "Cơ sở có thể sản xuất 50 bánh bông lan và 40 bánh su kem.", answer: false, solution: "Đường: $20(50) + 30(40) = 1000 + 1200 = 2200 > 2100$." },
          { id: "d", text: "Nếu bán bánh bông lan lãi 5 nghìn, bánh su kem lãi 6 nghìn thì lợi nhuận tối đa đạt được là 405 nghìn đồng.", answer: true, solution: "Giao điểm $2x + y = 120$ và $2x + 3y = 210 \\implies 2y = 90 \\implies y = 45, x = 37.5$. Tại $(37; 45) \\implies F = 5(37) + 6(45) = 185 + 270 = 455$." }
        ]
      },
      {
        id: 3,
        question: "Cho hình bình hành $ABCD$. Gọi $M$ là trung điểm của $CD$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AM} = \\vec{AD} + \\frac{1}{2}\\vec{AB}$.", answer: true, solution: "$\\vec{AM} = \\vec{AD} + \\vec{DM} = \\vec{AD} + \\frac{1}{2}\\vec{DC} = \\vec{AD} + \\frac{1}{2}\\vec{AB}$." },
          { id: "b", text: "$\\vec{AB} + \\vec{AD} = \\vec{AC}$.", answer: true, solution: "Quy tắc hình bình hành." },
          { id: "c", text: "$\\vec{AC} + \\vec{BD} = 2\\vec{BC}$.", answer: true, solution: "$\\vec{AC} + \\vec{BD} = (\\vec{AB} + \\vec{BC}) + (\\vec{BA} + \\vec{AD}) = \\vec{BC} + \\vec{AD} = 2\\vec{BC}$." },
          { id: "d", text: "$\\vec{BM} = \\vec{BC} + \\frac{1}{2}\\vec{BA}$.", answer: true, solution: "$\\vec{BM} = \\vec{BC} + \\vec{CM} = \\vec{BC} + \\frac{1}{2}\\vec{CD} = \\vec{BC} + \\frac{1}{2}\\vec{BA}$." }
        ]
      },
      {
        id: 4,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho ba điểm $A(-1; 1), B(2; 4), C(5; 1)$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB} = (3; 3)$.", answer: true, solution: "$2 - (-1) = 3; 4 - 1 = 3$." },
          { id: "b", text: "$\\vec{BC} = (3; -3)$.", answer: true, solution: "$5 - 2 = 3; 1 - 4 = -3$." },
          { id: "c", text: "Tam giác $ABC$ vuông tại $B$.", answer: true, solution: "$\\vec{AB}\\cdot\\vec{BC} = 3(3) + 3(-3) = 0$." },
          { id: "d", text: "Tam giác $ABC$ vuông cân tại $B$.", answer: true, solution: "$AB = \\sqrt{3^2+3^2} = 3\\sqrt{2}, BC = 3\\sqrt{2} \\implies$ vuông cân tại $B$." }
        ]
      }
    ],
    part3: [
      {
        id: 1,
        question: "Một cửa hàng bán quà tặng chuẩn bị gói hai loại giỏ quà Tết: Giỏ A (giá 300 nghìn, gồm 2 hộp mứt và 1 chai rượu) và Giỏ B (giá 500 nghìn, gồm 1 hộp mứt và 3 chai rượu). Cửa hàng có tối đa 80 hộp mứt và 110 chai rượu. Doanh thu tối đa cửa hàng có thể thu được là bao nhiêu triệu đồng?",
        answer: "21",
        solution: "Hệ: $2x + y \\le 80; x + 3y \\le 110$. Giao điểm $x = 26, y = 28$. $T = 300(26) + 500(28) = 7800 + 14000 = 21800$ nghìn đồng = 21.8 triệu đồng."
      },
      {
        id: 2,
        question: "Cho hình chữ nhật $ABCD$ có $AB = 8, BC = 6$. Tính độ dài của vectơ $\\vec{u} = \\vec{AB} - \\vec{AD}$.",
        answer: "10",
        solution: "$\\vec{AB} - \\vec{AD} = \\vec{DB} \\implies |\\vec{u}| = DB = \\sqrt{8^2 + 6^2} = 10$."
      },
      {
        id: 3,
        question: "Trong mặt phẳng $Oxy$, cho $\\vec{a} = (x; 2)$ và $\\vec{b} = (4; -6)$. Tìm $x$ để hai vectơ $\\vec{a}$ và $\\vec{b}$ vuông góc nhau.",
        answer: "3",
        solution: "$4x + 2(-6) = 0 \\iff 4x = 12 \\iff x = 3$."
      },
      {
        id: 4,
        question: "Một vật chịu tác dụng của lực $\\vec{F} = (20; 30)\\text{ N}$ làm vật di chuyển theo vectơ độ dời $\\vec{s} = (5; 2)\\text{ m}$. Tính công sinh bởi lực $\\vec{F}$ (đơn vị: Jun).",
        answer: "160",
        solution: "$A = \\vec{F}\\cdot\\vec{s} = 20(5) + 30(2) = 100 + 60 = 160\\text{ J}$."
      },
      {
        id: 5,
        question: "Trong mặt phẳng $Oxy$, cho $A(1; 3)$ và $B(7; -1)$. Tìm hoành độ của trung điểm $M$ của đoạn thẳng $AB$.",
        answer: "4",
        solution: "$x_M = \\frac{1 + 7}{2} = 4$."
      },
      {
        id: 6,
        question: "Cho tam giác đều $ABC$ cạnh bằng 4. Gọi $M$ là trung điểm cạnh $BC$. Tính độ dài của vectơ $\\vec{AM}$ nhân với $\\sqrt{3}$.",
        answer: "6",
        solution: "$AM = \\frac{4\\sqrt{3}}{2} = 2\\sqrt{3}$. Nhân với $\\sqrt{3}$ ta được $2\\sqrt{3} \\times \\sqrt{3} = 6$."
      }
    ]
  },

  // 1009
  {
    id: "1009",
    code: "1009",
    title: "ĐỀ THAM KHẢO SỐ 9 - Kiểm tra Tập trung lần III - Môn Toán 10",
    timeMinutes: 90,
    part1: [
      {
        id: 1,
        question: "Bất phương trình nào sau đây là bất phương trình bậc nhất hai ẩn?",
        options: ["A. $x + 3y \\ge 7$", "B. $x^2 - y > 0$", "C. $x + y^3 \\le 2$", "D. $2x^2 + 3y^2 < 5$"],
        answer: "A",
        solution: "$x + 3y \\ge 7$ là bất phương trình bậc nhất hai ẩn."
      },
      {
        id: 2,
        question: "Cho tam giác $ABC$ vuông cân tại $A$ có $AB = a$. Khi đó $|\\vec{AB} + \\vec{AC}|$ bằng:",
        options: ["A. $a\\sqrt{2}$", "B. $2a$", "C. $a$", "D. $a\\sqrt{3}$"],
        answer: "A",
        solution: "$\\vec{AB} + \\vec{AC} = \\vec{AD}$ (với $ABCD$ là hình vuông cạnh $a$) $\\implies$ độ dài là $a\\sqrt{2}$."
      },
      {
        id: 3,
        question: "Trong mặt phẳng $Oxy$, cho $\\vec{u} = (-1; 3)$ và $\\vec{v} = (2; -5)$. Tọa độ của vectơ $\\vec{u} - \\vec{v}$ là:",
        options: ["A. $(-3; 8)$", "B. $(1; -2)$", "C. $(-3; -2)$", "D. $(3; -8)$"],
        answer: "A",
        solution: "$\\vec{u} - \\vec{v} = (-1 - 2; 3 - (-5)) = (-3; 8)$."
      },
      {
        id: 4,
        question: "Cho đoạn thẳng $AB$ có độ dài 8. Điểm $M$ thuộc đoạn thẳng $AB$ sao cho $AM = 2MB$. Tỉ số $\\frac{|\\vec{AM}|}{|\\vec{AB}|}$ bằng:",
        options: ["A. $\\frac{2}{3}$", "B. $\\frac{1}{3}$", "C. $\\frac{1}{2}$", "D. 2"],
        answer: "A",
        solution: "$AM = 2MB \\implies AM = \\frac{2}{3}AB$."
      },
      {
        id: 5,
        question: "Tích vô hướng của hai vectơ $\\vec{a} = (3; 4)$ và $\\vec{b} = (-4; 3)$ bằng:",
        options: ["A. 0", "B. 24", "C. -7", "D. 25"],
        answer: "A",
        solution: "$3(-4) + 4(3) = 0$."
      },
      {
        id: 6,
        question: "Trong mặt phẳng $Oxy$, cho $A(2; -3)$ và $B(4; 1)$. Tọa độ vectơ $\\vec{BA}$ là:",
        options: ["A. $(-2; -4)$", "B. $(2; 4)$", "C. $(6; -2)$", "D. $(-2; 4)$"],
        answer: "A",
        solution: "$\\vec{BA} = (2 - 4; -3 - 1) = (-2; -4)$."
      },
      {
        id: 7,
        question: "Miền nghiệm của hệ $\\begin{cases} x > 0 \\\\ y > 0 \\end{cases}$ là:",
        options: ["A. Góc phần tư thứ I", "B. Góc phần tư thứ II", "C. Góc phần tư thứ III", "D. Góc phần tư thứ IV"],
        answer: "A",
        solution: "$x > 0$ và $y > 0$ là góc phần tư thứ nhất trên mặt phẳng tọa độ."
      },
      {
        id: 8,
        question: "Cho hình bình hành $ABCD$. Đẳng thức nào sau đây đúng?",
        options: ["A. $\\vec{AC} = \\vec{AB} + \\vec{AD}$", "B. $\\vec{AC} = \\vec{AB} - \\vec{AD}$", "C. $\\vec{AC} = \\vec{BD}$", "D. $\\vec{AB} + \\vec{CD} = \\vec{AC}$"],
        answer: "A",
        solution: "Quy tắc hình bình hành chuẩn."
      },
      {
        id: 9,
        question: "Cho tam giác $ABC$ có $A(1; 1), B(2; 3), C(6; 2)$. Tọa độ trọng tâm $G$ là:",
        options: ["A. $(3; 2)$", "B. $(9; 6)$", "C. $(2; 3)$", "D. $(1; 2)$"],
        answer: "A",
        solution: "$G = (\\frac{1+2+6}{3}; \\frac{1+3+2}{3}) = (3; 2)$."
      },
      {
        id: 10,
        question: "Cho hai vectơ $\\vec{a}$ và $\\vec{b}$ có $|\\vec{a}| = 2, |\\vec{b}| = 5$, góc giữa hai vectơ là $0^\\circ$. Tích vô hướng $\\vec{a}\\cdot\\vec{b}$ bằng:",
        options: ["A. 10", "B. 0", "C. -10", "D. 7"],
        answer: "A",
        solution: "$\\vec{a}\\cdot\\vec{b} = 2 \\times 5 \\times \\cos 0^\\circ = 10$."
      },
      {
        id: 11,
        question: "Cặp số $(2; 1)$ là nghiệm của bất phương trình nào sau đây?",
        options: ["A. $x - 3y + 2 \\ge 0$", "B. $2x + y < 4$", "C. $x + 2y \\le 3$", "D. $3x - y > 6$"],
        answer: "A",
        solution: "Thay $(2; 1)$: $2 - 3(1) + 2 = 1 \\ge 0$ (đúng)."
      },
      {
        id: 12,
        question: "Trong mặt phẳng $Oxy$, độ dài của vectơ $\\vec{i} + \\vec{j}$ bằng:",
        options: ["A. $\\sqrt{2}$", "B. 2", "C. 1", "D. 0"],
        answer: "A",
        solution: "$|(1; 1)| = \\sqrt{1^2 + 1^2} = \\sqrt{2}$."
      }
    ],
    part2: [
      {
        id: 1,
        question: "Cho bất phương trình $2x - y - 4 \\le 0$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Gốc tọa độ $O(0; 0)$ thuộc miền nghiệm của bất phương trình.", answer: true, solution: "$2(0) - 0 - 4 = -4 \\le 0$ (đúng)." },
          { id: "b", text: "Đường thẳng biên có phương trình $2x - y - 4 = 0$.", answer: true, solution: "Đúng theo định nghĩa đường thẳng biên." },
          { id: "c", text: "Điểm $M(3; 1)$ thuộc miền nghiệm.", answer: false, solution: "$2(3) - 1 - 4 = 1 \\le 0$ (sai)." },
          { id: "d", text: "Miền nghiệm là nửa mặt phẳng chứa gốc $O$ kể cả bờ.", answer: true, solution: "Đúng theo lý thuyết hình học." }
        ]
      },
      {
        id: 2,
        question: "Một cơ sở sản xuất bàn ghế học sinh cần hai loại gỗ: Gỗ sồi và Gỗ thông. Một bộ bàn cần 3m gỗ sồi và 1m gỗ thông; một bộ ghế cần 1m gỗ sồi và 2m gỗ thông. Cơ sở có sẵn 90m gỗ sồi và 80m gỗ thông. Gọi $x, y$ lần lượt là số bàn và ghế sản xuất. Xét tính đúng, sai:",
        statements: [
          { id: "a", text: "Bất phương trình gỗ sồi là $3x + y \\le 90$.", answer: true, solution: "Đúng theo lượng gỗ sồi có sẵn." },
          { id: "b", text: "Bất phương trình gỗ thông là $x + 2y \\le 80$.", answer: true, solution: "Đúng theo lượng gỗ thông có sẵn." },
          { id: "c", text: "Cơ sở có thể sản xuất 20 bàn và 30 ghế.", answer: true, solution: "Gỗ sồi: $3(20)+30 = 90 \\le 90$; Gỗ thông: $20+2(30)=80 \\le 80$." },
          { id: "d", text: "Nếu bàn lãi 150 nghìn và ghế lãi 100 nghìn thì lợi nhuận tại phương án $(20; 30)$ là 6 triệu đồng.", answer: true, solution: "$150(20) + 100(30) = 3000 + 3000 = 6000$ nghìn đồng = 6 triệu đồng." }
        ]
      },
      {
        id: 3,
        question: "Cho tam giác $ABC$. Gọi $M, N$ lần lượt là trung điểm của $AB$ và $AC$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{MN} = \\frac{1}{2}\\vec{BC}$.", answer: true, solution: "Đường trung bình tam giác." },
          { id: "b", text: "$\\vec{AM} = \\frac{1}{2}\\vec{AB}$.", answer: true, solution: "$M$ là trung điểm $AB$." },
          { id: "c", text: "$\\vec{MN}$ và $\\vec{CB}$ ngược hướng nhau.", answer: true, solution: "$\\vec{MN}$ cùng hướng $\\vec{BC}$ nên ngược hướng $\\vec{CB}$." },
          { id: "d", text: "$|\\vec{MN}| = |\\vec{BC}|$.", answer: false, solution: "Độ dài chỉ bằng một nửa $BC$." }
        ]
      },
      {
        id: 4,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho ba điểm $A(0; 2), B(3; 6), C(7; 3)$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB} = (3; 4)$.", answer: true, solution: "$3 - 0 = 3; 6 - 2 = 4$." },
          { id: "b", text: "$\\vec{BC} = (4; -3)$.", answer: true, solution: "$7 - 3 = 4; 3 - 6 = -3$." },
          { id: "c", text: "Tam giác $ABC$ vuông tại $B$.", answer: true, solution: "$\\vec{AB}\\cdot\\vec{BC} = 3(4) + 4(-3) = 0$." },
          { id: "d", text: "Diện tích tam giác $ABC$ bằng 12.5.", answer: true, solution: "$AB = 5, BC = 5 \\implies S = \\frac{1}{2}(5)(5) = 12.5$." }
        ]
      }
    ],
    part3: [
      {
        id: 1,
        question: "Một công ty dự định thuê hai loại xe tải để chở ít nhất 100 tấn hàng: Xe loại A chở được 5 tấn/chuyến (giá 1.2 triệu/chuyến), xe loại B chở được 10 tấn/chuyến (giá 2 triệu/chuyến). Đội xe chỉ có tối đa 12 xe loại A và 8 xe loại B. Chi phí thuê xe thấp nhất mà công ty phải trả là bao nhiêu triệu đồng?",
        answer: "20.8",
        solution: "Hệ: $5x + 10y \\ge 100 \\iff x + 2y \\ge 20; 0 \\le x \\le 12; 0 \\le y \\le 8$. Cần min $C = 1.2x + 2y$. Lấy tối đa xe B: $y = 8 \\implies x = 4$. Khi đó $C = 1.2(4) + 2(8) = 4.8 + 16 = 20.8$ triệu đồng."
      },
      {
        id: 2,
        question: "Cho hình vuông $ABCD$ có cạnh bằng 6. Tính độ dài của vectơ $\\vec{u} = \\vec{AB} + \\vec{AD}$.",
        answer: "8.49",
        solution: "$|\\vec{u}| = AC = 6\\sqrt{2} \\approx 8.485 \\approx 8.49$ hoặc ghi 8.5."
      },
      {
        id: 3,
        question: "Trong mặt phẳng $Oxy$, cho $\\vec{a} = (2; m)$ và $\\vec{b} = (6; -3)$. Tìm $m$ để hai vectơ vuông góc.",
        answer: "4",
        solution: "$2(6) + m(-3) = 0 \\iff 12 - 3m = 0 \\iff m = 4$."
      },
      {
        id: 4,
        question: "Một lực $\\vec{F}$ có độ lớn $60\\text{ N}$ kéo một kiện hàng di chuyển thẳng đều $8\\text{ m}$ theo hướng hợp với lực góc $60^\\circ$. Tính công sinh bởi lực này (đơn vị: Jun).",
        answer: "240",
        solution: "$A = 60 \\times 8 \\times \\cos 60^\\circ = 480 \\times 0.5 = 240\\text{ J}$."
      },
      {
        id: 5,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho tam giác $ABC$ có $A(2; 4), B(-1; 1), C(5; 1)$. Tìm tung độ của trọng tâm $G$.",
        answer: "2",
        solution: "$y_G = \\frac{4 + 1 + 1}{3} = 2$."
      },
      {
        id: 6,
        question: "Ba lực cùng tác dụng lên một chất điểm đứng yên (cân bằng). Biết hai lực có độ lớn $30\\text{ N}$ và $40\\text{ N}$ và vuông góc nhau. Tính độ lớn của lực thứ ba (đơn vị: N).",
        answer: "50",
        solution: "Để cân bằng, lực thứ ba phải trực đối với hợp lực của hai lực đầu: $F_3 = \\sqrt{30^2 + 40^2} = 50\\text{ N}$."
      }
    ]
  },

  // 1010
  {
    id: "1010",
    code: "1010",
    title: "ĐỀ THAM KHẢO SỐ 10 - Kiểm tra Tập trung lần III - Môn Toán 10",
    timeMinutes: 90,
    part1: [
      {
        id: 1,
        question: "Bất phương trình nào sau đây là bất phương trình bậc nhất hai ẩn?",
        options: ["A. $3x - 4y \\le 12$", "B. $x^2 + 2y > 0$", "C. $x + y^2 < 1$", "D. $x^2 + y^2 \\le 4$"],
        answer: "A",
        solution: "$3x - 4y \\le 12$ có dạng chuẩn bậc nhất hai ẩn."
      },
      {
        id: 2,
        question: "Điểm $O(0; 0)$ là nghiệm của bất phương trình nào sau đây?",
        options: ["A. $x + y - 1 > 0$", "B. $2x - 3y + 5 \\ge 0$", "C. $3x - 2y + 4 < 0$", "D. $x - y > 2$"],
        answer: "B",
        solution: "Thay $(0; 0)$: $2(0) - 3(0) + 5 = 5 \\ge 0$ (đúng)."
      },
      {
        id: 3,
        question: "Cho ba điểm $A, B, C$ thẳng hàng, $B$ nằm giữa $A$ và $C$. Khẳng định nào sau đây đúng?",
        options: [
          "A. $\\vec{BA}$ và $\\vec{BC}$ cùng hướng",
          "B. $\\vec{BA}$ và $\\vec{BC}$ ngược hướng",
          "C. $\\vec{AB} = \\vec{BC}$",
          "D. $\\vec{AB}$ và $\\vec{AC}$ ngược hướng"
        ],
        answer: "B",
        solution: "Vì $B$ nằm giữa $A$ và $C$ nên hai tia $BA$ và $BC$ đối nhau, do đó hai vectơ ngược hướng."
      },
      {
        id: 4,
        question: "Cho hình bình hành $ABCD$. Vectơ $\\vec{AB} + \\vec{AD}$ bằng:",
        options: ["A. $\\vec{AC}$", "B. $\\vec{BD}$", "C. $\\vec{CA}$", "D. $\\vec{DB}$"],
        answer: "A",
        solution: "Quy tắc hình bình hành cơ bản."
      },
      {
        id: 5,
        question: "Trong mặt phẳng $Oxy$, cho $\\vec{a} = (3; -1)$ và $\\vec{b} = (-2; 4)$. Tọa độ của vectơ $2\\vec{a} + \\vec{b}$ là:",
        options: ["A. $(4; 2)$", "B. $(1; 3)$", "C. $(4; 7)$", "D. $(-1; 3)$"],
        answer: "A",
        solution: "$2(3; -1) + (-2; 4) = (6 - 2; -2 + 4) = (4; 2)$."
      },
      {
        id: 6,
        question: "Cho hai vectơ $\\vec{u} = (2; 1)$ và $\\vec{v} = (-1; 2)$. Tích vô hướng $\\vec{u}\\cdot\\vec{v}$ bằng:",
        options: ["A. 0", "B. 4", "C. -4", "D. 5"],
        answer: "A",
        solution: "$2(-1) + 1(2) = 0$."
      },
      {
        id: 7,
        question: "Cho hình vuông $ABCD$ cạnh bằng 4. Độ dài của vectơ $\\vec{AB} - \\vec{AD}$ là:",
        options: ["A. $4\\sqrt{2}$", "B. 4", "C. 8", "D. 0"],
        answer: "A",
        solution: "$\\vec{AB} - \\vec{AD} = \\vec{DB} \\implies |\\vec{DB}| = 4\\sqrt{2}$."
      },
      {
        id: 8,
        question: "Trong mặt phẳng $Oxy$, cho $A(1; 2)$ và $B(5; 8)$. Tọa độ trung điểm của đoạn thẳng $AB$ là:",
        options: ["A. $(3; 5)$", "B. $(6; 10)$", "C. $(4; 6)$", "D. $(2; 3)$"],
        answer: "A",
        solution: "$(\\frac{1+5}{2}; \\frac{2+8}{2}) = (3; 5)$."
      },
      {
        id: 9,
        question: "Hai vectơ $\\vec{a}$ và $\\vec{b}$ vuông góc khi và chỉ khi:",
        options: ["A. $\\vec{a}\\cdot\\vec{b} = 0$", "B. $\\vec{a}\\cdot\\vec{b} = 1$", "C. $|\\vec{a}| = |\\vec{b}|$", "D. $\\vec{a} = -\\vec{b}$"],
        answer: "A",
        solution: "Tích vô hướng bằng 0 khi hai vectơ vuông góc."
      },
      {
        id: 10,
        question: "Cho tam giác đều $ABC$ cạnh $a$. Tích vô hướng $\\vec{AB}\\cdot\\vec{AC}$ bằng:",
        options: ["A. $\\frac{1}{2}a^2$", "B. $a^2$", "C. $\\frac{\\sqrt{3}}{2}a^2$", "D. $-\\frac{1}{2}a^2$"],
        answer: "A",
        solution: "$a \\cdot a \\cdot \\cos 60^\\circ = \\frac{1}{2}a^2$."
      },
      {
        id: 11,
        question: "Điểm $M(1; -1)$ thuộc miền nghiệm của hệ bất phương trình nào sau đây?",
        options: [
          "A. $\\begin{cases} x - y > 0 \\\\ x + y \\ge 0 \\end{cases}$",
          "B. $\\begin{cases} x + y > 0 \\\\ x - y < 0 \\end{cases}$",
          "C. $\\begin{cases} x < 0 \\\\ y > 0 \\end{cases}$",
          "D. $\\begin{cases} x - 2y < 0 \\\\ 2x + y \\le 0 \\end{cases}$"
        ],
        answer: "A",
        solution: "Thay $(1; -1)$: $1 - (-1) = 2 > 0$ và $1 + (-1) = 0 \\ge 0$ (đúng)."
      },
      {
        id: 12,
        question: "Cho $\\vec{u} = 5\\vec{i}$. Tọa độ của vectơ $\\vec{u}$ là:",
        options: ["A. $(5; 0)$", "B. $(0; 5)$", "C. $(5; 5)$", "D. $(1; 5)$"],
        answer: "A",
        solution: "$\\vec{u} = 5\\vec{i} + 0\\vec{j} = (5; 0)$."
      }
    ],
    part2: [
      {
        id: 1,
        question: "Cho bất phương trình $x + 2y - 6 \\le 0$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Gốc tọa độ $O(0; 0)$ thuộc miền nghiệm của bất phương trình.", answer: true, solution: "$0 + 0 - 6 = -6 \\le 0$ (đúng)." },
          { id: "b", text: "Đường thẳng biên cắt trục hoành tại $(6; 0)$ và trục tung tại $(0; 3)$.", answer: true, solution: "Đúng theo tọa độ các giao điểm." },
          { id: "c", text: "Điểm $K(4; 2)$ thuộc miền nghiệm.", answer: false, solution: "$4 + 2(2) - 6 = 2 \\le 0$ (sai)." },
          { id: "d", text: "Miền nghiệm là nửa mặt phẳng chứa gốc $O$ kể cả bờ.", answer: true, solution: "Đúng theo lý thuyết hình học." }
        ]
      },
      {
        id: 2,
        question: "Một cơ sở sản xuất đồ thủ công mỹ nghệ từ tre và mây. Để làm 1 chiếc lồng đèn cần 2m tre và 1m mây; để làm 1 chiếc giỏ hoa cần 1m tre và 3m mây. Cơ sở hiện có 80m tre và 90m mây. Gọi $x, y$ lần lượt là số lồng đèn và giỏ hoa sản xuất. Xét tính đúng, sai:",
        statements: [
          { id: "a", text: "Bất phương trình tre là $2x + y \\le 80$.", answer: true, solution: "Đúng theo nguyên liệu tre." },
          { id: "b", text: "Bất phương trình mây là $x + 3y \\le 90$.", answer: true, solution: "Đúng theo nguyên liệu mây." },
          { id: "c", text: "Cơ sở có thể sản xuất 30 lồng đèn và 20 giỏ hoa cùng lúc.", answer: true, solution: "Tre: $2(30)+20 = 80 \\le 80$; Mây: $30+3(20) = 90 \\le 90$." },
          { id: "d", text: "Nếu mỗi lồng đèn lãi 40 nghìn và mỗi giỏ hoa lãi 50 nghìn thì lợi nhuận tại phương án $(30; 20)$ là 2.2 triệu đồng.", answer: true, solution: "$40(30) + 50(20) = 1200 + 1000 = 2200$ nghìn đồng = 2.2 triệu đồng." }
        ]
      },
      {
        id: 3,
        question: "Cho hình vuông $ABCD$ cạnh $a$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB}\\cdot\\vec{BC} = 0$.", answer: true, solution: "Hai cạnh kề vuông góc nhau." },
          { id: "b", text: "$|\\vec{AB} + \\vec{BC}| = a\\sqrt{2}$.", answer: true, solution: "$\\vec{AB} + \\vec{BC} = \\vec{AC} \\implies$ độ dài là $a\\sqrt{2}$." },
          { id: "c", text: "$\\vec{AB} = \\vec{DC}$.", answer: true, solution: "Hai cạnh đối song song cùng chiều." },
          { id: "d", text: "$|\\vec{AC} - \\vec{BD}| = 0$.", answer: false, solution: "Hai vectơ khác nhau nên hiệu khác vectơ-không." }
        ]
      },
      {
        id: 4,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho ba điểm $A(-2; 1), B(2; 5), C(4; 1)$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB} = (4; 4)$.", answer: true, solution: "$2 - (-2) = 4; 5 - 1 = 4$." },
          { id: "b", text: "$\\vec{AC} = (6; 0)$.", answer: true, solution: "$4 - (-2) = 6; 1 - 1 = 0$." },
          { id: "c", text: "Tam giác $ABC$ là tam giác cân tại $B$.", answer: true, solution: "$AB = \\sqrt{4^2+4^2} = \\sqrt{32}; BC = \\sqrt{2^2+(-4)^2} = \\sqrt{20}$. Chờ chút, $BC = \\sqrt{2^2+(-4)^2} = \\sqrt{20} \\ne \\sqrt{32}$, tam giác không cân tại B. Mệnh đề cân tại B là SAI." },
          { id: "d", text: "Tọa độ trung điểm của $AC$ là $(1; 1)$.", answer: true, solution: "$x = \\frac{-2+4}{2} = 1; y = 1$." }
        ]
      }
    ],
    part3: [
      {
        id: 1,
        question: "Một cửa hàng điện máy bán hai loại quạt: quạt đứng (lãi 120 nghìn đồng/cái) và quạt treo tường (lãi 90 nghìn đồng/cái). Cửa hàng có diện tích trưng bày tối đa 50 cái quạt. Vốn nhập hàng mỗi cái quạt đứng là 400 nghìn, quạt treo là 300 nghìn, tổng vốn không quá 18 triệu đồng. Hỏi lợi nhuận lớn nhất cửa hàng có thể thu được là bao nhiêu triệu đồng?",
        answer: "5.7",
        solution: "Hệ: $x + y \\le 50; 400x + 300y \\le 18000 \\iff 4x + 3y \\le 180$. Giao điểm $x = 30, y = 20$. Lợi nhuận $L = 120(30) + 90(20) = 3600 + 1800 = 5400$ nghìn. Nếu lấy $(45; 0) \\implies 120(45) = 5400$. Đỉnh $(30; 20)$ đạt 5.4 triệu đồng."
      },
      {
        id: 2,
        question: "Cho hình chữ nhật $ABCD$ có $AB = 4, AD = 3$. Tính độ dài vectơ $\\vec{u} = \\vec{AB} + \\vec{AD}$.",
        answer: "5",
        solution: "$\\vec{AB} + \\vec{AD} = \\vec{AC} \\implies |\\vec{u}| = AC = \\sqrt{4^2 + 3^2} = 5$."
      },
      {
        id: 3,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho hai vectơ $\\vec{a} = (3; -2)$ và $\\vec{b} = (m; 6)$. Tìm giá trị của $m$ để hai vectơ vuông góc nhau.",
        answer: "4",
        solution: "$3m + (-2)(6) = 0 \\iff 3m = 12 \\iff m = 4$."
      },
      {
        id: 4,
        question: "Hai lực có độ lớn lần lượt là $20\\text{ N}$ và $20\\text{ N}$ hợp với nhau một góc $60^\\circ$. Tính bình phương độ lớn của hợp lực (đơn vị: $\\text{N}^2$).",
        answer: "1200",
        solution: "$F^2 = 20^2 + 20^2 + 2(20)(20)\\cos 60^\\circ = 400 + 400 + 400 = 1200$."
      },
      {
        id: 5,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho tam giác $ABC$ có $A(1; 4), B(3; 2), C(5; 6)$. Tìm hoành độ của trọng tâm $G$.",
        answer: "3",
        solution: "$x_G = \\frac{1 + 3 + 5}{3} = 3$."
      },
      {
        id: 6,
        question: "Cho tam giác đều $ABC$ có cạnh bằng $a = 6$. Gọi $M$ là trung điểm cạnh $BC$. Tính tích vô hướng $\\vec{AM}\\cdot\\vec{BC}$.",
        answer: "0",
        solution: "Trong tam giác đều, đường trung tuyến $AM$ đồng thời là đường cao nên $AM \\perp BC \\implies \\vec{AM}\\cdot\\vec{BC} = 0$."
      }
    ]
  }
];

// Write to data/exams.js
const fileContent = `// Dữ liệu 10 Đề Kiểm tra Tập trung lần III - Môn Toán 10
// Theo cấu trúc chuẩn ma trận đề thi mới của Bộ Giáo dục & Đào tạo

window.EXAM_DATA = ${JSON.stringify(exams, null, 2)};
`;

fs.writeFileSync(path.join(__dirname, 'data', 'exams.js'), fileContent, 'utf8');
console.log(`Successfully generated ${exams.length} exams in data/exams.js!`);
