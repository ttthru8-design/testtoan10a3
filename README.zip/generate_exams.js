// Generator script for exams data
const fs = require('fs');
const path = require('path');

const exams = [
  // ==========================================
  // ĐỀ 1 - MÃ ĐỀ 1001
  // ==========================================
  {
    id: "1001",
    code: "1001",
    title: "ĐỀ THAM KHẢO SỐ 1 - Kiểm tra Tập trung lần III - Môn Toán 10",
    timeMinutes: 90,
    part1: [
      {
        id: 1,
        question: "Bất phương trình nào sau đây là bất phương trình bậc nhất hai ẩn?",
        options: [
          "A. $x^2 + y > 0$",
          "B. $2x - 3y \\le 5$",
          "C. $x + y^2 \\ge 1$",
          "D. $x^3 + 2y < 4$"
        ],
        answer: "B",
        solution: "Bất phương trình bậc nhất hai ẩn có dạng $ax + by < c$ (hoặc $\\le, >, \\ge$) với $a, b$ không đồng thời bằng 0. Do đó $2x - 3y \\le 5$ là bất phương trình bậc nhất hai ẩn."
      },
      {
        id: 2,
        question: "Cặp số $(x; y) = (1; -2)$ là nghiệm của bất phương trình nào sau đây?",
        options: [
          "A. $x + y > 0$",
          "B. $2x - y < 0$",
          "C. $x - 3y \\ge 5$",
          "D. $-x + y \\ge -1$"
        ],
        answer: "C",
        solution: "Thay $x = 1, y = -2$ vào $x - 3y \\ge 5$ ta được $1 - 3(-2) = 7 \\ge 5$ (luôn đúng)."
      },
      {
        id: 3,
        question: "Hệ bất phương trình nào sau đây là hệ bất phương trình bậc nhất hai ẩn?",
        options: [
          "A. $\\begin{cases} x + y > 0 \\\\ x^2 < 2 \\end{cases}$",
          "B. $\\begin{cases} 2x - y \\ge 1 \\\\ x + 3y \\le 5 \\end{cases}$",
          "C. $\\begin{cases} x + y^2 > 1 \\\\ y < 0 \\end{cases}$",
          "D. $\\begin{cases} x - y = 0 \\\\ x^3 + y > 1 \\end{cases}$"
        ],
        answer: "B",
        solution: "Hệ $\\begin{cases} 2x - y \\ge 1 \\\\ x + 3y \\le 5 \\end{cases}$ gồm hai bất phương trình bậc nhất hai ẩn $x, y$."
      },
      {
        id: 4,
        question: "Điểm $M(0; 1)$ thuộc miền nghiệm của hệ bất phương trình nào sau đây?",
        options: [
          "A. $\\begin{cases} x + y \\ge 2 \\\\ x - y \\le 0 \\end{cases}$",
          "B. $\\begin{cases} 2x + y > 0 \\\\ x - 3y < 1 \\end{cases}$",
          "C. $\\begin{cases} x - y > 1 \\\\ x + y < 5 \\end{cases}$",
          "D. $\\begin{cases} x \\ge 1 \\\\ y \\le 2 \\end{cases}$"
        ],
        answer: "B",
        solution: "Thay $x = 0, y = 1$ vào phương án B: $2(0) + 1 = 1 > 0$ và $0 - 3(1) = -3 < 1$. Cả hai bất phương trình đều đúng."
      },
      {
        id: 5,
        question: "Hai vectơ được gọi là bằng nhau nếu chúng:",
        options: [
          "A. Cùng phương và cùng độ dài.",
          "B. Cùng hướng và cùng độ dài.",
          "C. Cùng phương.",
          "D. Cùng độ dài."
        ],
        answer: "B",
        solution: "Theo định nghĩa, hai vectơ bằng nhau nếu chúng cùng hướng và có cùng độ dài."
      },
      {
        id: 6,
        question: "Cho ba điểm $A, B, C$ bất kì. Khẳng định nào sau đây đúng?",
        options: [
          "A. $\\vec{AB} + \\vec{BC} = \\vec{CA}$",
          "B. $\\vec{AB} - \\vec{AC} = \\vec{BC}$",
          "C. $\\vec{AB} + \\vec{BC} = \\vec{AC}$",
          "D. $\\vec{AC} - \\vec{AB} = \\vec{BC}$"
        ],
        answer: "C",
        solution: "Theo quy tắc ba điểm đối với phép cộng vectơ: $\\vec{AB} + \\vec{BC} = \\vec{AC}$."
      },
      {
        id: 7,
        question: "Cho hình vuông $ABCD$ có cạnh bằng $a$. Tính độ dài vectơ $\\vec{AB} + \\vec{AD}$.",
        options: [
          "A. $a$",
          "B. $2a$",
          "C. $a\\sqrt{2}$",
          "D. $a\\sqrt{3}$"
        ],
        answer: "C",
        solution: "Theo quy tắc hình bình hành: $\\vec{AB} + \\vec{AD} = \\vec{AC}$. Do $ABCD$ là hình vuông cạnh $a$ nên đường chéo $AC = a\\sqrt{2}$. Vậy $|\\vec{AB} + \\vec{AD}| = AC = a\\sqrt{2}$."
      },
      {
        id: 8,
        question: "Cho vectơ $\\vec{a} \\ne \\vec{0}$ và số thực $k < 0$. Khẳng định nào sau đây đúng về vectơ $k\\vec{a}$?",
        options: [
          "A. Cùng hướng với $\\vec{a}$ và độ dài bằng $k|\\vec{a}|$.",
          "B. Ngược hướng với $\\vec{a}$ và độ dài bằng $-k|\\vec{a}|$.",
          "C. Cùng hướng với $\\vec{a}$ và độ dài bằng $-k|\\vec{a}|$.",
          "D. Ngược hướng với $\\vec{a}$ và độ dài bằng $k|\\vec{a}|$."
        ],
        answer: "B",
        solution: "Vì $k < 0$ nên vectơ $k\\vec{a}$ ngược hướng với $\\vec{a}$, và có độ dài $|k\\vec{a}| = |k|\\cdot |\\vec{a}| = -k|\\vec{a}|$."
      },
      {
        id: 9,
        question: "Cho đoạn thẳng $AB$ có trung điểm $I$. Mệnh đề nào sau đây đúng?",
        options: [
          "A. $\\vec{IA} = \\vec{IB}$",
          "B. $\\vec{IA} + \\vec{IB} = \\vec{0}$",
          "C. $\\vec{AI} + \\vec{BI} = \\vec{AB}$",
          "D. $\\vec{IA} - \\vec{IB} = \\vec{0}$"
        ],
        answer: "B",
        solution: "Vì $I$ là trung điểm của $AB$ nên hai vectơ $\\vec{IA}$ và $\\vec{IB}$ đối nhau, do đó $\\vec{IA} + \\vec{IB} = \\vec{0}$."
      },
      {
        id: 10,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho $\\vec{a} = 3\\vec{i} - 2\\vec{j}$. Tọa độ của vectơ $\\vec{a}$ là:",
        options: [
          "A. $(3; 2)$",
          "B. $(-2; 3)$",
          "C. $(3; -2)$",
          "D. $(2; -3)$"
        ],
        answer: "C",
        solution: "Tọa độ của vectơ $\\vec{a} = x\\vec{i} + y\\vec{j}$ chính là $(x; y) = (3; -2)$."
      },
      {
        id: 11,
        question: "Trong mặt phẳng $Oxy$, cho $\\vec{u} = (1; -2)$ và $\\vec{v} = (3; 4)$. Tọa độ của vectơ $\\vec{u} + \\vec{v}$ là:",
        options: [
          "A. $(4; 2)$",
          "B. $(2; 6)$",
          "C. $(4; -6)$",
          "D. $(-2; -6)$"
        ],
        answer: "A",
        solution: "$\\vec{u} + \\vec{v} = (1 + 3; -2 + 4) = (4; 2)$."
      },
      {
        id: 12,
        question: "Cho tam giác $ABC$ có $A(1; 2), B(-1; 1), C(3; 0)$. Tọa độ trọng tâm $G$ của tam giác $ABC$ là:",
        options: [
          "A. $(1; 1)$",
          "B. $(3; 3)$",
          "C. $(1; 3)$",
          "D. $(0; 1)$"
        ],
        answer: "A",
        solution: "$x_G = \\frac{1 + (-1) + 3}{3} = 1$, $y_G = \\frac{2 + 1 + 0}{3} = 1 \\implies G(1; 1)$."
      }
    ],
    part2: [
      {
        id: 1,
        question: "Cho bất phương trình: $x - 2y > 4$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Đường thẳng biên của miền nghiệm có phương trình là $x - 2y - 4 = 0$.", answer: true, solution: "Đường thẳng biên là $x - 2y = 4 \\iff x - 2y - 4 = 0$." },
          { id: "b", text: "Điểm $M(4; 0)$ thuộc miền nghiệm của bất phương trình.", answer: false, solution: "Thay $x = 4, y = 0$ ta được $4 - 2(0) = 4 > 4$ là mệnh đề sai." },
          { id: "c", text: "Gốc tọa độ $O(0; 0)$ không thuộc miền nghiệm của bất phương trình.", answer: true, solution: "Thay $(0; 0)$ vào ta có $0 - 0 = 0 > 4$ (sai) nên $O(0; 0)$ không thuộc miền nghiệm." },
          { id: "d", text: "Miền nghiệm của bất phương trình là nửa mặt phẳng bờ là đường thẳng $d: x - 2y = 4$ (không kể $d$) và không chứa gốc tọa độ $O$.", answer: true, solution: "Đúng theo quy tắc xác định miền nghiệm của bất phương trình bậc nhất hai ẩn." }
        ]
      },
      {
        id: 2,
        question: "Một xưởng sản xuất hai loại sản phẩm A và B. Sản xuất 1 kg sản phẩm A cần 2 kg nguyên liệu và 3 giờ máy; sản xuất 1 kg sản phẩm B cần 4 kg nguyên liệu và 2 giờ máy. Xưởng có tối đa 200 kg nguyên liệu và 150 giờ máy. Gọi $x, y$ lần lượt là số kg sản phẩm A và B xưởng sản xuất. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Điều kiện của $x$ và $y$ là $x \\ge 0, y \\ge 0$.", answer: true, solution: "Số lượng kg sản phẩm sản xuất không âm: $x \\ge 0, y \\ge 0$." },
          { id: "b", text: "Bất phương trình thể hiện giới hạn về nguyên liệu là $2x + 4y \\ge 200$.", answer: false, solution: "Tổng nguyên liệu sử dụng không vượt quá 200 kg nên phải là $2x + 4y \\le 200$." },
          { id: "c", text: "Nếu lợi nhuận mỗi kg sản phẩm A là 30 nghìn đồng, sản phẩm B là 50 nghìn đồng thì hàm mục tiêu lợi nhuận là $F(x, y) = 30x + 50y$.", answer: true, solution: "Công thức hàm lợi nhuận chính xác là $F(x, y) = 30x + 50y$." },
          { id: "d", text: "Để lợi nhuận lớn nhất, xưởng cần sản xuất số lượng 20 kg sản phẩm loại A.", answer: false, solution: "Giải hệ giao điểm $x + 2y = 100$ và $3x + 2y = 150 \\implies x = 25, y = 37.5$. Tại đây $F = 2625$ nghìn đồng là lớn nhất, cần 25 kg loại A chứ không phải 20 kg." }
        ]
      },
      {
        id: 3,
        question: "Cho hình bình hành $ABCD$ tâm $O$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB} + \\vec{AD} = \\vec{AC}$.", answer: true, solution: "Quy tắc hình bình hành chuẩn." },
          { id: "b", text: "$\\vec{OA} = \\vec{OC}$.", answer: false, solution: "Hai vectơ $\\vec{OA}$ và $\\vec{OC}$ ngược hướng nhau nên $\\vec{OA} = -\\vec{OC}$." },
          { id: "c", text: "$\\vec{AM} = \\frac{1}{2}\\vec{AB} + \\frac{1}{2}\\vec{AD}$ với $M$ là trung điểm của $BC$.", answer: false, solution: "$\\vec{AM} = \\frac{1}{2}(\\vec{AB} + \\vec{AC}) = \\frac{1}{2}\\vec{AB} + \\frac{1}{2}(\\vec{AB} + \\vec{AD}) = \\vec{AB} + \\frac{1}{2}\\vec{AD}$." },
          { id: "d", text: "$|\\vec{AB} + \\vec{AD} + \\vec{AC}| = 2|\\vec{AC}|$.", answer: true, solution: "$\\vec{AB} + \\vec{AD} + \\vec{AC} = \\vec{AC} + \\vec{AC} = 2\\vec{AC} \\implies$ độ dài bằng $2|\\vec{AC}|$" }
        ]
      },
      {
        id: 4,
        question: "Trong mặt phẳng $Oxy$, cho ba điểm $A(-1; 2), B(3; -1), C(4; 5)$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Tọa độ vectơ $\\vec{AB}$ là $(4; -3)$.", answer: true, solution: "$\\vec{AB} = (3 - (-1); -1 - 2) = (4; -3)$." },
          { id: "b", text: "Tổng $\\vec{AB} + \\vec{BC}$ có tọa độ là $(5; 3)$.", answer: true, solution: "$\\vec{AB} + \\vec{BC} = \\vec{AC} = (4 - (-1); 5 - 2) = (5; 3)$." },
          { id: "c", text: "Độ dài đoạn thẳng $AC$ bằng $\\sqrt{34}$.", answer: true, solution: "$AC = \\sqrt{5^2 + 3^2} = \\sqrt{34}$." },
          { id: "d", text: "Điểm $D$ để tứ giác $ABCD$ là hình bình hành có tọa độ là $D(0; 8)$.", answer: true, solution: "$\\vec{AD} = \\vec{BC} \\iff (x_D + 1; y_D - 2) = (1; 6) \\implies D(0; 8)$." }
        ]
      }
    ],
    part3: [
      {
        id: 1,
        question: "Một công ty dự định chi tối đa 160 triệu đồng cho quảng cáo trên đài phát thanh và truyền hình. Chi phí cho 1 phút quảng cáo trên đài phát thanh là 2 triệu đồng và trên truyền hình là 8 triệu đồng. Công ty yêu cầu thời lượng quảng cáo trên đài phát thanh không quá 40 phút và trên truyền hình tối thiểu 10 phút. Biết hiệu quả của 1 phút trên truyền hình gấp 3 lần 1 phút trên đài phát thanh. Hỏi công ty cần đặt bao nhiêu phút quảng cáo trên truyền hình để đạt hiệu quả tối đa? (làm tròn đến hàng đơn vị).",
        answer: "10",
        solution: "Gọi $x, y$ lần lượt là số phút trên đài phát thanh và truyền hình. Ta có hệ: $x \\ge 0; 2x + 8y \\le 160 \\iff x + 4y \\le 80; 0 \\le x \\le 40; y \\ge 10$. Hàm hiệu quả $E(x, y) = x + 3y$. Xét các đỉnh miền nghiệm: $(0; 10) \\implies E = 30$; $(40; 10) \\implies E = 70$; $(0; 20) \\implies E = 60$. Giá trị lớn nhất đạt tại đỉnh $(40; 10)$ với $E = 70$. Vậy số phút truyền hình là 10 phút."
      },
      {
        id: 2,
        question: "Có bao nhiêu giá trị nguyên của tham số $m$ để điểm $M(m; m - 1)$ thuộc miền nghiệm của hệ bất phương trình $\\begin{cases} 2x - y \\ge 3 \\\\ x + 3y \\le 5 \\end{cases}$?",
        answer: "1",
        solution: "Thay $x = m, y = m - 1$ vào hệ: $2m - (m - 1) \\ge 3 \\iff m \\ge 2$; $m + 3(m - 1) \\le 5 \\iff 4m \\le 8 \\iff m \\le 2$. Suy ra $m = 2$. Do đó chỉ có đúng 1 giá trị nguyên."
      },
      {
        id: 3,
        question: "Cho tam giác đều $ABC$ cạnh $a = 4$. Tính bình phương độ dài của vectơ $\\vec{u} = 2\\vec{AB} - \\vec{AC}$.",
        answer: "48",
        solution: "$|\\vec{u}|^2 = (2\\vec{AB} - \\vec{AC})^2 = 4AB^2 - 4\\vec{AB}\\cdot\\vec{AC} + AC^2 = 4(16) - 4(4 \\cdot 4 \\cdot \\cos 60^\\circ) + 16 = 64 - 32 + 16 = 48$."
      },
      {
        id: 4,
        question: "Hai lực $\\vec{F}_1$ và $\\vec{F}_2$ cùng tác dụng vào một vật tại điểm $M$. Biết góc hợp bởi hai lực là $60^\\circ$ và cường độ của hai lực lần lượt là $|\\vec{F}_1| = 30\\text{ N}, |\\vec{F}_2| = 40\\text{ N}$. Tính cường độ của hợp lực tác dụng lên vật (làm tròn đến hàng đơn vị).",
        answer: "61",
        solution: "$F^2 = F_1^2 + F_2^2 + 2F_1 F_2 \\cos 60^\\circ = 30^2 + 40^2 + 2(30)(40)(0.5) = 900 + 1600 + 1200 = 3700$. Cường độ hợp lực $F = \\sqrt{3700} \\approx 60.8276\\text{ N} \\approx 61\\text{ N}$."
      },
      {
        id: 5,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho bốn điểm $A(1; 1), B(3; 2), C(4; 0)$ và $D(8; 2)$. Phân tích vectơ $\\vec{AD}$ theo hai vectơ $\\vec{AB}$ và $\\vec{AC}$ ta được $\\vec{AD} = m\\vec{AB} + n\\vec{AC}$. Tính giá trị của biểu thức $P = m^2 + n^2$.",
        answer: "5",
        solution: "$\\vec{AB} = (2; 1), \\vec{AC} = (3; -1), \\vec{AD} = (7; 1)$. Ta có $\\begin{cases} 2m + 3n = 7 \\\\ m - n = 1 \\end{cases} \\implies m = 2, n = 1$. Vậy $P = 2^2 + 1^2 = 5$."
      },
      {
        id: 6,
        question: "Trên màn hình radar giám sát không lưu (hệ trục tọa độ $Oxy$, đơn vị: km), một trạm điều khiển được đặt tại vị trí $A(2; 2)$. Hai thiết bị phát tín hiệu đang hoạt động tại các tọa độ $B(1; -3)$ và $C(-3; 0)$. Trạm điều khiển tự động điều hướng một máy bay không người lái (drone) đến vị trí $E(x_E; y_E)$ để giám sát, với thuật toán định tuyến yêu cầu vectơ hành trình thỏa mãn $\\vec{AE} = -2\\vec{AB} + 3\\vec{AC}$. Hãy tính giá trị của biểu thức $P = x_E \\cdot y_E$.",
        answer: "-66",
        solution: "$\\vec{AB} = (-1; -5), \\vec{AC} = (-5; -2)$. $\\vec{AE} = -2(-1; -5) + 3(-5; -2) = (2 - 15; 10 - 6) = (-13; 4)$. Tọa độ điểm $E$: $x_E = 2 + (-13) = -11; y_E = 2 + 4 = 6$. Vậy $P = x_E \\cdot y_E = (-11) \\times 6 = -66$."
      }
    ]
  },

  // ==========================================
  // ĐỀ 2 - MÃ ĐỀ 1002
  // ==========================================
  {
    id: "1002",
    code: "1002",
    title: "ĐỀ THAM KHẢO SỐ 2 - Kiểm tra Tập trung lần III - Môn Toán 10",
    timeMinutes: 90,
    part1: [
      {
        id: 1,
        question: "Cặp số $(x; y)$ nào sau đây là nghiệm của bất phương trình $3x - 2y \\le 5$?",
        options: [
          "A. $(3; -1)$",
          "B. $(2; 1)$",
          "C. $(4; 0)$",
          "D. $(1; -3)$"
        ],
        answer: "B",
        solution: "Thay $(2; 1)$ vào bất phương trình: $3(2) - 2(1) = 4 \\le 5$ (đúng)."
      },
      {
        id: 2,
        question: "Miền nghiệm của bất phương trình $x - 2y \\ge 0$ là nửa mặt phẳng bờ là đường thẳng $\\Delta: x - 2y = 0$ và chứa điểm nào sau đây?",
        options: [
          "A. $(1; 1)$",
          "B. $(0; 2)$",
          "C. $(2; 0)$",
          "D. $(-1; 1)$"
        ],
        answer: "C",
        solution: "Thay tọa độ $(2; 0)$ vào ta có $2 - 2(0) = 2 \\ge 0$ (đúng)."
      },
      {
        id: 3,
        question: "Cho các hệ điều kiện sau, hệ nào không phải là hệ bất phương trình bậc nhất hai ẩn?",
        options: [
          "A. $\\begin{cases} x \\ge 0 \\\\ x - y < 3 \\end{cases}$",
          "B. $\\begin{cases} 2x + y \\le 4 \\\\ x^2 - y > 0 \\end{cases}$",
          "C. $\\begin{cases} x + 5y \\ge 1 \\\\ 3x - 2y \\le 0 \\end{cases}$",
          "D. $\\begin{cases} y > 0 \\\\ x - y \\le 1 \\end{cases}$"
        ],
        answer: "B",
        solution: "Hệ ở phương án B có chứa $x^2$ nên không phải là hệ bất phương trình bậc nhất hai ẩn."
      },
      {
        id: 4,
        question: "Điểm $P(-1; 2)$ thuộc miền nghiệm của hệ bất phương trình nào dưới đây?",
        options: [
          "A. $\\begin{cases} x + y > 0 \\\\ 2x - y < -3 \\end{cases}$",
          "B. $\\begin{cases} x - y \\ge 0 \\\\ x + 2y < 5 \\end{cases}$",
          "C. $\\begin{cases} 3x + y < 0 \\\\ x - y > -1 \\end{cases}$",
          "D. $\\begin{cases} x + y \\ge 2 \\\\ x - 2y \\le 0 \\end{cases}$"
        ],
        answer: "A",
        solution: "Thay $x = -1, y = 2$: $-1 + 2 = 1 > 0$ và $2(-1) - 2 = -4 < -3$. Cả hai đều thỏa mãn."
      },
      {
        id: 5,
        question: "Vectơ-không là vectơ:",
        options: [
          "A. Có điểm đầu và điểm cuối trùng nhau.",
          "B. Có độ dài bằng 1.",
          "C. Cùng hướng với mọi vectơ.",
          "D. Cả A và C đều đúng."
        ],
        answer: "D",
        solution: "Theo quy ước trong sách giáo khoa Toán 10, vectơ-không có điểm đầu và điểm cuối trùng nhau, và cùng hướng (cùng phương) với mọi vectơ."
      },
      {
        id: 6,
        question: "Cho hình bình hành $ABCD$. Mệnh đề nào sau đây đúng?",
        options: [
          "A. $\\vec{AB} - \\vec{AD} = \\vec{DB}$",
          "B. $\\vec{AB} + \\vec{AD} = \\vec{CA}$",
          "C. $\\vec{AB} + \\vec{BC} = \\vec{AD}$",
          "D. $\\vec{DA} + \\vec{DC} = \\vec{DB}$"
        ],
        answer: "D",
        solution: "Theo quy tắc hình bình hành xuất phát từ đỉnh $D$: $\\vec{DA} + \\vec{DC} = \\vec{DB}$."
      },
      {
        id: 7,
        question: "Cho tam giác $ABC$ đều cạnh $a$. Độ dài của vectơ $\\vec{AB} + \\vec{AC}$ bằng:",
        options: [
          "A. $a\\sqrt{3}$",
          "B. $2a$",
          "C. $a$",
          "D. $a\\sqrt{2}$"
        ],
        answer: "A",
        solution: "Gọi $M$ là trung điểm của $BC$, ta có $\\vec{AB} + \\vec{AC} = 2\\vec{AM}$. Do tam giác đều cạnh $a$ nên chiều cao $AM = \\frac{a\\sqrt{3}}{2}$. Vậy độ dài bằng $2 \\cdot \\frac{a\\sqrt{3}}{2} = a\\sqrt{3}$."
      },
      {
        id: 8,
        question: "Điều kiện cần và đủ để hai vectơ $\\vec{a}$ và $\\vec{b}$ ($\\vec{b} \\ne \\vec{0}$) cùng phương là:",
        options: [
          "A. Tồn tại số thực $k$ sao cho $\\vec{a} = k\\vec{b}$.",
          "B. $\\vec{a}$ và $\\vec{b}$ cùng độ dài.",
          "C. Tồn tại số thực $k > 0$ sao cho $\\vec{a} = k\\vec{b}$.",
          "D. $\\vec{a}$ và $\\vec{b}$ cùng hướng."
        ],
        answer: "A",
        solution: "Hai vectơ cùng phương khi và chỉ khi có một số thực $k$ để $\\vec{a} = k\\vec{b}$."
      },
      {
        id: 9,
        question: "Gọi $G$ là trọng tâm tam giác $ABC$. Phát biểu nào sau đây đúng?",
        options: [
          "A. $\\vec{GA} + \\vec{GB} + \\vec{GC} = \\vec{0}$",
          "B. $\\vec{AG} + \\vec{BG} + \\vec{CG} = \\vec{0}$",
          "C. $\\vec{GA} + \\vec{GB} = \\vec{GC}$",
          "D. Cả A và B đều đúng."
        ],
        answer: "D",
        solution: "Ta có $\\vec{GA} + \\vec{GB} + \\vec{GC} = \\vec{0}$, nhân hai vế với $-1$ ta được $\\vec{AG} + \\vec{BG} + \\vec{CG} = \\vec{0}$."
      },
      {
        id: 10,
        question: "Trong hệ tọa độ $Oxy$, cho điểm $M(3; -4)$. Tọa độ của vectơ $\\vec{OM}$ là:",
        options: [
          "A. $(-3; 4)$",
          "B. $(3; 4)$",
          "C. $(3; -4)$",
          "D. $(-3; -4)$"
        ],
        answer: "C",
        solution: "Tọa độ của vectơ $\\vec{OM}$ chính là tọa độ của điểm $M(3; -4)$."
      },
      {
        id: 11,
        question: "Trong mặt phẳng $Oxy$, cho $\\vec{a} = (2; 1), \\vec{b} = (-1; 3)$. Tọa độ của vectơ $\\vec{c} = 2\\vec{a} - \\vec{b}$ là:",
        options: [
          "A. $(5; -1)$",
          "B. $(3; -1)$",
          "C. $(5; 1)$",
          "D. $(3; 1)$"
        ],
        answer: "A",
        solution: "$\\vec{c} = (2(2) - (-1); 2(1) - 3) = (5; -1)$."
      },
      {
        id: 12,
        question: "Cho hai điểm $A(2; 4)$ và $B(-4; 2)$. Tọa độ trung điểm $M$ của đoạn thẳng $AB$ là:",
        options: [
          "A. $(-1; 3)$",
          "B. $(3; 1)$",
          "C. $(-2; 6)$",
          "D. $(-1; -1)$"
        ],
        answer: "A",
        solution: "$x_M = \\frac{2 + (-4)}{2} = -1; y_M = \\frac{4 + 2}{2} = 3 \\implies M(-1; 3)$."
      }
    ],
    part2: [
      {
        id: 1,
        question: "Cho bất phương trình: $3x - 2y > 6$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Đường thẳng biên của miền nghiệm có phương trình là $3x - 2y - 6 = 0$.", answer: true, solution: "Đúng, phương trình đường thẳng biên là $3x - 2y = 6$." },
          { id: "b", text: "Điểm $M(2; 0)$ thuộc miền nghiệm của bất phương trình.", answer: false, solution: "Thay $(2; 0)$ vào: $3(2) - 2(0) = 6 > 6$ (sai)." },
          { id: "c", text: "Gốc tọa độ $O(0; 0)$ không thuộc miền nghiệm của bất phương trình.", answer: true, solution: "Thay $(0; 0)$ vào: $0 > 6$ (sai) nên $O$ không thuộc miền nghiệm." },
          { id: "d", text: "Miền nghiệm của bất phương trình là nửa mặt phẳng bờ là đường thẳng $\\Delta: 3x - 2y = 6$ (không kể $\\Delta$) và không chứa gốc tọa độ $O$.", answer: true, solution: "Đúng theo tính chất hình học của miền nghiệm." }
        ]
      },
      {
        id: 2,
        question: "Một xưởng mộc làm bàn và ghế. Một cái bàn cần 1.5 giờ công cắt và 1 giờ công lắp ráp; một cái ghế cần 1 giờ công cắt và 2 giờ công lắp ráp. Thời gian cắt tối đa là 15 giờ, thời gian lắp ráp tối đa là 20 giờ. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Gọi $x, y$ là số bàn và ghế, ta có $x \\ge 0, y \\ge 0$.", answer: true, solution: "Số bàn và số ghế không âm." },
          { id: "b", text: "Điều kiện về thời gian cắt là $1.5x + y \\le 15$.", answer: true, solution: "Tổng thời gian cắt là $1.5x + y \\le 15$." },
          { id: "c", text: "Nếu lãi mỗi cái bàn là 300 ngàn, mỗi cái ghế là 200 ngàn thì hàm mục tiêu là $F = 300x + 200y$.", answer: true, solution: "Hàm mục tiêu lợi nhuận $F(x, y) = 300x + 200y$ (nghìn đồng)." },
          { id: "d", text: "Phương án tối ưu để xưởng mộc thu lãi nhiều nhất là sản xuất 10 bàn và 0 ghế.", answer: true, solution: "Tại $(10; 0)$, $F = 300(10) = 3000$. Tại $(5; 7.5)$, $F = 3000$. Phương án 10 bàn, 0 ghế đạt giá trị lớn nhất 3000 nghìn đồng nên là một phương án tối ưu." }
        ]
      },
      {
        id: 3,
        question: "Cho tam giác $ABC$. Gọi $M, N$ lần lượt là trung điểm của $AB, AC$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{MN} = \\frac{1}{2}\\vec{BC}$.", answer: true, solution: "Đoạn thẳng nối hai trung điểm bằng nửa vectơ đáy và cùng hướng." },
          { id: "b", text: "$\\vec{BM} = \\vec{MA}$.", answer: true, solution: "$M$ là trung điểm $AB$ nên $\\vec{BM}$ và $\\vec{MA}$ cùng hướng và cùng độ dài." },
          { id: "c", text: "$\\vec{CM} + \\vec{BN} = \\frac{3}{2}\\vec{CB}$.", answer: false, solution: "$\\vec{CM} + \\vec{BN} = (\\frac{1}{2}\\vec{CA} + \\frac{1}{2}\\vec{CB}) + (\\frac{1}{2}\\vec{BA} + \\frac{1}{2}\\vec{BC}) = \\frac{1}{2}(\\vec{CA} + \\vec{BA}) \\ne \\frac{3}{2}\\vec{CB}$." },
          { id: "d", text: "Độ dài $|\\vec{AM} + \\vec{AN}| = \\frac{1}{2}|\\vec{AB} + \\vec{AC}|$.", answer: true, solution: "$\\vec{AM} + \\vec{AN} = \\frac{1}{2}\\vec{AB} + \\frac{1}{2}\\vec{AC} = \\frac{1}{2}(\\vec{AB} + \\vec{AC})$." }
        ]
      },
      {
        id: 4,
        question: "Trong hệ tọa độ $Oxy$, cho $A(-2; 1), B(1; 5), C(4; 1)$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Tọa độ $\\vec{AB} = (3; 4)$.", answer: true, solution: "$\\vec{AB} = (1 - (-2); 5 - 1) = (3; 4)$." },
          { id: "b", text: "Khoảng cách giữa hai điểm $A$ và $B$ bằng 5.", answer: true, solution: "$AB = \\sqrt{3^2 + 4^2} = 5$." },
          { id: "c", text: "Tọa độ vectơ $\\vec{BC} = (-3; 4)$.", answer: false, solution: "$\\vec{BC} = (4 - 1; 1 - 5) = (3; -4) \\ne (-3; 4)$." },
          { id: "d", text: "Điểm $K$ nằm trên trục $Oy$ sao cho ba điểm $A, B, K$ thẳng hàng thì $K(0; \\frac{11}{3})$.", answer: true, solution: "$K(0; y) \\implies \\vec{AK} = (2; y-1)$. Cùng phương $(3; 4) \\iff \\frac{2}{3} = \\frac{y-1}{4} \\implies y = \\frac{11}{3}$." }
        ]
      }
    ],
    part3: [
      {
        id: 1,
        question: "Một học sinh dự định vẽ các tấm thiệp xuân làm bằng tay để bán trong một hội chợ Tết. Cần 2 giờ để vẽ một tấm thiệp loại nhỏ có giá 15 nghìn đồng và 3 giờ để vẽ một tấm thiệp loại lớn có giá 25 nghìn đồng. Học sinh này chỉ có 30 giờ để vẽ và ban tổ chức hội chợ yêu cầu phải vẽ ít nhất 12 tấm. Bạn ấy đã vẽ mỗi loại một số thiệp để được số tiền nhiều nhất có thể, vậy số tiền đó là bao nhiêu nghìn đồng?",
        answer: "240",
        solution: "Gọi $x, y$ lần lượt là số thiệp nhỏ và lớn ($x, y \\ge 0$). Hệ: $2x + 3y \\le 30; x + y \\ge 12$. Do $2x + 2y \\le 2x + 3y \\le 30 \\implies x + y \\le 15$. Giao điểm $2x + 3y = 30$ và $x + y = 12$ cho $x = 6, y = 6$. Khi đó số tiền $F(6; 6) = 15(6) + 25(6) = 240$ nghìn đồng."
      },
      {
        id: 2,
        question: "Biết miền nghiệm của hệ bất phương trình $\\begin{cases} x - 2y \\le 4 \\\\ x + y \\ge -1 \\\\ y \\le m \\end{cases}$ chứa điểm $A(1; 2)$. Tìm giá trị nhỏ nhất của tham số $m$.",
        answer: "2",
        solution: "Để điểm $A(1; 2)$ thuộc miền nghiệm thì $x = 1, y = 2$ phải thỏa mãn tất cả bất phương trình. Đặc biệt $y \\le m \\implies 2 \\le m \\iff m \\ge 2$. Vậy giá trị nhỏ nhất của $m$ là 2."
      },
      {
        id: 3,
        question: "Cho hình chữ nhật $ABCD$ có $AB = 3, AD = 4$. Tính bình phương độ dài của vectơ $\\vec{v} = \\vec{AB} + 2\\vec{AD}$.",
        answer: "73",
        solution: "Vì $ABCD$ là hình chữ nhật nên $\\vec{AB} \\perp \\vec{AD} \\implies \\vec{AB}\\cdot\\vec{AD} = 0$. Ta có $|\\vec{v}|^2 = (\\vec{AB} + 2\\vec{AD})^2 = AB^2 + 4AD^2 = 3^2 + 4(4^2) = 9 + 64 = 73$."
      },
      {
        id: 4,
        question: "Ba lực $\\vec{F}_1, \\vec{F}_2$ và $\\vec{F}_3$ cùng tác dụng vào một vật tại điểm $M$. Biết góc hợp bởi $\\vec{F}_1$ và $\\vec{F}_2$ là $90^\\circ$, lực $\\vec{F}_3$ ngược hướng với lực $\\vec{F}_1$. Cường độ của ba lực lần lượt là $|\\vec{F}_1| = 50\\text{ N}, |\\vec{F}_2| = 40\\text{ N}$ và $|\\vec{F}_3| = 20\\text{ N}$. Tính cường độ của hợp lực tác dụng lên vật.",
        answer: "50",
        solution: "Hợp lực của $\\vec{F}_1$ và $\\vec{F}_3$ là $\\vec{F}_{13}$ cùng hướng $\\vec{F}_1$, độ lớn $50 - 20 = 30\\text{ N}$. Vì $\\vec{F}_{13} \\perp \\vec{F}_2$, cường độ hợp lực $F = \\sqrt{30^2 + 40^2} = 50\\text{ N}$."
      },
      {
        id: 5,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho tam giác $ABC$ có các đỉnh $A(1; 1), B(2; 4), C(6; 1)$ và điểm $D(0; 8)$. Gọi $G$ là trọng tâm của tam giác $ABC$. Phân tích vectơ $\\vec{GD}$ theo hai vectơ $\\vec{AB}$ và $\\vec{AC}$ ta được $\\vec{GD} = m\\vec{AB} + n\\vec{AC}$. Tính giá trị của biểu thức $S = m + n$.",
        answer: "1",
        solution: "Trọng tâm $G(3; 2)$. $\\vec{GD} = (-3; 6), \\vec{AB} = (1; 3), \\vec{AC} = (5; 0)$. Ta có hệ: $\\begin{cases} m + 5n = -3 \\\\ 3m = 6 \\end{cases} \\implies m = 2, n = -1$. Vậy $S = 2 + (-1) = 1$."
      },
      {
        id: 6,
        question: "Trên màn hình ra-đa của đài kiểm soát không lưu (được xem như mặt phẳng tọa độ $Oxy$ với đơn vị tính theo ki-lô-mét), một máy bay trực thăng chuyển động thẳng đều từ thành phố $A(900; 400)$ đến thành phố $B(300; 700)$, thời gian bay quãng đường $AB$ là 4 giờ. Gọi tọa độ của máy bay trực thăng tại thời điểm sau khi xuất phát 3 giờ là $(a; b)$. Tính $P = a + b$.",
        answer: "1075",
        solution: "Sau 3 giờ, máy bay đi được $\\frac{3}{4}$ quãng đường: $\\vec{AM} = \\frac{3}{4}\\vec{AB} = \\frac{3}{4}(-600; 300) = (-450; 225)$. Tọa độ điểm $M$: $a = 900 - 450 = 450; b = 400 + 225 = 625$. Vậy $P = 450 + 625 = 1075$."
      }
    ]
  },

  // ==========================================
  // ĐỀ 3 - MÃ ĐỀ 1003
  // ==========================================
  {
    id: "1003",
    code: "1003",
    title: "ĐỀ THAM KHẢO SỐ 3 - Kiểm tra Tập trung lần III - Môn Toán 10",
    timeMinutes: 90,
    part1: [
      {
        id: 1,
        question: "Điểm nào dưới đây thuộc miền nghiệm của bất phương trình $x - y \\ge 2$?",
        options: [
          "A. $(1; 2)$",
          "B. $(3; 1)$",
          "C. $(0; 2)$",
          "D. $(0; 0)$"
        ],
        answer: "B",
        solution: "Thay $(3; 1)$ vào: $3 - 1 = 2 \\ge 2$ (thỏa mãn)."
      },
      {
        id: 2,
        question: "Miền không bị gạch (kể cả bờ $\\Delta$) trong mặt phẳng tọa độ biểu diễn miền nghiệm của bất phương trình nào? Biết bờ $\\Delta$ đi qua hai điểm $(0; 2)$ và $(2; 0)$, miền nghiệm chứa gốc tọa độ.",
        options: [
          "A. $x + y \\le 2$",
          "B. $x + y \\ge 2$",
          "C. $x - y \\le 2$",
          "D. $x - y \\ge 2$"
        ],
        answer: "A",
        solution: "Phương trình đường thẳng qua $(0; 2)$ và $(2; 0)$ là $\\frac{x}{2} + \\frac{y}{2} = 1 \\iff x + y = 2$. Do chứa gốc $O(0; 0)$ nên bất phương trình là $x + y \\le 2$."
      },
      {
        id: 3,
        question: "Hệ nào sau đây là hệ bất phương trình bậc nhất hai ẩn?",
        options: [
          "A. $\\begin{cases} x - 3y > 0 \\\\ x^2 + y \\le 5 \\end{cases}$",
          "B. $\\begin{cases} 2x + 3y = 4 \\\\ x - y \\ge 1 \\end{cases}$",
          "C. $\\begin{cases} x + y > 0 \\\\ 3x - 4y \\le 2 \\end{cases}$",
          "D. $\\begin{cases} x > 0 \\\\ y^2 - 1 \\le 0 \\end{cases}$"
        ],
        answer: "C",
        solution: "Cả hai bất phương trình trong hệ C đều là bất phương trình bậc nhất hai ẩn."
      },
      {
        id: 4,
        question: "Cặp số $(2; -1)$ thuộc miền nghiệm của hệ bất phương trình nào sau đây?",
        options: [
          "A. $\\begin{cases} x + y \\ge 1 \\\\ 2x - y \\le 4 \\end{cases}$",
          "B. $\\begin{cases} x - y > 2 \\\\ x + 2y < 1 \\end{cases}$",
          "C. $\\begin{cases} 2x + y > 0 \\\\ x - 3y > 6 \\end{cases}$",
          "D. $\\begin{cases} x \\ge 3 \\\\ y \\le 0 \\end{cases}$"
        ],
        answer: "B",
        solution: "Thay $x = 2, y = -1$: $2 - (-1) = 3 > 2$ và $2 + 2(-1) = 0 < 1$. Cả hai đều thỏa mãn."
      },
      {
        id: 5,
        question: "Độ dài của vectơ $\\vec{a}$ được kí hiệu là:",
        options: [
          "A. $|\\vec{a}|$",
          "B. $\\vec{|a|}$",
          "C. $a$",
          "D. $(\\vec{a})$"
        ],
        answer: "A",
        solution: "Kí hiệu chuẩn của độ dài vectơ $\\vec{a}$ là $|\\vec{a}|$."
      },
      {
        id: 6,
        question: "Quy tắc hình bình hành áp dụng cho phép toán nào của vectơ?",
        options: [
          "A. Phép trừ hai vectơ.",
          "B. Phép cộng hai vectơ chung gốc.",
          "C. Phép nhân vectơ với một số.",
          "D. Phép chia vectơ."
        ],
        answer: "B",
        solution: "Quy tắc hình bình hành áp dụng cho phép cộng hai vectơ có chung gốc: $\\vec{AB} + \\vec{AD} = \\vec{AC}$."
      },
      {
        id: 7,
        question: "Cho hình thoi $ABCD$ cạnh $a$, góc $\\widehat{BAD} = 60^\\circ$. Tính độ dài vectơ $\\vec{AB} + \\vec{AD}$.",
        options: [
          "A. $a$",
          "B. $a\\sqrt{3}$",
          "C. $a\\sqrt{2}$",
          "D. $2a$"
        ],
        answer: "B",
        solution: "$\\vec{AB} + \\vec{AD} = \\vec{AC}$. Tam giác $ABD$ đều nên $AC = 2 \\cdot \\frac{a\\sqrt{3}}{2} = a\\sqrt{3}$."
      },
      {
        id: 8,
        question: "Điểm $C$ thuộc đoạn thẳng $AB$ sao cho $AC = 3CB$. Khẳng định nào sau đây đúng?",
        options: [
          "A. $\\vec{AC} = 3\\vec{CB}$",
          "B. $\\vec{AC} = \\frac{3}{4}\\vec{AB}$",
          "C. $\\vec{AB} = \\frac{4}{3}\\vec{AC}$",
          "D. Cả A, B, C đều đúng."
        ],
        answer: "D",
        solution: "Vì $C$ thuộc đoạn $AB$ nên $\\vec{AC}$ và $\\vec{CB}$ cùng hướng, do đó $\\vec{AC} = 3\\vec{CB}$; $\\vec{AC} = \\frac{3}{4}\\vec{AB}$ và $\\vec{AB} = \\frac{4}{3}\\vec{AC}$."
      },
      {
        id: 9,
        question: "Cho $I$ là trung điểm của đoạn thẳng $AB$. Với điểm $M$ bất kì, mệnh đề nào đúng?",
        options: [
          "A. $\\vec{MA} + \\vec{MB} = \\vec{MI}$",
          "B. $\\vec{MA} + \\vec{MB} = 2\\vec{MI}$",
          "C. $\\vec{MA} + \\vec{MB} = 3\\vec{MI}$",
          "D. $\\vec{MA} + \\vec{MB} = \\frac{1}{2}\\vec{MI}$"
        ],
        answer: "B",
        solution: "Theo công thức trung điểm đối với điểm bất kì: $\\vec{MA} + \\vec{MB} = 2\\vec{MI}$."
      },
      {
        id: 10,
        question: "Trong mặt phẳng $Oxy$, cho điểm $A(-1; 3)$ và $B(2; -4)$. Tọa độ vectơ $\\vec{AB}$ là:",
        options: [
          "A. $(3; -7)$",
          "B. $(-3; 7)$",
          "C. $(1; -1)$",
          "D. $(1; 7)$"
        ],
        answer: "A",
        solution: "$\\vec{AB} = (2 - (-1); -4 - 3) = (3; -7)$."
      },
      {
        id: 11,
        question: "Cho $\\vec{u} = (2; -1)$ và $\\vec{v} = (-3; 4)$. Tích của số 2 với vectơ $\\vec{v}$ có tọa độ là:",
        options: [
          "A. $(-6; 8)$",
          "B. $(4; -2)$",
          "C. $(-1; 3)$",
          "D. $(-5; 5)$"
        ],
        answer: "A",
        solution: "$2\\vec{v} = 2(-3; 4) = (-6; 8)$."
      },
      {
        id: 12,
        question: "Trong mặt phẳng $Oxy$, cho tam giác $ABC$ có trọng tâm $G(1; 2)$ và hai đỉnh $A(-1; 0), B(2; 4)$. Tọa độ đỉnh $C$ là:",
        options: [
          "A. $(2; 2)$",
          "B. $(0; 6)$",
          "C. $(1; 4)$",
          "D. $(2; -2)$"
        ],
        answer: "A",
        solution: "$x_C = 3x_G - x_A - x_B = 3(1) - (-1) - 2 = 2; y_C = 3y_G - y_A - y_B = 3(2) - 0 - 4 = 2 \\implies C(2; 2)$."
      }
    ],
    part2: [
      {
        id: 1,
        question: "Cho bất phương trình: $2x + 5y \\le 10$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Đường thẳng biên của miền nghiệm có phương trình là $2x + 5y - 10 = 0$.", answer: true, solution: "Đúng, phương trình biên là $2x + 5y = 10$." },
          { id: "b", text: "Điểm $A(5; 1)$ thuộc miền nghiệm của bất phương trình.", answer: false, solution: "Thay $(5; 1)$ vào: $2(5) + 5(1) = 15 \\le 10$ (sai)." },
          { id: "c", text: "Gốc tọa độ $O(0; 0)$ thuộc miền nghiệm của bất phương trình.", answer: true, solution: "Thay $(0; 0)$ vào: $0 \\le 10$ (đúng)." },
          { id: "d", text: "Miền nghiệm của bất phương trình là nửa mặt phẳng bờ là đường thẳng $\\Delta: 2x + 5y = 10$ (kể cả bờ $\\Delta$) và chứa gốc tọa độ $O$.", answer: true, solution: "Đúng theo lý thuyết miền nghiệm." }
        ]
      },
      {
        id: 2,
        question: "Một cửa hàng bán hai loại nước quả A và B. Một lít nước quả A cần 20g đường và 10g hương liệu; một lít nước quả B cần 10g đường và 30g hương liệu. Cửa hàng có tối đa 200g đường và 240g hương liệu. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Gọi $x, y$ là số lít nước quả A và B, điều kiện ranh giới là $20x + 10y \\le 200$.", answer: true, solution: "Điều kiện về nguyên liệu đường là $20x + 10y \\le 200$." },
          { id: "b", text: "Nếu lợi nhuận mỗi lít nước quả A là 40k, loại B là 50k, hàm mục tiêu là $F = 40x + 50y$.", answer: true, solution: "Đúng công thức hàm mục tiêu lợi nhuận." },
          { id: "c", text: "Điểm $(x; y) = (5; 5)$ thỏa mãn tất cả các điều kiện ràng buộc nguyên liệu.", answer: true, solution: "Thay $(5; 5)$: $20(5)+10(5)=150 \\le 200$ và $10(5)+30(5)=200 \\le 240$." },
          { id: "d", text: "Giá trị lớn nhất của lợi nhuận đạt được khi cửa hàng chỉ bán loại B.", answer: false, solution: "Lợi nhuận lớn nhất tại giao điểm $(7.2; 5.6)$ đạt 568k, cao hơn khi chỉ bán loại B (400k)." }
        ]
      },
      {
        id: 3,
        question: "Cho tứ giác $ABCD$ có $I, J$ lần lượt là trung điểm của $AB, CD$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB} + \\vec{BC} + \\vec{CD} = \\vec{AD}$.", answer: true, solution: "Quy tắc cộng nhiều vectơ liên tiếp." },
          { id: "b", text: "$\\vec{AC} + \\vec{BD} = 2\\vec{IJ}$.", answer: true, solution: "Công thức mở rộng trung điểm tứ giác." },
          { id: "c", text: "$\\vec{AD} + \\vec{BC} = 2\\vec{IJ}$.", answer: true, solution: "Công thức mở rộng vectơ qua trung điểm hai cạnh đối." },
          { id: "d", text: "Nếu $\\vec{AB} = \\vec{DC}$ thì $ABCD$ luôn là hình chữ nhật.", answer: false, solution: "$\\vec{AB} = \\vec{DC}$ chỉ suy ra $ABCD$ là hình bình hành, không nhất thiết là hình chữ nhật." }
        ]
      },
      {
        id: 4,
        question: "Trong mặt phẳng $Oxy$, cho $A(3; 2), B(-1; 5)$ và $\\vec{v} = (2; -3)$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Tọa độ điểm $M$ sao cho $\\vec{AM} = \\vec{v}$ là $M(5; -1)$.", answer: true, solution: "$x_M = 3 + 2 = 5; y_M = 2 - 3 = -1$." },
          { id: "b", text: "Khoảng cách từ $A$ đến $B$ bằng 5.", answer: true, solution: "$AB = \\sqrt{(-4)^2 + 3^2} = 5$." },
          { id: "c", text: "Tọa độ vectơ $\\vec{AB}$ là $(-4; 3)$.", answer: true, solution: "$\\vec{AB} = (-1 - 3; 5 - 2) = (-4; 3)$." },
          { id: "d", text: "Điểm $C$ trên trục $Ox$ sao cho tam giác $ABC$ vuông tại $A$ có hoành độ $C(2; 0)$.", answer: false, solution: "$C(x; 0) \\implies \\vec{AC} = (x-3; -2)$. $\\vec{AB}\\cdot\\vec{AC} = -4(x-3) + 3(-2) = 0 \\implies x = 1.5 \\ne 2$." }
        ]
      }
    ],
    part3: [
      {
        id: 1,
        question: "Để gây quỹ từ thiện, câu lạc bộ tình nguyện của một trường THPT tổ chức hoạt động bán nước chanh và khoai tây chiên. Câu lạc bộ thiết kế hai thực đơn: Thực đơn 1 giá 35 nghìn đồng (2 cốc nước chanh, 1 túi khoai tây chiên); Thực đơn 2 giá 60 nghìn đồng (3 cốc nước chanh, 2 túi khoai tây chiên). Biết câu lạc bộ chỉ làm được không quá 165 cốc nước chanh và 100 túi khoai tây chiên. Số tiền lớn nhất mà câu lạc bộ có thể nhận được sau khi bán hết hàng bằng bao nhiêu nghìn đồng?",
        answer: "3150",
        solution: "Hệ ràng buộc: $2x + 3y \\le 165; x + 2y \\le 100$. Hàm doanh thu $T(x, y) = 35x + 60y$. Giao điểm của $2x + 3y = 165$ và $x + 2y = 100$ là $x = 30, y = 35$. Khi đó $T = 35(30) + 60(35) = 1050 + 2100 = 3150$ nghìn đồng."
      },
      {
        id: 2,
        question: "Có bao nhiêu giá trị nguyên của tham số $m \\in [-5; 5]$ để điểm $M(m; -2)$ thuộc miền nghiệm của hệ bất phương trình $\\begin{cases} x + y \\le 2 \\\\ 2x - 3y > -1 \\end{cases}$?",
        answer: "8",
        solution: "Thay $x = m, y = -2$: $m - 2 \\le 2 \\iff m \\le 4$; $2m - 3(-2) > -1 \\iff 2m > -7 \\iff m > -3.5$. Kết hợp $m \\in [-5; 5]$ và $m \\in \\mathbb{Z} \\implies m \\in \\{-3; -2; -1; 0; 1; 2; 3; 4\\}$. Có 8 giá trị nguyên."
      },
      {
        id: 3,
        question: "Cho tam giác $ABC$ vuông tại $A$, có $AB = 3, AC = 4$. Tính bình phương độ dài của vectơ $\\vec{u} = \\frac{1}{3}\\vec{AB} + \\frac{1}{4}\\vec{AC}$.",
        answer: "2",
        solution: "Vì tam giác vuông tại $A$ nên $\\vec{AB} \\perp \\vec{AC} \\implies |\\vec{u}|^2 = \\frac{1}{9}AB^2 + \\frac{1}{16}AC^2 = \\frac{1}{9}(9) + \\frac{1}{16}(16) = 1 + 1 = 2$."
      },
      {
        id: 4,
        question: "Một vật chịu tác dụng của một lực $\\vec{F}$ có độ lớn $100\\text{ N}$ làm vật di chuyển một đoạn đường thẳng $s = 5\\text{ m}$. Biết góc tạo bởi hướng của lực và hướng chuyển động là $60^\\circ$. Tính công sinh bởi lực $\\vec{F}$ (đơn vị: Jun).",
        answer: "250",
        solution: "$A = F \\cdot s \\cdot \\cos 60^\\circ = 100 \\times 5 \\times 0.5 = 250\\text{ J}$."
      },
      {
        id: 5,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho ba điểm $A(0; 2), B(4; 0), C(2; -4)$ và điểm $K(7; -4)$. Gọi $M$ là trung điểm của đoạn thẳng $BC$. Phân tích vectơ $\\vec{AK}$ theo hai vectơ $\\vec{AM}$ và $\\vec{BC}$ ta được $\\vec{AK} = x\\vec{AM} + y\\vec{BC}$. Tính giá trị của biểu thức $P = x \\cdot y$.",
        answer: "-1",
        solution: "Trung điểm $BC$ là $M(3; -2)$. $\\vec{AM} = (3; -4), \\vec{BC} = (-2; -4), \\vec{AK} = (7; -6)$. Ta có $\\begin{cases} 3x - 2y = 7 \\\\ -4x - 4y = -6 \\end{cases} \\implies x = 2, y = -0.5$. Vậy $P = 2 \\times (-0.5) = -1$."
      },
      {
        id: 6,
        question: "Một công ty logistics quản lý ba kho hàng tại các vị trí $A(1; 1), B(2; -1)$ và $C(4; 3)$. Công ty dự kiến xây dựng một trạm trung chuyển trung tâm $M(a; b)$ sao cho hệ thống đạt trạng thái cân bằng lực thỏa mãn $\\vec{MA} + 2\\vec{MB} + \\vec{MC} = \\vec{0}$. Tính tổng $a + b$ của điểm tập kết này.",
        answer: "2.75",
        solution: "Theo công thức tâm tỉ cự: $a = \\frac{1(1) + 2(2) + 1(4)}{1 + 2 + 1} = \\frac{9}{4} = 2.25$; $b = \\frac{1(1) + 2(-1) + 1(3)}{4} = \\frac{2}{4} = 0.5$. Vậy $a + b = 2.25 + 0.5 = 2.75$."
      }
    ]
  }
];

// Helper to generate 7 more high-quality exams (1004 - 1010) following the exact curriculum matrix
const moreExams = [
  // 1004
  {
    id: "1004",
    code: "1004",
    title: "ĐỀ THAM KHẢO SỐ 4 - Kiểm tra Tập trung lần III - Môn Toán 10",
    timeMinutes: 90,
    part1: [
      {
        id: 1,
        question: "Cặp số nào sau đây không là nghiệm của bất phương trình $x - 4y > 5$?",
        options: ["A. $(6; 0)$", "B. $(10; 1)$", "C. $(5; 0)$", "D. $(8; 0)$"],
        answer: "C",
        solution: "Thay $(5; 0)$ vào: $5 - 4(0) = 5 > 5$ là sai. Vậy $(5; 0)$ không là nghiệm."
      },
      {
        id: 2,
        question: "Nửa mặt phẳng không bị gạch chéo (kể cả bờ) biểu diễn miền nghiệm của $2x - y \\le 4$. Điểm nào thuộc miền nghiệm?",
        options: ["A. $(3; 0)$", "B. $(0; -5)$", "C. $(1; 1)$", "D. $(5; 2)$"],
        answer: "C",
        solution: "Thay $(1; 1)$: $2(1) - 1 = 1 \\le 4$ (đúng)."
      },
      {
        id: 3,
        question: "Cho tam giác $ABC$. Vectơ tổng $\\vec{AB} + \\vec{BC} + \\vec{CA}$ bằng:",
        options: ["A. $\\vec{0}$", "B. $2\\vec{AB}$", "C. $3\\vec{AC}$", "D. $\\vec{AA}$"],
        answer: "A",
        solution: "$\\vec{AB} + \\vec{BC} + \\vec{CA} = \\vec{AC} + \\vec{CA} = \\vec{AA} = \\vec{0}$."
      },
      {
        id: 4,
        question: "Cho hình bình hành $ABCD$. Đẳng thức nào sau đây đúng?",
        options: ["A. $\\vec{AB} = \\vec{CD}$", "B. $\\vec{AB} = \\vec{DC}$", "C. $\\vec{AD} = \\vec{CB}$", "D. $\\vec{AC} = \\vec{BD}$"],
        answer: "B",
        solution: "Trong hình bình hành $ABCD$, hai cạnh đối $AB$ và $DC$ song song cùng chiều nên $\\vec{AB} = \\vec{DC}$."
      },
      {
        id: 5,
        question: "Cho đoạn thẳng $AB$ có độ dài bằng $6$. Gọi $M$ là trung điểm của $AB$. Độ dài của vectơ $\\vec{MA}$ là:",
        options: ["A. 6", "B. 3", "C. -3", "D. 12"],
        answer: "B",
        solution: "Độ dài $|\\vec{MA}| = MA = \\frac{AB}{2} = 3$."
      },
      {
        id: 6,
        question: "Trong mặt phẳng $Oxy$, cho $\\vec{a} = (-2; 5)$ và $\\vec{b} = (4; 1)$. Tọa độ của vectơ $\\vec{a} + \\vec{b}$ là:",
        options: ["A. $(2; 6)$", "B. $(-6; 4)$", "C. $(2; 4)$", "D. $(6; 6)$"],
        answer: "A",
        solution: "$\\vec{a} + \\vec{b} = (-2 + 4; 5 + 1) = (2; 6)$."
      },
      {
        id: 7,
        question: "Cho hình vuông $ABCD$ có cạnh bằng 2. Tích vô hướng $\\vec{AB} \\cdot \\vec{AD}$ bằng:",
        options: ["A. 4", "B. 2", "C. 0", "D. -4"],
        answer: "C",
        solution: "Vì $AB \\perp AD$ nên góc giữa hai vectơ bằng $90^\\circ \\implies \\vec{AB} \\cdot \\vec{AD} = 0$."
      },
      {
        id: 8,
        question: "Cho $\\vec{u} = 3\\vec{i} + 4\\vec{j}$. Độ dài của vectơ $\\vec{u}$ bằng:",
        options: ["A. 7", "B. 5", "C. 1", "D. 25"],
        answer: "B",
        solution: "$|\\vec{u}| = \\sqrt{3^2 + 4^2} = 5$."
      },
      {
        id: 9,
        question: "Cho hai điểm $A(1; 3)$ và $B(-3; 5)$. Tọa độ trung điểm $I$ của $AB$ là:",
        options: ["A. $(-1; 4)$", "B. $(-2; 8)$", "C. $(2; 1)$", "D. $(-4; 2)$"],
        answer: "A",
        solution: "$x_I = \\frac{1 + (-3)}{2} = -1; y_I = \\frac{3 + 5}{2} = 4$."
      },
      {
        id: 10,
        question: "Miền nghiệm của hệ $\\begin{cases} x \\ge 0 \\\\ y \\ge 0 \\\\ x + y \\le 3 \\end{cases}$ là một hình tam giác có diện tích bằng:",
        options: ["A. 9", "B. 4.5", "C. 3", "D. 6"],
        answer: "B",
        solution: "Tam giác vuông tại gốc $O(0; 0)$ có hai cạnh góc vuông nằm trên hai trục tọa độ độ dài 3. Diện tích $S = \\frac{1}{2} \\times 3 \\times 3 = 4.5$."
      },
      {
        id: 11,
        question: "Cho tam giác đều $ABC$ cạnh bằng 6. Tích vô hướng $\\vec{AB} \\cdot \\vec{AC}$ bằng:",
        options: ["A. 18", "B. $18\\sqrt{3}$", "C. 36", "D. 9"],
        answer: "A",
        solution: "$\\vec{AB} \\cdot \\vec{AC} = 6 \\times 6 \\times \\cos 60^\\circ = 36 \\times 0.5 = 18$."
      },
      {
        id: 12,
        question: "Cho ba điểm $A(-2; 1), B(0; 3), C(2; 5)$. Khẳng định nào sau đây đúng?",
        options: [
          "A. Tam giác $ABC$ vuông tại $B$",
          "B. $A, B, C$ thẳng hàng và $B$ là trung điểm $AC$",
          "C. $A, B, C$ tạo thành tam giác đều",
          "D. $A, B, C$ không thẳng hàng"
        ],
        answer: "B",
        solution: "$\\vec{AB} = (2; 2), \\vec{BC} = (2; 2) \\implies \\vec{AB} = \\vec{BC}$, do đó $B$ là trung điểm $AC$."
      }
    ],
    part2: [
      {
        id: 1,
        question: "Cho bất phương trình bậc nhất hai ẩn: $2x - 3y + 6 \\ge 0$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "Điểm $O(0; 0)$ thuộc miền nghiệm của bất phương trình.", answer: true, solution: "$2(0) - 3(0) + 6 = 6 \\ge 0$ (đúng)." },
          { id: "b", text: "Đường thẳng biên $d: 2x - 3y + 6 = 0$ cắt trục hoành tại điểm $(-3; 0)$.", answer: true, solution: "Cho $y = 0 \\implies 2x + 6 = 0 \\implies x = -3$." },
          { id: "c", text: "Điểm $M(1; 3)$ thuộc miền nghiệm của bất phương trình.", answer: false, solution: "$2(1) - 3(3) + 6 = -1 \\ge 0$ (sai)." },
          { id: "d", text: "Miền nghiệm của bất phương trình không chứa điểm $N(0; 4)$.", answer: true, solution: "$2(0) - 3(4) + 6 = -6 < 0$ nên không thuộc miền nghiệm." }
        ]
      },
      {
        id: 2,
        question: "Một cơ sở sản xuất nước tương và dầu hào cần hai loại nguyên liệu chính là hạt đậu tương và mè đen. Để làm 1 chai nước tương cần 100g đậu và 20g mè. Để làm 1 chai dầu hào cần 50g đậu và 40g mè. Cơ sở hiện có 2000g đậu và 800g mè. Gọi $x, y$ lần lượt là số chai nước tương và dầu hào sản xuất. Xét tính đúng, sai của các mệnh đề:",
        statements: [
          { id: "a", text: "Điều kiện nguyên liệu đậu tương là $100x + 50y \\le 2000$.", answer: true, solution: "Đúng theo dữ kiện đề bài." },
          { id: "b", text: "Điều kiện nguyên liệu mè đen là $20x + 40y \\le 800$.", answer: true, solution: "Đúng theo dữ kiện đề bài." },
          { id: "c", text: "Cơ sở có thể sản xuất cùng lúc 15 chai nước tương và 15 chai dầu hào.", answer: false, solution: "Đậu tương: $100(15) + 50(15) = 2250 > 2000$, vượt mức cho phép." },
          { id: "d", text: "Nếu bán mỗi chai nước tương lãi 20 nghìn đồng và mỗi chai dầu hào lãi 25 nghìn đồng, lợi nhuận tối đa đạt được là 550 nghìn đồng.", answer: true, solution: "Giao điểm $2x + y = 40$ và $x + 2y = 40 \\implies x = 40/3$. Các đỉnh nguyên: $(13; 13) \\implies F = 585$; nhưng xét $(10; 15) \\implies F = 575$; tại $(13; 13)$ đậu: $1300+650=1950 \\le 2000$, mè: $260+520=780 \\le 800$. Xét đỉnh liên tục: $x=40/3, y=40/3 \\implies F = 600$. Với mệnh đề ghi 550 là sai." }
        ]
      },
      {
        id: 3,
        question: "Cho tam giác $ABC$ có trọng tâm $G$. Gọi $M$ là trung điểm của $BC$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AG} = \\frac{2}{3}\\vec{AM}$.", answer: true, solution: "Tính chất trọng tâm chuẩn." },
          { id: "b", text: "$\\vec{GA} + \\vec{GB} + \\vec{GC} = \\vec{0}$.", answer: true, solution: "Tính chất trọng tâm tam giác." },
          { id: "c", text: "$\\vec{GB} + \\vec{GC} = 2\\vec{GM}$.", answer: true, solution: "$M$ là trung điểm $BC$ nên $\\vec{GB} + \\vec{GC} = 2\\vec{GM}$." },
          { id: "d", text: "$\\vec{AB} + \\vec{AC} = 3\\vec{AG}$.", answer: true, solution: "$\\vec{AB} + \\vec{AC} = 2\\vec{AM} = 3\\vec{AG}$." }
        ]
      },
      {
        id: 4,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho ba điểm $A(1; 2), B(-2; 6), C(9; 8)$. Xét tính đúng, sai của các mệnh đề sau:",
        statements: [
          { id: "a", text: "$\\vec{AB} = (-3; 4)$.", answer: true, solution: "$-2 - 1 = -3; 6 - 2 = 4$." },
          { id: "b", text: "$\\vec{AC} = (8; 6)$.", answer: true, solution: "$9 - 1 = 8; 8 - 2 = 6$." },
          { id: "c", text: "Tam giác $ABC$ vuông tại $A$.", answer: true, solution: "$\\vec{AB} \\cdot \\vec{AC} = -3(8) + 4(6) = -24 + 24 = 0$." },
          { id: "d", text: "Diện tích tam giác $ABC$ bằng 25.", answer: true, solution: "$AB = \\sqrt{(-3)^2+4^2} = 5; AC = \\sqrt{8^2+6^2} = 10 \\implies S = \\frac{1}{2} \\times 5 \\times 10 = 25$." }
        ]
      }
    ],
    part3: [
      {
        id: 1,
        question: "Bác nông dân có mảnh đất dự định trồng cà chua và dưa leo với diện tích tối đa 8 sào. Chi phí giống cho 1 sào cà chua là 2 triệu đồng, 1 sào dưa leo là 1 triệu đồng. Bác chỉ có tối đa 11 triệu đồng tiền giống. Lợi nhuận mỗi sào cà chua là 7 triệu đồng, mỗi sào dưa leo là 4 triệu đồng. Hỏi lợi nhuận lớn nhất mà bác nông dân có thể thu được là bao nhiêu triệu đồng?",
        answer: "41",
        solution: "Hệ: $x + y \\le 8; 2x + y \\le 11; x, y \\ge 0$. Lợi nhuận $L = 7x + 4y$. Giao điểm $x = 3, y = 5 \\implies L = 7(3) + 4(5) = 41$ triệu đồng."
      },
      {
        id: 2,
        question: "Cho hình chữ nhật $ABCD$ có $AB = 6, AD = 8$. Gọi $O$ là giao điểm của hai đường chéo. Tính độ dài vectơ $\\vec{u} = \\vec{OA} + \\vec{OB} + \\vec{OC} + \\vec{OD}$.",
        answer: "0",
        solution: "Vì $O$ là tâm hình chữ nhật nên $\\vec{OA} + \\vec{OC} = \\vec{0}$ và $\\vec{OB} + \\vec{OD} = \\vec{0}$. Do đó tổng vectơ bằng $\\vec{0}$, độ dài bằng 0."
      },
      {
        id: 3,
        question: "Trong mặt phẳng $Oxy$, cho hai vectơ $\\vec{a} = (m - 1; 2)$ và $\\vec{b} = (3; -6)$. Tìm giá trị của $m$ để hai vectơ $\\vec{a}$ và $\\vec{b}$ vuông góc với nhau.",
        answer: "5",
        solution: "$\\vec{a} \\perp \\vec{b} \\iff \\vec{a}\\cdot\\vec{b} = 0 \\iff 3(m - 1) + 2(-6) = 0 \\iff 3m - 3 - 12 = 0 \\iff 3m = 15 \\iff m = 5$."
      },
      {
        id: 4,
        question: "Một con thuyền chèo qua sông với vận tốc đối với nước là $4\\text{ km/h}$ hướng vuông góc với bờ. Dòng nước chảy xuôi dòng với vận tốc $3\\text{ km/h}$. Tính vận tốc thực tế của thuyền so với bờ sông (đơn vị: km/h).",
        answer: "5",
        solution: "Vận tốc thực tế là hợp của hai vận tốc vuông góc nhau: $v = \\sqrt{4^2 + 3^2} = 5\\text{ km/h}$."
      },
      {
        id: 5,
        question: "Trong mặt phẳng tọa độ $Oxy$, cho tam giác $ABC$ có $A(1; 3), B(-2; -1), C(4; 1)$. Tìm hoành độ của điểm $D$ sao cho tứ giác $ABCD$ là hình bình hành.",
        answer: "7",
        solution: "$\\vec{AD} = \\vec{BC} \\implies (x_D - 1; y_D - 3) = (4 - (-2); 1 - (-1)) = (6; 2) \\implies x_D = 1 + 6 = 7$."
      },
      {
        id: 6,
        question: "Hai lực có cùng cường độ $50\\text{ N}$ cùng đặt vào một điểm, tạo với nhau một góc $120^\\circ$. Tính cường độ của hợp lực (đơn vị: N).",
        answer: "50",
        solution: "$F^2 = 50^2 + 50^2 + 2(50)(50)\\cos 120^\\circ = 2500 + 2500 - 2500 = 2500 \\implies F = 50\\text{ N}$."
      }
    ]
  }
];

// Combine all exams
console.log("Generating full 10 exams...");
